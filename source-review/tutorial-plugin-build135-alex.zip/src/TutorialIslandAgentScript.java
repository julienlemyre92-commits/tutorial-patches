package net.runelite.client.plugins.microbot.tutorialisland;

import net.runelite.client.plugins.microbot.Microbot;
import net.runelite.client.plugins.microbot.Script;
import net.runelite.client.plugins.microbot.tutorialisland.agent.AgentTelemetry;
import net.runelite.client.plugins.microbot.tutorialisland.agent.TutorialIslandAgent;

import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;

/**
 * AGENT SCRIPT — runs the autonomous Tutorial Island agent.
 *
 * <p>Unlike the legacy {@link TutorialIslandScript} (fixed sequences with
 * boolean flags), this script runs the feedback-controlled agent loop:
 * <pre>
 *   OBSERVE → UNDERSTAND → ACT → VERIFY → UPDATE → LEARN → OBSERVE AGAIN
 * </pre>
 * The screenshot/API state is ground truth; the bot's previous intention
 * is not. Every action declares its observable post-condition and is
 * verified on subsequent ticks.
 *
 * <p>Build marker: AGENT-1 (first autonomous-agent build).
 */
public class TutorialIslandAgentScript extends Script {

    /** Bump for every agent build so the diag log identifies the code. */
    public static final String AGENT_BUILD = "AGENT-1";

    private TutorialIslandAgent agent;
    private ScheduledFuture<?> tickFuture;

    public boolean run(TutorialIslandConfig config) {
        int runId = (int) (System.currentTimeMillis() / 1000);
        AgentTelemetry.observation("==================================================");
        AgentTelemetry.observation(
            "Tutorial Island AUTONOMOUS AGENT starting (" + AGENT_BUILD + ")");
        AgentTelemetry.observation("Loop: OBSERVE → UNDERSTAND → ACT → VERIFY"
            + " → UPDATE → LEARN → OBSERVE AGAIN");
        AgentTelemetry.observation("==================================================");
        Microbot.status = "Tutorial Island: agent starting (" + AGENT_BUILD + ")...";

        agent = new TutorialIslandAgent(runId);

        // One tick every 600ms — matches the game's tick rhythm.
        // Each tick does ONE thing: poll a verification, or execute one
        // discrete action. Never blocks.
        tickFuture = scheduledExecutorService.scheduleWithFixedDelay(() -> {
            try {
                if (!Microbot.isLoggedIn()) return;
                agent.loop();
            } catch (Exception e) {
                AgentTelemetry.warning("agent tick exception: " + e.getMessage());
            }
        }, 0, 600, TimeUnit.MILLISECONDS);

        return true;
    }

    @Override
    public void shutdown() {
        try {
            if (tickFuture != null) tickFuture.cancel(true);
        } catch (Exception ignored) { }
        try {
            if (agent != null) agent.shutdown();
        } catch (Exception ignored) { }
        Microbot.status = "Tutorial Island: agent stopped";
        super.shutdown();
    }

    /** For diagnostics: expose the agent. */
    public TutorialIslandAgent getAgent() {
        return agent;
    }
}
