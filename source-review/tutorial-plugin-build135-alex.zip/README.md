# Tutorial Island Plugin — Build 135 — For Alex Review
## 2026-09-27 20:49 EDT

### What this is
The compiled plugin classes + original source for Build 135.
This is the PATCH ARTIFACT (what gets injected into Julien's local JAR),
NOT Julien's full local JAR (which I cannot access from here).

### Package contents
- `classes/`: 9 compiled .class files (JDK 17, from patch-135.zip)
  - Package: `net.runelite.client.plugins.microbot.tutorialisland`
  - Main class: `TutorialIslandScript` (extends StateMachineScript)
  - Entry: `TutorialIslandPlugin` (Plugin descriptor)
  - Config: `TutorialIslandConfig`
  - Model: `WorldModel` (+ inner classes)
- `src/`: Original .java source files (not decompiled — this is the actual source)

### Artifact hashes
- patch-135.zip (the 4 main classes): SHA-256 `a600d66d6086a1609c4fe74a224f9b4458ac7137be3ea799c9fdfda2f415b6ff`
- version.txt: 135
- Full combined JAR (base + 135 injected, built here for reference):
  SHA-256 `f9fc2779dd0257af69a1670ac4f3fc92ec63f1d68148c7ae494cacb90a762b99`
  (Note: this was built 20:42 with Build 134 classes; Build 135 classes are in patch-135.zip)

### Build marker (from strings on TutorialIslandScript.class)
"Build 135 - SHARED DOOR ROUTE. Alex 2026-09-27: (1) Extracted door-1/door-2 substate logic into handleDoorRouteTick() reusable from doPrayer(). With varp>=550, doPrayer() bypasses doBank() but player at Y=3124 still needs physical route to chapel. (2) doPrayer travel-south now uses explicit door handling, not generic walk+click. (3) Alex fixes: fresh door selection per tick, adjacent-tile reachability, ONE action per tick, latched paused watchdog, specific-door crossing verification. Keeps Build 134 varp>=550 gate."

### Key methods for the fence-gate issue
- `handleDoorRouteTick(WorldPoint, String)`: Shared door handler (NEW in 135)
- `findSouthBlockingDoor(WorldPoint)`: Finds door/gate south of player (NEW)
- `findReachableAdjacentTile(WorldPoint, WorldPoint)`: Adjacent tile check (NEW)
- `verifyDoorCrossing(...)`: Specific-door crossing verification (NEW)
- `doPrayer()`: Calls handleDoorRouteTick when Y>3115 (MODIFIED in 135)
- `doBank()`: Still has Build 134 door-1/door-2 substates (for 540 exit)

### Distinction
- THIS package: Built in my workspace, uploaded to GitHub. I can hash this.
- JULIEN'S PC: Has the full microbot-2.6.18.jar with patched classes injected by Supervisor. I cannot hash or read that file. Only a hash from Julien's PC proves they match.
- Current runtime (20:45): Build 134 banner confirmed 20:42:35. Build 135 shipped but not yet running.

### No credentials, tokens, or personal files included.
