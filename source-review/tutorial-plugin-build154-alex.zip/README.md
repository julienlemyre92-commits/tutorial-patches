# Build 154 — ADJACENT CLICKS — For Alex
## 2026-09-27 22:07 EDT

### Status: SHIPPED (not yet loaded)
Patch: patches/patch-154.zip
SHA-256: 125dba3ab96f1d0cced878ab09abded58e4f472266db371bfb2bdf643baa817e
version.txt = 154
Marker: "Build 154 - ADJACENT CLICKS" (verified via strings)

### Fix (Alex 22:05 code review)

Build 153 made 9722 selectable, but handleDoorRouteTick still did:
  adjacentTile = findReachableAdjacentTile(...)  // excludes own tile -> null
  if (!reachable) return;  // early return BEFORE readyToClick check

The early return blocked the click forever.

154 (review loop): player-adjacent counts as reachable. In both the
selection-tick walk phase AND the phase-1 APPROACH handler:
  alreadyAdjacent = isPlayerAdjacentToDoor(doorTile, playerPos)
  adjacentTile = alreadyAdjacent ? playerPos : findReachableAdjacentTile(...)

This bypasses the early return and goes direct to click Open on 9722
from the current tile (3129,3124).

### Status
Loaded: Build 153 (banner 22:00:32). Available: 154.
Player at (3129,3124), varp 550. Awaiting 154 banner + 9722 accepted
as current-adjacent + Open click + x>3130 exit.
