# Build 139 — Crossing Strict — For Alex
## 2026-09-27 21:00 EDT

### Fixes your 3 findings on 138
1. **Tried-set (not single ID)**:
   - triedDoorIds Set replaces lastReplanDoorId.
   - Resets on meaningful state change (varp or tile changed).
   - Resets when all candidates exhausted (recursive re-select).
   - Logs candidate IDs and skip reasons.
2. **No generic fallback**: APPROACH removes clickDoorDirect('Open',4).
   If findDoorByIdTile() misses, marks tried, clears pending, replans.
   Never clicks a different object while pendingDoorId claims original.
3. **Strict verifyDoorCrossing**:
   - Exactly ONE axis flips sides (both = corner walk, rejected).
   - Non-flipping axis stays within 1 of door tile (no going around).
   - Total movement 1-4 tiles (more = unrelated walking).
   - Uses click-time tile.

### Artifacts
- patch-139.zip SHA-256: fb524541148647d00e2996c05a4ae2fadd77a8d72d7b39beda866524ebc69c52
- version.txt: 139
- Marker: "Build 139 - CROSSING STRICT" (verified via strings)

### Status
139 shipped, not yet running. Runtime remains Build 136 through 20:56:37
(repeated 9722 clicks, 10-tick timeout, oscillation). 137/138 shipped, not confirmed.
