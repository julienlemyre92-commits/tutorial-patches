package net.runelite.client.plugins.microbot.tutorialisland;

import net.runelite.api.Client;
import net.runelite.api.GameState;
import net.runelite.api.Player;
import net.runelite.api.coords.WorldPoint;
import net.runelite.api.events.GameTick;
import net.runelite.api.events.GameStateChanged;
import net.runelite.api.events.WidgetClosed;
import net.runelite.api.events.WidgetLoaded;
import net.runelite.api.widgets.Widget;
import net.runelite.client.callback.ClientThread;
import net.runelite.client.eventbus.Subscribe;
import net.runelite.client.plugins.microbot.Microbot;
import net.runelite.client.plugins.microbot.globval.enums.InterfaceTab;

import java.awt.Rectangle;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicReference;

/**
 * Event-driven world model for the Tutorial Island script.
 *
 * <p>Replaces blocking {@code ClientThread.invoke(Supplier)} polling with
 * non-blocking reads. All {@code @Subscribe} handlers run on the client
 * thread and do nothing but copy fields (never block, never sleep, never
 * I/O). The script thread reads via plain memory accesses.
 *
 * <p>Thread rules (from Microbot AGENTS.md):
 * <ul>
 *   <li>Event handlers: field copies only, &lt; 1ms, no blocking.</li>
 *   <li>Script thread: reads volatile/concurrent fields, never touches game state directly.</li>
 * </ul>
 */
public class WorldModel {

    /** Immutable dialog snapshot to avoid torn reads (title from page 2, body from page 1). */
    public static final class DialogSnapshot {
        public final boolean open;
        public final String title;
        public final String body;
        public DialogSnapshot(boolean open, String title, String body) {
            this.open = open;
            this.title = title == null ? "" : title;
            this.body = body == null ? "" : body;
        }
        public static final DialogSnapshot CLOSED = new DialogSnapshot(false, "", "");
    }

    /**
     * Build 166 (Alex): Immutable door snapshot. Sampled on GameTick (client thread)
     * via client.getObjectDefinition(id) -- no ClientThread.invoke, no 10s stalls.
     * Worker thread filters these cached values instead of calling getName().
     */
    public static final class DoorSnapshot {
        public final int id;
        public final WorldPoint tile;
        public final String name;
        public final String[] actions;
        public final long tick; // GameTick count when sampled
        public DoorSnapshot(int id, WorldPoint tile, String name, String[] actions, long tick) {
            this.id = id;
            this.tile = tile;
            this.name = name == null ? "" : name;
            this.actions = actions == null ? new String[0] : actions;
            this.tick = tick;
        }
        /** True if "Open" is in the actions (fresh, not option0 fallthrough). */
        public boolean hasOpenAction() {
            for (String a : actions) {
                if (a != null && a.equalsIgnoreCase("Open")) return true;
            }
            return false;
        }
    }

    /**
     * Build 166 (Alex): Immutable NPC snapshot. Sampled on GameTick (client
     * thread): id/index are direct reads, name/actions via
     * client.getNpcDefinition(id), tile via getWorldLocation() (runs direct
     * on client thread, no invoke stall). Worker reads these -- never calls
     * withName/getName/getWorldLocation from the worker (each blocks).
     * Logs carry id/index/position (Alex: logs omitted them).
     */
    public static final class NpcSnapshot {
        public final int id;
        public final int index;
        public final String name;
        public final WorldPoint tile;
        public final String[] actions;
        public final long tick;
        public NpcSnapshot(int id, int index, String name, WorldPoint tile,
                           String[] actions, long tick) {
            this.id = id;
            this.index = index;
            this.name = name == null ? "" : name;
            this.tile = tile;
            this.actions = actions == null ? new String[0] : actions;
            this.tick = tick;
        }
    }

    // ---- Cross-thread state (client thread writes, script thread reads) ----

    /** Player position, sampled on GameTick. Null if not logged in. */
    public volatile WorldPoint playerPos;

    /**
     * Build 166 (Alex): Cached door snapshots, sampled on GameTick.
     * Replaces blocking getName() calls (ClientThread.invoke, 10s each)
     * in findSouthBlockingDoor. Worker reads these directly.
     */
    public final AtomicReference<java.util.List<DoorSnapshot>> doorSnapshots =
        new AtomicReference<>(java.util.Collections.emptyList());

    /** GameTick counter for snapshot freshness. */
    public volatile long gameTickCount = 0;

    /**
     * Build 166 (Alex): Cached NPC snapshots, sampled on GameTick.
     * Replaces blocking withName/getName/getWorldLocation calls on the
     * worker. talkToOnce travels to the snapshot position explicitly.
     */
    public final AtomicReference<java.util.List<NpcSnapshot>> npcSnapshots =
        new AtomicReference<>(java.util.Collections.emptyList());

    /** Current dialog state as a single atomic snapshot. */
    public final AtomicReference<DialogSnapshot> dialog = new AtomicReference<>(DialogSnapshot.CLOSED);

    /**
     * Cached widget bounds for physical mouse clicks.
     * Key: (groupId &lt;&lt; 32) | childId. Value: screen bounds, or null if hidden/absent.
     * Sampled on GameTick for the widget IDs the script clicks.
     */
    public final ConcurrentHashMap<Long, Rectangle> widgetBounds = new ConcurrentHashMap<>();

    /**
     * Build 113: cached bounds of the Account Management tab icon, matched by
     * widget name/actions ("account") as a fallback when the packed IDs above
     * don't hit (Jagex shifts tab-bar children between revisions). The script
     * must PHYSICALLY click the flashing account icon — script tab-switches
     * don't satisfy the tutorial flag.
     */
    public final AtomicReference<Rectangle> accountTabBounds = new AtomicReference<>();

    /**
     * Build 115: when accountTabBounds was last (re)sampled (epoch ms). The
     * name-matched target is only trusted while fresh — the tab bar can be
     * hidden/rebuilt and stale bounds would click blind.
     */
    public volatile long accountTabBoundsTime = 0L;

    /**
     * Build 115: sampled widget NAME for the tab packed IDs above (client
     * thread, GameTick). Lets the script VERIFY a packed ID really is the
     * tab it thinks it is instead of clicking a blind derived child.
     * Keyed by the same packed key as widgetBounds.
     */
    public final ConcurrentHashMap<Long, String> tabWidgetNames = new ConcurrentHashMap<>();

    /**
     * Build 116: name-matched tab icon hits for EVERY tutorial tab.
     * Live 2026-09-27 19:00 (Build 115): PRAYER's packed 548:69/161:64
     * (sequence-derived, like the disproven ACC_MAN 548:72) never resolved
     * in the widget cache, so the forced physical click never fired and the
     * script-915 fallback looped without setting the game's flashing-icon
     * tutorial flag. Root cause: packed IDs are derived, never verified
     * against the widget tree. This sampler scans the tab-bar groups every
     * GameTick and matches each icon by widget name/actions — independent
     * of packed child IDs. Smallest matching widget wins per tab (tab icons
     * are ~30px; open panels are not), killing panel-content false
     * positives. Freshness is enforced by the reader (<10s).
     */
    public static final class TabIconHit {
        public volatile Rectangle bounds;
        public volatile String name = "";
        public volatile long time = 0L;
    }

    private final ConcurrentHashMap<InterfaceTab, TabIconHit> tabIconHits = new ConcurrentHashMap<>();

    /** Lowercase name/action keywords identifying each tab icon. */
    private static final java.util.Map<InterfaceTab, String[]> TAB_NAME_KEYWORDS =
            new java.util.EnumMap<>(InterfaceTab.class);
    static {
        TAB_NAME_KEYWORDS.put(InterfaceTab.COMBAT,    new String[]{"combat", "attack"});
        TAB_NAME_KEYWORDS.put(InterfaceTab.SKILLS,     new String[]{"stats", "skill"});
        TAB_NAME_KEYWORDS.put(InterfaceTab.QUESTS,     new String[]{"quest"});
        TAB_NAME_KEYWORDS.put(InterfaceTab.INVENTORY,  new String[]{"inventory", "backpack"});
        TAB_NAME_KEYWORDS.put(InterfaceTab.EQUIPMENT,  new String[]{"equipment", "worn"});
        TAB_NAME_KEYWORDS.put(InterfaceTab.PRAYER,     new String[]{"prayer"});
        TAB_NAME_KEYWORDS.put(InterfaceTab.MAGIC,      new String[]{"magic", "spellbook"});
        TAB_NAME_KEYWORDS.put(InterfaceTab.FRIENDS,    new String[]{"friend"});
        TAB_NAME_KEYWORDS.put(InterfaceTab.SETTINGS,   new String[]{"settings", "options"});
        TAB_NAME_KEYWORDS.put(InterfaceTab.MUSIC,      new String[]{"music"});
        TAB_NAME_KEYWORDS.put(InterfaceTab.LOGOUT,     new String[]{"log out", "logout"});
        TAB_NAME_KEYWORDS.put(InterfaceTab.EMOTES,     new String[]{"emote"});
        TAB_NAME_KEYWORDS.put(InterfaceTab.ACC_MAN,    new String[]{"account"});
    }

    // ---- Widget IDs the script needs bounds for (physical clicks) ----
    // Dialog "Click here to continue" is in the chatbox; we sample the
    // dialog text widget and derive click position from its bounds.
    // Tab icons (from TutorialIslandScript): packed IDs tried as group/child.
    // Equipment stats button: group 387, child 2.

    /** Widget (group, child) pairs to sample bounds for each GameTick. */
    private static final int[][] SAMPLED_WIDGETS = {
        // Dialog chatbox text widget (group 162 = CHATBOX, child varies; we also
        // sample the dialog group directly via getWidgetRoots-free lookup)
        {162, 0},
        // Equipment stats button (Character Summary)
        {387, 2},
        // Tab icons: fixed mode group 161 children, resizable 164 — packed IDs
        // from TutorialIslandScript are packed; we unpack them here.
    };

    /** Packed tab icon IDs (unpacked on GameTick).
     *  Build 124: IDs are now the fork's authoritative
     *  {@link ComponentID} values (gameval InterfaceID), NOT
     *  sequence-derived guesses. Live 2026-09-27 19:33 (Build 118):
     *  the PRAYER flashing-icon prompt looped with NO VERIFIED TARGET —
     *  packed 548:69/161:64/164:64 all null via client.getWidget, and the
     *  name-scan found nothing. Corrections: (1) Build 117's 164:59-65
     *  "TABs" were actually the bottom-line ICONs — the real bottom-line
     *  TABs are 164:52-58 (ComponentID.RESIZABLE_VIEWPORT_BOTTOM_LINE_*_TAB);
     *  (2) ICON widgets (clickable too) are now sampled as fallbacks —
     *  161:66-72, 548:71-77, 164:59-65. Packed = (group << 16) | child. */
    private static final int[] TAB_PACKED_IDS = {
        // fixed (548): stones 64-70 (combat..magic, ComponentID-verified)
        35913792, 35913793, 35913794, 35913795, 35913796, 35913797, 35913798,
        // fixed icons 71-77 (ICON0-6 pair with STONE0-6; 548:76 is the
        // ComponentID-verified FIXED prayer icon). 548:72 doubles as the
        // account entry below (proven live 19:24) so it is not repeated here.
        35913799, 35913801, 35913802, 35913803, 35913804, 35913805,
        // fixed: settings + account (existing, proven live 19:24)
        35913780, 35913800,
        // resizable-side (161): stones 59-65 (ComponentID-verified)
        10551355, 10551356, 10551357, 10551358, 10551359, 10551360, 10551361,
        // resizable-side icons 66-72 (161:71 = ComponentID-verified
        // RESIZABLE prayer icon). 161:67 doubles as the account entry
        // below so it is not repeated here.
        10551362, 10551364, 10551365, 10551366, 10551367, 10551368,
        // resizable-side: settings + account (existing)
        10551343, 10551363,
        // Build 124: resizable bottom-line (164) TABs — the real stones
        // 52-58 (Build 117 sampled 59-65, which are the ICONs, not TABs)
        10747956, 10747957, 10747958, 10747959, 10747960, 10747961, 10747962,
        // bottom-line icons 59-65 (clickable fallbacks; 164:64 = prayer icon)
        10747963, 10747964, 10747965, 10747966, 10747967, 10747968, 10747969,
        // bottom-line: logout, friend chat, friends, settings, emotes, music
        10747938, 10747948, 10747950, 10747951, 10747952, 10747953,
    };

    /** Build 124: resolve a widget through three paths, in order:
     *  (1) client.getWidget(group, child) (existing);
     *  (2) client.getWidget(packed) — the @Component overload, which may
     *      take a different (working) lookup path in the injected client;
     *  (3) manual getWidgetRoots() walk — find the group root (tolerating
     *      packed-id root ids) and read the static child directly.
     *  Live 2026-09-27 19:33: path (1) returned null for every 161:xx tab
     *  icon while the icons were visibly rendered, so the sampler can no
     *  longer rely on a single lookup path. */
    private Widget resolveTabWidget(Client client, int group, int child) {
        Widget w = null;
        try { w = client.getWidget(group, child); } catch (Exception ignored) {}
        if (w != null) return w;
        try { w = client.getWidget((group << 16) | child); } catch (Exception ignored) {}
        if (w != null) return w;
        return resolveViaRoots(client, group, child);
    }

    /** Build 124: manual getWidgetRoots() walk for one (group, child).
     *  Tolerates root ids stored as plain group, packed, or shifted. */
    private Widget resolveViaRoots(Client client, int group, int child) {
        try {
            Widget[] roots = client.getWidgetRoots();
            if (roots != null) {
                for (Widget root : roots) {
                    if (root == null) continue;
                    int rid;
                    try { rid = root.getId(); } catch (Exception ignored) { continue; }
                    if (rid == group || (rid >>> 16) == group || rid == (group << 16)) {
                        try {
                            Widget c = root.getChild(child);
                            if (c != null) return c;
                        } catch (Exception ignored) {}
                        try {
                            Widget[] dyn = root.getDynamicChildren();
                            if (dyn != null) {
                                for (Widget d : dyn) {
                                    if (d == null) continue;
                                    int did;
                                    try { did = d.getId(); } catch (Exception ignored) { continue; }
                                    if (did == child || (did & 0xFFFF) == child) return d;
                                }
                            }
                        } catch (Exception ignored) {}
                        return null;
                    }
                }
            }
        } catch (Exception ignored) {}
        return null;
    }

    private volatile boolean registered = false;

    /** Build 124: throttled widget-tree diagnostic for the tab strip.
     *  The script polls this and logs it via diag() so the review loop
     *  can see EXACTLY what each lookup path returns for the prayer
     *  stone/icon in every layout (mixin group/child vs @Component packed
     *  vs roots walk). Refreshed on GameTick at most every 15s. */
    private volatile String tabStripDiag = "";
    private volatile long tabStripDiagTime = 0;

    /** Latest tab-strip tree diagnostic (never null). */
    public String getTabStripDiag() {
        return tabStripDiag;
    }

    // ---- Lifecycle ----

    public void register() {
        if (registered) return;
        Microbot.getEventBus().register(this);
        registered = true;
    }

    public void unregister() {
        if (!registered) return;
        try {
            Microbot.getEventBus().unregister(this);
        } catch (Exception ignored) {}
        registered = false;
    }

    // ---- Event handlers (ALL on client thread — field copies only) ----

    @Subscribe
    public void onGameTick(GameTick e) {
        Client client = Microbot.getClient();
        if (client == null) return;

        gameTickCount++;

        // Player position (volatile write, cheap)
        try {
            Player p = client.getLocalPlayer();
            playerPos = (p != null) ? p.getWorldLocation() : null;
        } catch (Exception ignored) {}

        // Dialog widgets: targeted reads, NOT a tree scan.
        sampleDialog(client);

        // Widget bounds for physical clicks.
        sampleWidgetBounds(client);

        // Build 113: name-matched Account Management tab icon (fallback for
        // the packed IDs when Jagex shifts tab-bar children).
        sampleAccountTab(client);

        // Build 116: name-matched icons for ALL tutorial tabs (PRAYER's
        // packed IDs never resolved — see field comment).
        sampleTabIcons(client);

        // Build 166 (Alex): door snapshots with names+actions. Replaces
        // blocking getName() (ClientThread.invoke, 10s stall per call).
        sampleDoors(client);

        // Build 166 (Alex): NPC snapshots with id/index/name/tile/actions.
        // Replaces blocking withName/getName/getWorldLocation on worker.
        sampleNpcs(client);

        // Build 124: throttled tab-strip tree diagnostic (see field).
        long now = System.currentTimeMillis();
        if (now - tabStripDiagTime > 15000) {
            tabStripDiagTime = now;
            try {
                tabStripDiag = buildTabStripDiag(client);
            } catch (Exception ignored) {}
        }
    }

    /** Build 124: probe the prayer stone+icon in each layout through all
     *  three lookup paths. One line, e.g.:
     *  "548:TAB69=mixin:33x36@560,168 packed:33x36@560,168 roots:33x36@560,168 ..."
     *  A path reports "null" (no widget), "hidden", or "WxH@X,Y". */
    private String buildTabStripDiag(Client client) {
        StringBuilder sb = new StringBuilder("Build 124: tabstrip tree:");
        // {group, tabChild, iconChild} per layout — ComponentID-verified.
        int[][] layouts = {{548, 69, 76}, {161, 64, 71}, {164, 57, 64}};
        for (int[] l : layouts) {
            int group = l[0];
            sb.append(' ').append(group).append(':');
            // root presence (roots-walk basis)
            boolean rootFound = false;
            try {
                Widget[] roots = client.getWidgetRoots();
                if (roots != null) {
                    for (Widget r : roots) {
                        if (r == null) continue;
                        int rid;
                        try { rid = r.getId(); } catch (Exception ignored) { continue; }
                        if (rid == group || (rid >>> 16) == group || rid == (group << 16)) {
                            rootFound = true;
                            break;
                        }
                    }
                }
            } catch (Exception ignored) {}
            sb.append("root=").append(rootFound ? 'Y' : 'N');
            String[] names = {"TAB" + l[1], "ICON" + l[2]};
            int[] children = {l[1], l[2]};
            for (int i = 0; i < 2; i++) {
                int child = children[i];
                sb.append(' ').append(names[i]).append('=');
                String[] pathNames = {"mixin", "packed", "roots"};
                Widget[] ws = new Widget[3];
                try { ws[0] = client.getWidget(group, child); } catch (Exception ignored) {}
                try { ws[1] = client.getWidget((group << 16) | child); } catch (Exception ignored) {}
                ws[2] = resolveViaRoots(client, group, child);
                for (int p = 0; p < 3; p++) {
                    if (p > 0) sb.append('/');
                    sb.append(pathNames[p]).append(':');
                    Widget w = ws[p];
                    if (w == null) {
                        sb.append("null");
                        continue;
                    }
                    boolean hidden;
                    try { hidden = w.isHidden(); } catch (Exception e) { hidden = true; }
                    if (hidden) {
                        sb.append("hidden");
                        continue;
                    }
                    java.awt.Rectangle b;
                    try { b = w.getBounds(); } catch (Exception e) { b = null; }
                    if (b == null || b.width <= 0 || b.height <= 0) sb.append("nobounds");
                    else sb.append(b.width).append('x').append(b.height)
                            .append('@').append(b.x).append(',').append(b.y);
                }
            }
            sb.append(';');
        }
        return sb.toString();
    }

    /** Build 113: scan tab-bar groups for the Account Management icon by
     *  name/actions. Runs on the client thread; field copies only. */
    private void sampleAccountTab(Client client) {
        try {
            for (int group : new int[]{548, 161, 164}) {
                for (int child = 0; child < 96; child++) {
                    Widget w;
                    // Build 124: same three-path resolution as the packed
                    // sampler (mixin alone misses 161:xx icons).
                    try { w = resolveTabWidget(client, group, child); }
                    catch (Exception e) { continue; }
                    if (w == null || w.isHidden()) continue;
                    boolean match = false;
                    try {
                        String name = w.getName();
                        if (name != null && name.toLowerCase().contains("account")) match = true;
                        if (!match) {
                            String[] actions = w.getActions();
                            if (actions != null) {
                                for (String a : actions) {
                                    if (a != null && a.toLowerCase().contains("account")) { match = true; break; }
                                }
                            }
                        }
                    } catch (Exception ignored) { continue; }
                    if (!match) continue;
                    Rectangle b;
                    try { b = w.getBounds(); } catch (Exception e) { continue; }
                    // Tab icons are small; the open Account Management panel is not.
                    if (b != null && b.width > 0 && b.width < 120 && b.height > 0 && b.height < 120) {
                        accountTabBounds.set(b);
                        accountTabBoundsTime = System.currentTimeMillis();
                        return;
                    }
                }
            }
            // No match this tick: keep the last known bounds (the icon only
            // disappears if the whole tab bar does).
        } catch (Exception ignored) {}
    }

    /** Build 116: scan tab-bar groups for every tutorial tab icon by
     *  name/actions. Runs on the client thread; field copies only. Smallest
     *  matching widget wins per tab (icons, not panels).
     *  Build 117: also scans group 164 (resizable bottom-line layout —
     *  Julien's client; tab icons are 164:59..65 per RuneLite WidgetInfo). */
    private void sampleTabIcons(Client client) {
        try {
            java.util.Map<InterfaceTab, Widget> best = new java.util.EnumMap<>(InterfaceTab.class);
            java.util.Map<InterfaceTab, Integer> bestArea = new java.util.EnumMap<>(InterfaceTab.class);
            for (int group : new int[]{548, 161, 164}) {
                for (int child = 0; child < 96; child++) {
                    Widget w;
                    // Build 124: same three-path resolution as the packed
                    // sampler (mixin alone misses 161:xx icons).
                    try { w = resolveTabWidget(client, group, child); }
                    catch (Exception e) { continue; }
                    if (w == null || w.isHidden()) continue;
                    String hay;
                    try {
                        StringBuilder sb = new StringBuilder();
                        String n = w.getName();
                        if (n != null) sb.append(n).append(' ');
                        String[] actions = w.getActions();
                        if (actions != null) {
                            for (String a : actions) {
                                if (a != null) sb.append(a).append(' ');
                            }
                        }
                        hay = sb.toString().toLowerCase();
                    } catch (Exception e) { continue; }
                    if (hay.trim().isEmpty()) continue;
                    Rectangle b;
                    try { b = w.getBounds(); } catch (Exception e) { continue; }
                    if (b == null || b.width <= 0 || b.height <= 0) continue;
                    if (b.width > 120 || b.height > 120) continue;
                    int area = b.width * b.height;
                    for (java.util.Map.Entry<InterfaceTab, String[]> e : TAB_NAME_KEYWORDS.entrySet()) {
                        boolean match = false;
                        for (String kw : e.getValue()) {
                            if (hay.contains(kw)) { match = true; break; }
                        }
                        if (!match) continue;
                        Integer ba = bestArea.get(e.getKey());
                        if (ba == null || area < ba) {
                            best.put(e.getKey(), w);
                            bestArea.put(e.getKey(), area);
                        }
                    }
                }
            }
            long now = System.currentTimeMillis();
            for (java.util.Map.Entry<InterfaceTab, Widget> e : best.entrySet()) {
                Rectangle b;
                try { b = e.getValue().getBounds(); } catch (Exception ex) { continue; }
                if (b == null) continue;
                String nm = "";
                try {
                    String n = e.getValue().getName();
                    if (n != null) nm = n;
                } catch (Exception ignored) {}
                TabIconHit hit = tabIconHits.computeIfAbsent(e.getKey(), k -> new TabIconHit());
                hit.bounds = b;
                hit.name = nm;
                hit.time = now;
            }
        } catch (Exception ignored) {}
    }

    /** Build 116: freshest name-matched hit for a tab icon, or null. */
    public TabIconHit getTabIconHit(InterfaceTab tab) {
        return tabIconHits.get(tab);
    }

    /**
     * Build 166 (Alex): Sample doors/gates with names+actions on GameTick.
     * Uses client.getObjectDefinition(id) directly (client thread, no blocking).
     * Handles impostors: if getImpostorIds() != null, use getImpostor().
     * Worker thread reads doorSnapshots instead of calling getName().
     */
    private void sampleDoors(Client client) {
        try {
            java.util.List<DoorSnapshot> snaps = new java.util.ArrayList<>();
            WorldPoint pp = playerPos;
            if (pp == null) return;
            // Query tile object cache for doors/gates within 12 tiles.
            // This is a cache read, not a ClientThread.invoke -- safe on client thread.
            var doors = Microbot.getRs2TileObjectCache().query()
                    .within(12)
                    .withNameContains("door")
                    .toList();
            var gates = Microbot.getRs2TileObjectCache().query()
                    .within(12)
                    .withNameContains("gate")
                    .toList();
            java.util.List<net.runelite.client.plugins.microbot.api.tileobject.models.Rs2TileObjectModel> all =
                new java.util.ArrayList<>();
            if (doors != null) all.addAll(doors);
            if (gates != null) all.addAll(gates);
            long tick = gameTickCount;
            for (var m : all) {
                try {
                    int id = m.getId();
                    WorldPoint tile = m.getWorldLocation();
                    if (tile == null) continue;
                    // Get name+actions via ObjectComposition (client thread, no invoke).
                    String name = "";
                    String[] actions = new String[0];
                    try {
                        net.runelite.api.ObjectComposition comp =
                            client.getObjectDefinition(id);
                        if (comp != null) {
                            // Handle impostors (e.g., doors that change state).
                            if (comp.getImpostorIds() != null) {
                                net.runelite.api.ObjectComposition imp = comp.getImpostor();
                                if (imp != null) comp = imp;
                            }
                            name = comp.getName();
                            if (name == null) name = "";
                            String[] a = comp.getActions();
                            if (a != null) actions = a;
                        }
                    } catch (Exception ignored) {}
                    snaps.add(new DoorSnapshot(id, tile, name, actions, tick));
                } catch (Exception ignored) {}
            }
            doorSnapshots.set(java.util.Collections.unmodifiableList(snaps));
        } catch (Exception ignored) {}
    }

    /**
     * Build 166 (Alex): Sample NPCs with id/index/name/tile/actions on
     * GameTick (client thread). getId()/getIndex() are direct reads;
     * getWorldLocation() runs direct on the client thread (no invoke stall);
     * name/actions via client.getNpcDefinition(id). The worker must NEVER
     * call withName/getName/getWorldLocation (each blocks via
     * ClientThread.invoke, up to 10s).
     */
    private void sampleNpcs(Client client) {
        try {
            java.util.List<NpcSnapshot> snaps = new java.util.ArrayList<>();
            var list = Microbot.getRs2NpcCache().query().within(30).toList();
            long tick = gameTickCount;
            if (list != null) {
                for (var m : list) {
                    try {
                        int id = m.getId();
                        int idx = m.getIndex();
                        WorldPoint tile = null;
                        try { tile = m.getWorldLocation(); } catch (Exception ignored) {}
                        String name = "";
                        String[] actions = new String[0];
                        try {
                            net.runelite.api.NPCComposition comp =
                                client.getNpcDefinition(id);
                            if (comp != null) {
                                name = comp.getName();
                                if (name == null) name = "";
                                String[] a = comp.getActions();
                                if (a != null) actions = a;
                            }
                        } catch (Exception ignored) {}
                        snaps.add(new NpcSnapshot(id, idx, name, tile, actions, tick));
                    } catch (Exception ignored) {}
                }
            }
            npcSnapshots.set(java.util.Collections.unmodifiableList(snaps));
        } catch (Exception ignored) {}
    }

    @Subscribe
    public void onWidgetLoaded(WidgetLoaded e) {
        // Dialog group loaded — sample immediately so the script sees it
        // without waiting for the next GameTick.
        if (isDialogGroup(e.getGroupId())) {
            try {
                sampleDialog(Microbot.getClient());
            } catch (Exception ignored) {}
        }
    }

    @Subscribe
    public void onWidgetClosed(WidgetClosed e) {
        if (isDialogGroup(e.getGroupId())) {
            dialog.set(DialogSnapshot.CLOSED);
        }
    }

    @Subscribe
    public void onGameStateChanged(GameStateChanged e) {
        if (e.getGameState() == GameState.LOGIN_SCREEN
                || e.getGameState() == GameState.LOADING) {
            // Region change / logout: clear stale state.
            playerPos = null;
            dialog.set(DialogSnapshot.CLOSED);
            widgetBounds.clear();
        }
    }

    // ---- Client-thread helpers (only called from @Subscribe) ----

    private static boolean isDialogGroup(int groupId) {
        // 162 = chatbox (dialog text), 219 = dialog options, 193 = dialog sprites, etc.
        return groupId == 162 || groupId == 219 || groupId == 193 || groupId == 231;
    }

    /**
     * Sample dialog title/body via targeted widget reads.
     * Uses the same widget IDs as Rs2Dialogue (219:1 for options title,
     * chatbox 162 for NPC dialog) — no recursive tree walk.
     */
    private void sampleDialog(Client client) {
        try {
            // Rs2Dialogue.getQuestion() reads 219:1 when a "select an option" is open.
            // For NPC/chat dialog, the text is in the chatbox (162).
            // We do targeted getWidget calls — microseconds, not a tree scan.
            String title = "";
            String body = "";

            Widget chatbox = client.getWidget(162, 0);
            if (chatbox != null && !chatbox.isHidden()) {
                // The dialog text is typically in a child of the chatbox.
                // We read the known text child IDs directly.
                Widget textWidget = client.getWidget(162, 4);
                if (textWidget == null) textWidget = client.getWidget(162, 3);
                if (textWidget != null && !textWidget.isHidden()) {
                    body = textWidget.getText();
                    if (body == null) body = "";
                }
                // Title is often in a sibling widget.
                Widget titleWidget = client.getWidget(162, 2);
                if (titleWidget != null && !titleWidget.isHidden()) {
                    title = titleWidget.getText();
                    if (title == null) title = "";
                }
            }

            // Dialog options (219:1) — the "question" for select-an-option.
            Widget optTitle = client.getWidget(219, 1);
            if (optTitle != null && !optTitle.isHidden()) {
                String t = optTitle.getText();
                if (t != null && !t.isEmpty()) {
                    title = t;
                    // Options themselves are children of 219.
                }
            }

            boolean open = !body.isEmpty() || !title.isEmpty();
            dialog.set(open ? new DialogSnapshot(true, title, body) : DialogSnapshot.CLOSED);
        } catch (Exception ignored) {
            // Never let a sampler break the client thread.
        }
    }

    /**
     * Sample screen bounds for widgets the script physically clicks.
     * Targeted getWidget(group, child) + getBounds() — no tree walks.
     */
    private void sampleWidgetBounds(Client client) {
        try {
            for (int[] gc : SAMPLED_WIDGETS) {
                long key = key(gc[0], gc[1]);
                try {
                    Widget w = client.getWidget(gc[0], gc[1]);
                    if (w != null && !w.isHidden()) {
                        Rectangle b = w.getBounds();
                        if (b != null && b.width > 0 && b.height > 0) {
                            widgetBounds.put(key, b);
                        } else {
                            widgetBounds.remove(key);
                        }
                    } else {
                        widgetBounds.remove(key);
                    }
                } catch (Exception ignored) {}
            }
            for (int packed : TAB_PACKED_IDS) {
                int group = packed >>> 16;
                int child = packed & 0xFFFF;
                long key = key(group, child);
                try {
                    // Build 124: three lookup paths (mixin group/child,
                    // @Component packed, roots walk) — 19:33 proved the
                    // first path alone returns null for 161:xx icons.
                    Widget w = resolveTabWidget(client, group, child);
                    if (w != null && !w.isHidden()) {
                        Rectangle b = w.getBounds();
                        if (b != null && b.width > 0 && b.height > 0) {
                            widgetBounds.put(key, b);
                        } else {
                            widgetBounds.remove(key);
                        }
                        // Build 115: sample the widget NAME too, so the
                        // script can VERIFY a packed ID really is the tab it
                        // thinks it is (never click a blind derived child).
                        String nm = "";
                        try { nm = w.getName(); } catch (Exception ignored) {}
                        if (nm == null) nm = "";
                        tabWidgetNames.put(key, nm);
                    } else {
                        widgetBounds.remove(key);
                        tabWidgetNames.remove(key);
                    }
                } catch (Exception ignored) {}
            }
        } catch (Exception ignored) {}
    }

    private static long key(int group, int child) {
        return ((long) group << 32) | (child & 0xFFFFFFFFL);
    }

    // ---- Script-thread readers (non-blocking) ----

    /** Get cached bounds for a widget, or null if not visible/cached. */
    public Rectangle getWidgetBounds(int group, int child) {
        return widgetBounds.get(key(group, child));
    }

    /** Get cached bounds for a packed widget ID, or null. */
    public Rectangle getWidgetBoundsPacked(int packedId) {
        int group = packedId >>> 16;
        int child = packedId & 0xFFFF;
        return getWidgetBounds(group, child);
    }

    /** Build 115: sampled widget NAME for a packed tab ID, or "" if unknown. */
    public String getTabWidgetName(int packedId) {
        int group = packedId >>> 16;
        int child = packedId & 0xFFFF;
        String n = tabWidgetNames.get(key(group, child));
        return n == null ? "" : n;
    }

    /** Current dialog snapshot (never null). */
    public DialogSnapshot getDialog() {
        DialogSnapshot d = dialog.get();
        return d != null ? d : DialogSnapshot.CLOSED;
    }

    /** True if a dialog is currently open (per sampled widgets). */
    public boolean isDialogOpen() {
        return getDialog().open;
    }
}
