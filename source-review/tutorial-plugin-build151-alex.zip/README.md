# Build 151 — Door Orientation — For Alex
## 2026-09-27 21:43 EDT

### Status: SHIPPED (not yet loaded)
Patch: patches/patch-151.zip
SHA-256: 64676709efa01e22043c2b0dfe62c6c4fcb5d0c4ba3b365b5d947c5524f953df
version.txt = 151
Marker: "Build 151 - DOOR ORIENTATION" (verified via strings)

### Fix: Route-axis mismatch (Alex's finding)
Build 148 applied south-only (Y-axis) logic to ALL doors. But:
- 9721/9722 at y=3124 are EAST-WEST bank doors (cross on X-axis)
- 1512/1516 near y=3119 are NORTH-SOUTH church gates (cross on Y-axis)

151 adds getDoorOrientation():
- 9721, 9722 → "EW"
- 1512, 1516 → "NS"
- y=3124 → "EW" (heuristic)

WALKTHROUGH farSide:
- EW: (doorX ± 2, doorY) — east/west, opposite the player
- NS: (doorX, doorY - 2) — south

verifyDoorCrossing now orientation-aware:
- EW: accepts X-axis flip (Y hugging door)
- NS: requires Y-axis flip southbound (147 behavior)
- Unknown: south-only (safe default)

### Status
Loaded: Build 148. Available: 151.
Player at (3129,3124), varp 550. No y<=3115.
