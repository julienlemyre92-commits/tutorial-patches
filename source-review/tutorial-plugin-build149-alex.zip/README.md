# Build 149 — One Door Commit — For Alex
## 2026-09-27 21:38 EDT

### Status: SHIPPED (not yet loaded)
Patch: patches/patch-149.zip
SHA-256: c7114e166aef4d8929ccb9948e4c150b62f65497959bbd8a8663d5117dc53e6b
version.txt = 149
Marker: "Build 149 - ONE DOOR COMMIT" (verified via strings)

### Fix vs 148 (Alex's route-model issue)
The bot was oscillating between doors 9721 (3125,3124) and 9722 (3130,3124),
never committing to either. 149 makes findSouthBlockingDoor() return the
PENDING door if one is set — no re-selection, no oscillation.

Once a door is selected, the bot commits until it's cleared (crossed) or
proven impassable. One state transition per door.

### Route
After crossing, head SOUTH (Y decreasing) toward y<=3115 (church/Brother Brace).
Legacy corroboration: Prayer area near (3129,3107), Brother Brace near (3126,3106).
Wiki: https://oldschool.runescape.wiki/w/Learning_the_Ropes

### Status
Player at (3130,3124). No y<=3115. Not crossed.
Stream: 10 watching.
