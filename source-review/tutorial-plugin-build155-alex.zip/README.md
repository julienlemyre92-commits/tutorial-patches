# Build 155 — WALKTHROUGH BYPASS — For Alex
## 2026-09-27 22:35 EDT

### Status: SHIPPED (not yet loaded)
Patch: patches/patch-155.zip
SHA-256: fc4fad9b1339997523822117687fc3ac4ae70ad4a14b60d8c6050e34be3e729e
version.txt = 155
Marker: "Build 155 - WALKTHROUGH BYPASS" (verified via strings)

### Fix (Review loop 22:27, Codex/Alex root cause)

Build 154 looped Open->CLICKED->VERIFY->timeout->replan->Open since 22:11.
The WALKTHROUGH entry gate required the door to disappear from the
object cache, which never happens for 9722.

155 changes:
1. VERIFY phase takes ONE bounded walkthrough attempt directly after Open
   (orientation-aware far-side route to x=3132 east) instead of re-clicking
2. WALKTHROUGH verifies fresh player tile moved after each walk request —
   4 ticks with no tile change = blocked
3. Failed doors parked in blockedDoorIds (never re-selected), route
   reports BLOCKED instead of looping forever

Keeps Build 154 ADJACENT CLICKS.

### Status
Loaded: Build 154. Available: 155.
Player at (3130,3124), varp 550. Awaiting 155 banner + walkthrough
to x>=3131 + east exit proof.
