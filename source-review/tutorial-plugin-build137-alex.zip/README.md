# Build 137 — Phased Door — For Alex
## 2026-09-27 20:55 EDT

### Fixes your 20:53 findings
1. **Phased pending state** (pendingPhase: 1=APPROACH, 2=CLICKED, 3=VERIFY):
   - APPROACH: Walk to adjacent EACH tick; when adjacent (dist<=1), click ONCE,
     transition to CLICKED. Fixes 136 waiting 10 ticks after walk without clicking.
   - CLICKED: Observe for 5 ticks; if crossed -> clear; else -> VERIFY.
   - VERIFY: Bounded retry (one more click) or replan after 8 ticks.
2. **Watchdog in shared handler**: (varp,tile,dialogue,target) 8-tick latch now
   in handleDoorRouteTick() for PRAYER path (was only in doBank()).
3. **findDoorByIdTile()**: Re-finds pending door by ID+tile for re-click.

### Artifacts
- patch-137.zip SHA-256: 2e4082f6d462bfd5a0685f696800265033a0fdb79eeee4eca5eab0773ec0e12f
- version.txt: 137
- Marker: "Build 137 - PHASED DOOR" (verified via strings)

### Status
137 shipped, not yet running. 136 runtime-confirmed (20:52:53 startup,
20:53:10 varp=550/PRAYER, no DOOR lines yet in that immediate post-restart sample).
