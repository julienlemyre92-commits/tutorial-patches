# Build 150 — No Self Target — For Alex
## 2026-09-27 21:40 EDT

### Status: SHIPPED (not yet loaded)
Patch: patches/patch-150.zip
SHA-256: caa7e751e7a025e732c14540b1cf3986e3973f445bc63d2469ac71948fce5da3
version.txt = 150
Marker: "Build 150 - NO SELF TARGET" (verified via strings)

### Fix vs 148/149
Alex found (21:39:04 diag): findReachableAdjacentTile returned (3129,3124)
which IS the player's tile. walkTo() returned true with zero movement.

150 excludes the player's own tile from adjacent candidates. If the player
is already on the closest adjacent, the function returns null (or a different
adjacent), forcing the CLICK path instead of a no-op walk.

### Note
149 (one-door commit) was shipped but never loaded (version.txt stayed 148).
150 includes the 149 commit logic and supersedes it.

### Status
Loaded: Build 148 (21:34:36). Available: 150.
Player at (3129,3124), varp 550. No y<=3115.
