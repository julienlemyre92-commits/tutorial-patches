# Build 140 — Tried-Set Anchor — For Alex
## 2026-09-27 21:02 EDT

### Fixes your Build 139 concern #1
Tried-set reset was on ANY tile change. The (3129,3124)<->(3130,3124)
oscillation cleared the exclusion every tick, defeating it entirely.

Now resets only on:
- varp 281 change, OR
- player moved >5 tiles (Manhattan) from the anchor tile.

Concern #2 (corner-route false positive without orientation evidence)
noted for runtime review; current strict check (one axis flips, other
hugs <=1, movement 1-4) stands until evidence shows otherwise.

### Also confirmed
- 138's CROSSED logs (20:58:44, 20:59:04) were false positives from the OR
  sign-flip test: one-tile X toggles at Y=3124, one endpoint on the door tile.
- 139's strict crossing rejects these (one side is 0, not a flip).
- Julien's visual "crossed then went back" matches the false positives;
  not a real crossing. Corrected with Julien.

### Artifacts
- patch-140.zip SHA-256: 036b26e5870278d24823af5b3a0e03bc05d800181a4f0b09fc6aeb9ac0aeb3c2
- version.txt: 140
- Marker: "Build 140 - TRIED-SET ANCHOR" (verified via strings)

### Status
140 shipped, not yet running. Bot on 138 (Julien confirmed "Bot at 38").
139 shipped but skipped (140 supersedes before runtime).
