# Build 147 — South Cross Only — For Alex
## 2026-09-27 21:30 EDT

### Status: SHIPPED (not yet loaded)
Patch: patches/patch-147.zip
SHA-256: 4aa712af9c23b7971f1fad4716df5822f6fd91c211f26f23efe4255d611bab94
version.txt = 147
Marker: "Build 147 - SOUTH CROSS ONLY" (verified via strings)

### Fix vs 146
Alex identified: verifyDoorCrossing accepted X-axis sign flips as "crossed"
when Y stayed within 1 of the door. The 21:25:48 diag "CROSSED 9722" from
(3131,3124)->(3129,3124) was a lateral shuffle PAST the door, not THROUGH it.

147 requires:
- crossedY (north-to-south sign flip on Y)
- wentSouth (afterY < 0, ended on south side)
- huggingX (X within 1 of door, no going around)
X-flip alone now returns false (not a crossing).

### Status
Bot is at the door (3130,3124), NOT crossed. No y<=3115.
Julien confirmed: "still stuck at the door."
Church progress NOT claimed.
