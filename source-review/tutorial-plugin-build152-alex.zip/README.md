# Build 152 — Click State + Orient — For Alex
## 2026-09-27 21:46 EDT

### Status: SHIPPED (not yet loaded)
Patch: patches/patch-152.zip
SHA-256: 98a99b196dfe33156da254e4281f5736e9193e17bbb8863db00c8d141d4144af
version.txt = 152
Marker: "Build 152 - CLICK STATE+ORIENT" (verified via strings)

### Fixes (Alex's two gaps in 151)

1. Click state: The fresh-target click path at ~3540 called doorObj.click("Open")
   then returned WITHOUT setting pendingClickTile or phase=2. Next tick saw
   phase=APPROACH and replanned (21:43:30 clicked, 21:43:31 replanned).
   152 sets pendingClickTile=playerPos, pendingPhase=2, ticks=0, retry=false
   in BOTH click paths.

2. Orientation passed through:
   - verifyDoorCrossing call at ~3193 now passes getDoorOrientation()
   - verifyWalkthroughFarSide now has orientation-aware overload:
     EW requires X progress east (tileAfter.x > door.x, moving east)
     NS requires Y progress south (legacy behavior)

### Status
Loaded: Build 148 (through 21:44:12). Available: 152.
Player at (3129,3124), varp 550. Awaiting 152 banner + east/outside movement.
