# Build 148 — Walker Lie Detect — For Alex
## 2026-09-27 21:33 EDT

### Status: SHIPPED (not yet loaded)
Patch: patches/patch-148.zip
SHA-256: 282d8facf55522c084c160ad681f9eaa6b893ffc691be827ae8039e724bdc42c
version.txt = 148
Marker: "Build 148 - WALKER LIE DETECT" (verified via strings)

### Fix vs 147
Alex reported: walkTo returns true but player doesn't move (21:30:22:
player (3129,3124), target (3126,3124), result=true, before/after same).

148 adds walker lie detection: if walkTo()=true BUT fresh before/after
positions are identical (no actual tile change), log "WALKER LIED!" and
force direct door click instead of trusting the boolean.

Movement evidence = actual tile change, not the boolean.

### Status
Player at (3130,3124) clicking door 9722. No y<=3115. Not crossed.
Stream: 10 watching.
