# Build 136 — Pending Door Fix — For Alex
## 2026-09-27 20:52 EDT

### Fixes your 20:49:06 findings
1. **verifyDoorCrossing() now has a call site**: handleDoorRouteTick() STEP 1
   checks pending door FIRST, calls verifyDoorCrossing(pendingTileBefore,
   playerPos, pendingDoorTile). Only clears pending on actual crossing.
2. **Holds pending target**: pendingDoorId/pendingDoorTile/pendingTileBefore
   retained across ticks. No more alternating Door/9722 ↔ Door/9721.
3. **findSouthBlockingDoor() enumerates**: Uses toList() (not nearest()),
   filters to doors south of player (Y <= playerY+2), picks nearest qualifying.
4. **Watchdog uses stable ID**: bankDoorTargetDesc built from pendingDoorId,
   not switching per tick.
5. **Distinguishes unreachable vs no-blocker**: hasAnyDoorNearby() checks if
   any door exists; if yes but none qualify → wait (don't walk into wall).

### Artifacts
- patch-136.zip SHA-256: 7413c200200fbbfe0d9a74e528a02680a2d35ae757fb203ee2962089b6262dc4
- version.txt: 136
- Marker: "Build 136 - PENDING DOOR FIX" (verified via strings)

### Status
136 shipped, not yet running. Build 135 runtime-confirmed (varp 550 at 20:47:58,
door logs 20:48:06-20:49:05, looping as you diagnosed).

### Distinction
This is the patch artifact from my workspace, NOT Julien's full local JAR.
