package net.runelite.client.plugins.microbot.tutorialisland;

import com.google.inject.Provides;
import net.runelite.client.config.ConfigManager;
import net.runelite.client.plugins.Plugin;
import net.runelite.client.plugins.PluginDescriptor;

import javax.inject.Inject;

@PluginDescriptor(
        name = "Tutorial Island",
        description = "Automates Tutorial Island on a fresh account. Enable it while standing on Tutorial Island.",
        tags = {"tutorial", "microbot", "automation"},
        enabledByDefault = false
)
public class TutorialIslandPlugin extends Plugin {
    private static final org.slf4j.Logger log =
            org.slf4j.LoggerFactory.getLogger(TutorialIslandPlugin.class);
    @Inject
    private TutorialIslandScript script;

    @Inject
    private TutorialIslandConfig config;

    @Provides
    TutorialIslandConfig provideConfig(ConfigManager configManager) {
        return configManager.getConfig(TutorialIslandConfig.class);
    }

    @Override
    protected void startUp() {
        script.run(config);
    }

    @Override
    protected void shutDown() {
        script.shutdown();
    }
}
