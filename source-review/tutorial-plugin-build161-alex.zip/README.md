# Build 161 — DIRECTED DOORS — For Alex
## 2026-09-27 22:56 EDT

### Status: SHIPPED (not yet loaded)
Patch: patches/patch-161.zip
SHA-256: 8fb411906e1a4da091852c2da2c209822dd576a5ebe0f1a4c601321e5f85bd0e
version.txt = 161
Marker: "Build 161 - DIRECTED DOORS" (verified via strings)

### Fixes (Alex 22:54 findings)

**Reverse-route bug**: 159 crossed 9722 east (3129,3124→3132,3124) at
22:53:25, then re-selected SAME 9722 at 22:53:43 and crossed BACK WEST
at 22:53:45. Then selected 9721 deeper in bank.

Root cause: CROSSED cleared pending state but never recorded directed
doorway completion. findSouthBlockingDoor re-found 9722 (nearby);
computeDoorFarSide chose west from east side.

Fix:
- New completedDoorIds set -- doors successfully crossed
- Excluded from findSouthBlockingDoor selection (SKIP(completed))
- Walker target reset on successful crossing (phase exit)
- Prevents 9722 east->west reversal

**Remaining blocking walkTo**: Replaced at approach (~3640) and prayer
travel (~6822) with non-blocking walkStep.

Keeps: 160 liveness, 159 varp thresholds, NPC wrapper, Quest Guide scope.

### Status
Loaded: Build 159 (crossed east, then reversed). Available: 161.
Awaiting 161 banner. Priority: continue SOUTH to Brace, no more reversals.
