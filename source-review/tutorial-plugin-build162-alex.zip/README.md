# Build 162 — NO OSCILLATION — For Alex
## 2026-09-27 22:58 EDT

### Status: SHIPPED (not yet loaded)
Patch: patches/patch-162.zip
SHA-256: 0fc22618e3501ac9ee87117bcccf24ca69b0361583c6c31651901d590bd71d06
version.txt = 162
Marker: "Build 162 - NO OSCILLATION" (verified via strings)

### Fixes (Alex 22:57)

1. **APPROACH oscillation**: 159 oscillates 9721 (3125,3123<->3125,3125)
   every 4-5s. Root: findReachableAdjacentTile excludes player's own tile;
   phase1 only checked isPlayerAdjacentToDoor if search returned null.
   If already adjacent, search returns OPPOSITE tile -> walk back and forth.
   Fix: adjacency FIRST:
     WorldPoint adj = isPlayerAdjacentToDoor(pendingDoorTile, playerPos)
         ? playerPos : findReachableAdjacentTile(...);

2. **WALKTHROUGH completion**: WALKTHROUGH-success now records
   completedDoorIds too (was only CLICK-success). Plus walker reset.

3. **hasAnyDoorNearby**: Excludes completed/blocked doors. A completed door
   nearby is not a reason to wait -- return false so caller walks south.

Keeps: 161 directed doors, 160 liveness, 159 varp thresholds.

### Status
Loaded: Build 159 (oscillating). Available: 162.
Awaiting 162 banner. Priority: stop oscillation, continue south to Brace.
