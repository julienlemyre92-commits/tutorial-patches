# Build 132 → 133 Source Review
## For Alex — 2026-09-27 20:31 EDT

### Patch Files
- patch-132.zip SHA-256: 3130743d3b05224ec70c48a3e635cfc16a47e5377baafa929340d1d7f63c3e33
- patch-133.zip SHA-256: b890e982368822d92f6ef196e07ba6b13c9d14131e1871f0295ae5fe1d113ba7

### Microbot API / Build Environment
- Base: microbot-2.6.18.jar (official nightly release)
- JDK: 17.0.20.1+1 (~/workspace/jdk/jdk-17.0.20.1+1)
- Lombok: ~/workspace/lombok.jar
- Compile: javac -encoding UTF-8 -cp microbot-base.jar:lombok.jar
- Package: zip (never jar cf — jar injects MANIFEST.MF that breaks Check-Update.ps1)
- API model: net.runelite.client.plugins.microbot.util.* (2.6.18 uses api.* model packages)

### Startup Banner Mapping
- Build 132: "Build 132 - 540 SKIP REDO. Alex 2026-09-27 20:22: ..."
- Build 133: "Build 133 - 540 POLL-BOOTH GUARD. Alex 2026-09-27 20:27: ..."

### Build 132 → 133 Diff (the bankPollBoothDone guard)

Build 132's 540 substate (INCOMPLETE):
```java
if (bv != null && bv == 540) {
    diag("Build 132 SUBSTATE: VARP 540 = EXIT_ACCOUNT_GUIDE_ROOM...");
    accountGuideDone = true;
    bankOpened = true;
    bankClosed = true;
    // BUG: MISSED bankPollBoothDone -- poll-booth block still ran at 20:27:05
}
```

Build 133's 540 substate (FIXED):
```java
if (bv != null && bv == 540) {
    diag("Build 133 SUBSTATE: VARP 540 = EXIT_ACCOUNT_GUIDE_ROOM. Varp proves Account Guide (530/531/532), bank booth (510), and POLL BOOTH (520) are DONE -- skipping all redo. Going straight to exit.");
    accountGuideDone = true;
    bankOpened = true;
    bankClosed = true;
    bankPollBoothDone = true;  // <-- THE FIX: was missing in 132
}
```

### Poll-Booth Guard Location
File: TutorialIslandScript.java, ~line 5278
```java
if (!bankPollBoothDone) {
    pollRetryTicks++;
    // ... poll-booth click logic ...
    // This block RAN at 20:27:05 on Build 132 because bankPollBoothDone was false
    // Build 133 sets it true in the 540 substate, so this block is skipped
}
```

### 'outsideBank y≤3121' — Can it bypass door crossings?

File: TutorialIslandScript.java, ~line 5312 (in doBank, after poll-booth block)
```java
// Build 86: EXIT VERIFICATION. The bank stage must not complete until
// the player is OBSERVED outside the bank (Julien's principle:
// coordinate-verified, never guessed from NPC proximity).
WorldPoint bpp = Rs2Player.getWorldLocation();
boolean outsideBank = bpp != null && bpp.getY() <= 3121;
if (!outsideBank) {
    bankExitTicks++;
    bankUpStep = 1;
    // ... door handling logic ...
    // If Y is decreasing, we're moving south (good)
    // If stuck, click "Open" on the door
}
```

**Answer to Alex's question:** The `y≤3121` check does NOT bypass door crossings — it VERIFIES them.
- It does not set bankDone=true or advance the stage
- It only checks: "are we outside yet?" (Y ≤ 3121 means south of the bank's south door at y~3125)
- If NOT outside: it runs the door-handling logic (keep door open, step south)
- The stage only completes when varp advances 540→550 (read fresh each tick)
- The coordinate check is a *necessary* condition for exit, not a *sufficient* one for completion

The door-by-door crossing is still required: the bot must physically move from inside (Y > 3121) to outside (Y ≤ 3121) via the door. The check just observes the result.

### State/Tick Dispatch Path
1. `onTick()` → `dialogueTick()` first (dismisses blocking dialogues)
2. `detectStageByVarp()` reads varp 281 → returns Stage (BANK for 540, PRAYER for 550+)
3. `doBank()` or `doPrayer()` based on stage
4. doBank(): 
   a. If varp >= 550 → skip to PRAYER (bankDone=true, resetPrayerFlags)
   b. If varp == 540 → set all done flags (133), fall through to exit logic
   c. If !accountGuideDone → doAccountGuideStep() (skipped at 540)
   d. Booth logic (skipped at 540 via bankOpened=true)
   e. If !bankPollBoothDone → poll-booth logic (skipped at 540 via 133 fix)
   f. Exit/door logic: check outsideBank, handle door, step south

### Files Included
- TutorialIslandScript.java (279KB, main state machine)
- TutorialIslandPlugin.java (plugin entry point)
- TutorialIslandConfig.java (config interface)
- WorldModel.java (30KB, widget/NPC caching)

No credentials, tokens, or personal files included.
