package net.runelite.client.plugins.microbot.tutorialisland;

import net.runelite.client.config.Config;
import net.runelite.client.config.ConfigGroup;
import net.runelite.client.config.ConfigItem;

@ConfigGroup("tutorialisland")
public interface TutorialIslandConfig extends Config {

    @ConfigItem(
            keyName = "tickDelay",
            name = "Tick delay (ms)",
            description = "Delay between state machine ticks",
            position = 0
    )
    default int tickDelay() {
        return 600;
    }
}
