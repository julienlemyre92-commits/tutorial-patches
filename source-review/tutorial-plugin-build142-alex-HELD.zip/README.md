# Build 142 — Walkthrough Fix — For Alex (HELD, NOT SHIPPED)
## 2026-09-27 21:14 EDT

### Status: HELD
Compiled and marker-verified, but NOT uploaded to the repo.
No patch-142.zip, version.txt remains at 141.
Held per Alex's instruction until 141 runtime is reviewed.

### Fixes vs 141 source
1. **No-adjacent is a REAL rejection** (lines ~3589-3590):
   ```java
   WorldPoint adjFilter = findReachableAdjacentTile(dt, playerPos);
   if (adjFilter == null) continue;
   ```
   This is in the actual selection loop, BEFORE `best = c` is assigned.
   141 only logged SKIP(no-adjacent) in the diagnostic string but still selected.

2. **WALKTHROUGH logs FAILED on crossed=false** (not success):
   Logs "WALKTHROUGH FAILED strict crossing" and marks tried.
   Does not claim success when strict verification fails.

3. **Open-door requires traversable=true**:
   `onDoor` (standing on tile) is now corroborating evidence only, not sufficient.
   Gate is `if (traversable)` with fresh Rs2Tile.isTileReachable() check.

### Build info
- Marker: "Build 142 - WALKTHROUGH FIX" (verified via strings)
- Classes: net.runelite.client.plugins.microbot.tutorialisland.{TutorialIslandScript,TutorialIslandPlugin,TutorialIslandConfig,WorldModel}
- Compiled with JDK 17 against microbot-base.jar + lombok.jar
- Agent script excluded per Build 112/114 precedent
