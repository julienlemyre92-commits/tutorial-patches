# Build 163 — WALK DONOT WAIT — For Alex
## 2026-09-27 23:01 EDT

### Status: SHIPPED (not yet loaded)
Patch: patches/patch-163.zip
SHA-256: 424856dc1eecbbb6d415fadbeac5e6a314f788313e0500aced8cf33184aeab5c
version.txt = 163
Marker: "Build 163 - WALK DONOT WAIT" (verified via strings)

### Fix (Alex 23:00)

hasAnyDoorNearby deadlock: after candidate selection rejected all doors
(e.g., completed, north, no-adjacent), hasAnyDoorNearby still returned true
if ANY door was within 10 tiles, causing the handler to wait forever.

Fix: if findSouthBlockingDoor returns null (no eligible south blocker),
return false immediately -- walk south. The door will be picked up on a
later tick if it becomes relevant. Don't wait merely because an object
is nearby.

Keeps: 162 no-oscillation, 161 directed doors, 160 liveness.

### Status
Loaded: Build 161 (oscillating on 1512). Available: 163 (162, 163 queued).
Awaiting 163 banner. Priority: walk south to Brace, no waiting on irrelevant doors.
