# Build 159 — VARP NEXT-ACTION — For Alex
## 2026-09-27 22:52 EDT

### Status: SHIPPED (not yet loaded)
Patch: patches/patch-159.zip
SHA-256: 227fa7d4c66b4a121f42285be354954eaaac5d238cc4296eb019102cfe73eb9c
version.txt = 159
Marker: "Build 159 - VARP NEXT-ACTION" (verified via strings)

### Fixes (Alex's urgent review)

CRITICAL: varp281 = NEXT REQUIRED action, not completed.
158 marked steps done when varp REACHED them (skipping the action).

PRAYER (step done when varp moves PAST):
- Brace1 >= 560, Prayer tab >= 570, Brace2 >= 580,
  Friends >= 600, Brace3 >= 610, prayerDone >= 620

MAGIC (step done when varp moves PAST):
- Talk1 >= 630, Spellbook >= 640, Talk2 >= 650,
  Cast >= 670, Teleport >= 1000

Plus:
- Chapel exit movement owner at varp 610 (walk south 6 tiles)
- Cast verified by varp 650->670 (not animation idle)
- Bounded retry while varp=650 persists
- Departure dialogue performed at 670 (not pre-completed)

Keeps: 157 walkTo(x,0), NPC wrapper, Quest Guide option scope.

### Status
Loaded: Build 157. Available: 159.
Awaiting 159 banner. Priority: movement to Brace, verified state progress.
