# Build 160 — NONBLOCKING WALK+LIVENESS — For Alex
## 2026-09-27 22:55 EDT

### Status: SHIPPED (not yet loaded)
Patch: patches/patch-160.zip
SHA-256: 6dc98d7fce101f4cd5d518982f8d69f059b8f5f413ef5742035fa2a0a7965804
version.txt = 160
Marker: "Build 160 - NONBLOCKING WALK+LIVENESS" (verified via strings)

### Fixes

1. **Non-blocking walk**: Replaced all three blocking walkTo(x,0) calls
   (door approach, walkthrough, chapel exit) with Rs2Walker.walkStep(x,0).
   - walkStep returns WalkerState {UNREACHABLE, MOVING, ARRIVED, EXIT}
   - One movement step per tick, no 82s stalls
   - WalkerState logged every 20 ticks
   - setTarget(null, "tutorial-door-reset") on UNREACHABLE/EXIT and phase exit

2. **610 chapel exit**: Now uses door-owned handleDoorRouteTick(PRAYER_EXIT)
   before walkStep, so chapel doors get explicit handling.

3. **670 departure**: Retry conversation while varp=670 persists.
   Only varp>=1000 confirms departure. No more infinite wait.

4. **Cast verification**: Removed animation-idle fallback. Varp-only truth.
   Bounded retry while varp=650 persists.

Keeps: 159 varp-next-action thresholds, NPC wrapper, Quest Guide scope.

### Status
Loaded: Build 157 (frozen on walkTo 82s stalls). Available: 160.
Awaiting 160 banner. Priority: movement from bank door toward Brace.
