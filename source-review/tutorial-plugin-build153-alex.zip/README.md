# Build 153 — ADJACENT READY — For Alex
## 2026-09-27 21:59 EDT

### Status: SHIPPED (not yet loaded)
Patch: patches/patch-153.zip
SHA-256: 864e64c1a2231797034e4ddbcab33bfca0a4b830ada41687605f2b2e9798d4d9
version.txt = 153
Marker: "Build 153 - ADJACENT READY" (verified via strings)

### Fix (Alex 21:55:07 analysis + Bumbaa's safeguard)

Build 152's no-self-target filter wrongly rejected door 9722@(3130,3124)
as SKIP(no-adjacent) because the player's own tile (3129,3124) IS the
west-adjacent tile. The bot then picked 9721 and looped WALKER-LIED.

153 adds isPlayerAdjacentToDoor(): if player is already adjacent to the
door (Manhattan distance=1), that's "ready to interact" — valid for
selection AND triggers the click path directly, not a walk.

- Door selection: alreadyAdj ? playerPos : findReachableAdjacentTile(...)
- handleDoorRouteTick: readyToClick skips the walk, goes to click

### Status
Loaded: Build 152 (banner 21:50:23). Available: 153.
Player at (3129,3124), varp 550. Awaiting 153 banner + click on 9722
from current tile + eastward X progress.
