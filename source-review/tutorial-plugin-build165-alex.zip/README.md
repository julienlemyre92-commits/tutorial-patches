# Build 165 — SOUTH OR NOTHING — For Alex
## 2026-09-27 23:07 EDT

### Status: SHIPPED (not yet loaded)
Patch: patches/patch-165.zip
SHA-256: d69acd7e344c68d8e3d623a7d27cd2a512bbf694ef1d744d64edd5d8fca4b40a
version.txt = 165
Marker: "Build 165 - SOUTH OR NOTHING" (verified via strings)

### Fix (Alex 23:06)

Route regression: 163 crossed 1511 SOUTH (3122,3119->3121,3117), then at
23:04:58 selected 1516@3121,3119 BEHIND the player (2 tiles north).
The selector's y<=playerY+2 tolerance admitted it as a "south blocker",
dragging the bot back toward the doorway.

Fix:
- New field bankExitedSouth (boolean).
- Set true on CONFIRMED southward door crossing (CLICK and WALKTHROUGH paths):
  if playerPos.getY() < crossRef.getY().
- In findSouthBlockingDoor: when bankExitedSouth=true, reject ALL doors with
  dt.getY() > playerPos.getY() (zero north tolerance). Logging updated.
- Route now advances south to Brace, never cycles adjacent bank doors.

Also notes 1512->1511 door ID transformation: completion is now also tracked
via south-exit flag, not solely by door ID.

Keeps: 163 walk-dont-wait, 162 no-oscillation, 161 directed doors.

### Status
Loaded: Build 163 (on lawn, regressing north). Available: 165.
Awaiting 165 banner. Acceptance: leave bank-front lawn toward chapel (Y<3115),
then varp 560 after Brace.
