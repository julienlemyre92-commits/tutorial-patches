# Build 156 — WALKTHROUGH RETRY — For Alex
## 2026-09-27 22:44 EDT

### Status: SHIPPED (not yet loaded)
Patch: patches/patch-156.zip
SHA-256: 7be667fd2e603b9762350d11ad3ba4292e7422db45f52fb41cc5699c1936c615
version.txt = 156
Marker: "Build 156 - WALKTHROUGH RETRY" (verified via strings)

### Root cause (from 155 live evidence)

Build 155's walkthrough to (3132,3124) failed with ZERO tile movement
for 4 ticks. Player stuck ON door tile (3130,3124).

The 'door disappeared' gate is a FALSE POSITIVE when the player stands
on the door's tile -- the object query can't see the door under the
player, so it reports "gone" even if still closed. traversable=true is
trivially true (player is standing there).

The door is likely still CLOSED. 155 parked it after ONE attempt.

### Fix

1. WALKTHROUGH failure now RETRIES the Open+walk cycle up to 3 times
   per door (re-click Open from adjacent) instead of parking after one
2. Log Rs2Walker.walkTo() boolean result and Rs2Tile.isWalkable(farSide)
   for diagnostics
3. Only park in blockedDoorIds after 3 failed cycles
4. Attempt counter resets on successful crossing or new situation

Keeps Build 155 - WALKTHROUGH BYPASS.

### Status
Loaded: Build 155 (holding BLOCKED at 3130,3124). Available: 156.
Awaiting 156 banner + Open retry + east movement to x>3130.
