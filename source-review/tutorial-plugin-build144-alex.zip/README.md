# Build 144 — Walk Stall + Doorway Transit — For Alex
## 2026-09-27 21:23 EDT

### Status
This is the build the bot was running when it CROSSED the door (Julien confirmed 21:23 EDT).
Patch: patches/patch-144.zip
SHA-256: 867f996f75d0f8616448a09c88a4fb5b37e804ebd0056eda90ef89553e61c689
version.txt was 144 at crossing time (145 shipped after).
Marker: "Build 144 - WALK STALL+DORWAY" (verified via strings)
Classes: net.runelite.client.plugins.microbot.tutorialisland.{TutorialIslandScript,TutorialIslandPlugin,TutorialIslandConfig,WorldModel}
Compiled: JDK 17, clean, agent excluded

### Changes vs 143
1. Walk stall detection: if Rs2Walker.walkTo() issued for same target 5+ ticks
   with zero player movement, fall back to direct door click. The walker's
   pathfinding was blocked (isTileReachable true but no path via fence collision).

2. Doorway transit required: WALKTHROUGH tracks walkthroughMinDoorDist every tick.
   CROSSED requires far-side OK AND minDist <= 1 (walk-around-fence rejected).

### Runtime context at crossing
- Player was at (3133,3124), door 9722 at (3130,3124)
- 144's walkthrough fired when door opened, walked to far side (3130,3122)
- Julien confirmed: "It crossed btw it's just need to go the church"
- Bot now heading south to Brother Brace (chapel)

### Relevant code sections
- findSouthBlockingDoor(): ~line 3570 (candidate selection with no-adjacent filter)
- verifyWalkthroughFarSide(): ~line 3700 (far-side arrival check)
- verifyDoorCrossing(): ~line 3662 (strict, for small click verifications)
- WALKTHROUGH phase (pendingPhase=4): ~line 3300
- APPROACH phase with stall detection: ~line 3210
