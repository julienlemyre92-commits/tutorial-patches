# Build 141 — Walkthrough — For Alex
## 2026-09-27 21:08 EDT

### Fixes your Build 140 runtime findings (21:03:17-21:04:43)
1. **WALKTHROUGH phase (phase 4)**: When the clicked door disappears
   (findDoorByIdTile returns null in CLICKED phase), check if the doorway
   tile is traversable via Rs2Tile.isTileReachable() or if player is already
   on the door tile. If open: walk through to far side (doorY-2, south)
   instead of treating as failure and replanning. Fixes 140's "door gone =
   replan" trap that you identified at 21:03:55.
2. **Candidate logging**: findSouthBlockingDoor now logs every candidate
   with name, ID, tile, and decision (SKIP(tried), SKIP(north), SKIP(no-adjacent),
   OK(adj=...)). This will show why 9721 and 1535 are rejected.

### Investigated but not changed
- 9721 at (3125,3124) with adjacent=null: player at (3130,3124) is 5 tiles
  away; adjacent tiles may be walls/fence. Candidate log will confirm.
- Object 1535 at (3124,3126): north of player, passes Y filter (+2 tolerance)
  but likely not a south-blocking door. May need tighter Y filter if log
  shows it being selected.

### Artifacts
- patch-141.zip SHA-256: 698661fc3900c9047f4b4d789f8cf62bc8eaa27093c7564fa9dbcab6c6370cb1
- version.txt: 141
- Marker: "Build 141 - WALKTHROUGH" (verified via strings)

### Status
141 shipped, not yet running. 140 runtime (21:03:17-21:04:43) is the baseline:
door 9722 clicked Open at 21:03:55, disappeared, handler replanned instead of
walking through. 9721 and 1535 both had no reachable adjacent.
