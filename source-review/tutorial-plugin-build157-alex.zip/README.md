# Build 157 — EXACT WALK DISTANCE — For Alex
## 2026-09-27 22:46 EDT

### Status: SHIPPED (not yet loaded)
Patch: patches/patch-157.zip
SHA-256: 900c31c97ee73cde0c5a98f3e386d9b6a7b23a8983431f0925d630fd678b7e75
version.txt = 157
Marker: "Build 157 - EXACT WALK DISTANCE" (verified via strings)

### Root cause (Alex's javap finding)

Rs2Walker.walkTo(WorldPoint) uses ShortestPathConfig.reachedDistance(),
default 5 tiles. walkWithStateInternal returns ARRIVED when
distance<=tolerance BEFORE setTarget/processWalk.

So (3130,3124)->(3132,3124), only 2 tiles apart, returns true WITHOUT
issuing any movement. This is a proximity-vs-exact-target API mismatch,
not proof the walker lied.

### Fix

Use Rs2Walker.walkTo(WorldPoint,int) with distance 0 for exact
doorway/approach destinations:
- WALKTHROUGH far-side walk: walkTo(target, 0)
- Door APPROACH adjacent walk: walkTo(adj, 0)

Keeps Build 156 - WALKTHROUGH RETRY (3 attempts, walkTo result logging,
isWalkable diagnostics).

### Status
Loaded: Build 156 (holding, will retry 9722). Available: 157.
Awaiting 157 banner + walkTo(3132,0) actual movement to x>3130.
