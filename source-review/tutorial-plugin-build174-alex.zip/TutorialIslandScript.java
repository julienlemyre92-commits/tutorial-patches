package net.runelite.client.plugins.microbot.tutorialisland;

import net.runelite.api.Actor;
import net.runelite.api.MenuAction;
import net.runelite.api.NPC;
import net.runelite.api.coords.WorldPoint;
import net.runelite.api.widgets.Widget;
import net.runelite.client.plugins.microbot.util.menu.NewMenuEntry;
import net.runelite.client.plugins.microbot.util.misc.Rs2UiHelper;
import net.runelite.client.plugins.microbot.Microbot;
import net.runelite.client.plugins.microbot.api.npc.models.Rs2NpcModel;
import net.runelite.client.plugins.microbot.api.tileobject.models.Rs2TileObjectModel;
import net.runelite.client.plugins.microbot.util.gameobject.Rs2GameObject;
import net.runelite.client.plugins.microbot.globval.enums.InterfaceTab;
import net.runelite.client.plugins.microbot.statemachine.StateMachineScript;
import net.runelite.client.plugins.microbot.statemachine.Transition;
import net.runelite.client.plugins.microbot.util.Global;
import net.runelite.client.plugins.microbot.util.bank.Rs2Bank;
import net.runelite.client.plugins.microbot.util.camera.Rs2Camera;
import net.runelite.client.plugins.microbot.util.dialogues.Rs2Dialogue;
import net.runelite.client.plugins.microbot.util.equipment.Rs2Equipment;
import net.runelite.client.plugins.microbot.util.inventory.Rs2Inventory;
import net.runelite.client.plugins.microbot.util.keyboard.Rs2Keyboard;
import net.runelite.client.plugins.microbot.util.magic.Rs2Magic;
import net.runelite.client.plugins.microbot.util.walker.WalkerState;
import net.runelite.client.plugins.microbot.util.walker.Rs2Walker;
import net.runelite.client.plugins.microbot.util.player.Rs2Player;
import net.runelite.client.plugins.microbot.util.tabs.Rs2Tab;
import net.runelite.client.plugins.microbot.util.tile.Rs2Tile;
import net.runelite.client.plugins.microbot.util.walker.Rs2Walker;
import net.runelite.client.plugins.microbot.util.walker.WalkerState;
import net.runelite.client.plugins.microbot.util.widget.Rs2Widget;
import net.runelite.client.plugins.skillcalculator.skills.MagicAction;

import java.awt.event.KeyEvent;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;
import javax.imageio.ImageIO;
import java.util.concurrent.TimeoutException;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.time.LocalTime;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * Automates Tutorial Island start to finish on a fresh account.
 * <p>
 * State machine: each state performs one tutorial section, then a guarded
 * transition moves to the next. On startup, completed sections auto-skip by
 * detecting which instructor is nearby, so the plugin can be re-enabled
 * mid-tutorial (e.g. after answering the Ironman prompt by hand).
 */
public class TutorialIslandScript extends StateMachineScript<TutorialIslandScript.Stage> {
    // Explicit logger (what lombok @Slf4j would generate; the workspace
    // lombok.jar is a shadow jar whose annotation processor cannot run).
    private static final org.slf4j.Logger log =
            org.slf4j.LoggerFactory.getLogger(TutorialIslandScript.class);

    enum Stage {
        CHAR_CREATOR,
        GUIDE,
        SURVIVAL,
        CHEF,
        QUEST_GUIDE,
        MINING,
        COMBAT,
        BANK,
        PRAYER,
        MAGIC,
        DONE
    }

    private TutorialIslandConfig config;
    private volatile boolean pausedForManual = false;
    private volatile boolean startDetected = false;
    private volatile Stage startStage = Stage.CHAR_CREATOR;
    private int detectionTicks = 0;
    private long lastStepBackMs = 0;
    private Stage lastDiagState = null;

    // ------------------------------------------------------------------
    // Black-box recorder: plain-English diagnostics, also written to
    // %USERPROFILE%/.runelite/tutorial-island-diag.log so the user can
    // paste the tail of it into chat instead of taking screenshots.
    // ------------------------------------------------------------------
    private static final String DIAG_PATH =
            System.getProperty("user.home") + "/.runelite/tutorial-island-diag.log";

    // In-memory tail of recent diag lines, uploaded to GitHub alongside each
    // auto-screenshot so the reviewer can see the state machine without
    // asking the user to paste the log.
    private static final int DIAG_TAIL_MAX = 250;
    private static final java.util.Deque<String> diagTail = new java.util.ArrayDeque<>();

    private static synchronized void diag(String msg) {
        String line = LocalTime.now().truncatedTo(ChronoUnit.SECONDS) + "  " + msg;
        log.info("[TutorialIsland] {}", msg);
        diagTail.addLast(line);
        while (diagTail.size() > DIAG_TAIL_MAX) diagTail.removeFirst();
        try {
            Files.write(Paths.get(DIAG_PATH),
                    (line + System.lineSeparator()).getBytes(StandardCharsets.UTF_8),
                    StandardOpenOption.CREATE, StandardOpenOption.APPEND);
        } catch (Exception ignored) {
        }
    }

    private static synchronized void diagClear() {
        try {
            Files.write(Paths.get(DIAG_PATH),
                    ("=== Tutorial Island run started "
                            + LocalTime.now().truncatedTo(ChronoUnit.SECONDS)
                            + " ===" + System.lineSeparator()).getBytes(StandardCharsets.UTF_8),
                    StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
        } catch (Exception ignored) {
        }
    }
    /** Ticks to wait for the NPC cache before giving up on auto-detect (~36s). */
    private static final int DETECTION_TIMEOUT_TICKS = 60;

    private boolean charCreatorDone;
    private boolean guideDone;
    private boolean survivalDone;
    private boolean chefDone;
    private boolean breadBaked; // Set after baking, persists for session
    private boolean questGuideDone;
    private int questGuideTalkStuckCount = 0;
    private boolean questTabClicked = false;
    private boolean miningDone;
    private boolean miningTalked = false;
    private boolean daggerInstructorTalked = false;
    private boolean combatDone;
    private boolean bankDone;
    private boolean prayerDone;
    private boolean magicDone;
    // Set after the equipment stats button is clicked; next step is dagger.
    private boolean statsButtonClicked = false;
    // Screenshot automation: save to bundle/screenshots/ for GitHub upload.
    private long lastScreenshotMs = 0;
    private static final long SCREENSHOT_INTERVAL_MS = 60000; // Build 82: 1 min (was 2 min) per Julien request for better visibility // 2 min
    private long lastUpdateCheckMs = 0;
    private static final long UPDATE_CHECK_INTERVAL_MS = 60000; // 1 min (reverted from 164 API hold)
    // Build 76: tab-bar recovery. Julien's client stopped rendering the
    // in-game tab buttons (~13:35 2026-09-27: the tab row shows blank stone
    // bricks, widget lookups find nothing), hard-stucking every clickTabIcon
    // caller. After a few consecutive widget misses, fall back to the client's
    // own tab-switch script (915), which needs no visible button.
    private final java.util.Map<InterfaceTab, Integer> tabClickMisses = new java.util.EnumMap<>(InterfaceTab.class);
    private final java.util.Map<InterfaceTab, Integer> tabScriptFallbacks = new java.util.EnumMap<>(InterfaceTab.class);
    // Build 127: cached one-line summary of the last all-roots tab scan, re-diag'd
    // on every fallback so it survives the 250-line diag tail (the PRAYER loop logs
    // ~6 lines/sec -> ~40s window < 60s upload interval; Build 125's scan output
    // scrolled out before the next upload and was lost).
    private volatile String lastTabScanSummary = null;
    private static final int TAB_SWITCH_CLIENT_SCRIPT = 915;
    private static final int TAB_MISS_FALLBACK_AFTER = 3;
    // Fallback only. The real "current version" is read from bundle/patch-version.txt
    // (written by Check-Update.ps1), which is the single source of truth shared
    // with the Supervisor. A hardcoded constant went stale in Build 66 (said 65
    // while 66 was applied) and caused an infinite update/exit/relaunch loop.
    private int currentPatchVersion = 80;
    // Build 164 HELD (Alex 23:06): API version oracle staged, NOT active.
    // Both plugin and Supervisor must use the same oracle before API-triggered
    // exits, or we get quit/relaunch-old-build loops. Reverting to raw CDN.
    private static final String VERSION_URL =
        "https://raw.githubusercontent.com/julienlemyre92-commits/tutorial-patches/main/version.txt";

    /**
     * Saves a screenshot to bundle/screenshots/ for the auto-uploader.
     * Filename: yyyy-MM-dd_HH-mm-ss_STAGE_reason.png
     */
    private void saveScreenshot(String reason) {
        try {
            String jarPath = TutorialIslandScript.class.getProtectionDomain()
                .getCodeSource().getLocation().toURI().getPath();
            File bundleDir = new File(jarPath).getParentFile();
            File shotsDir = new File(bundleDir, "screenshots");
            shotsDir.mkdirs();

            String ts = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss").format(new Date());
            String stage;
            try {
                stage = getCurrentState() != null ? getCurrentState().name() : "UNKNOWN";
            } catch (Exception e) {
                stage = "UNKNOWN";
            }
            String fname = ts + "_" + stage + "_" + reason + ".png";
            // Sanitize filename
            fname = fname.replaceAll("[^a-zA-Z0-9._-]", "_");

            Rectangle screenRect = new Rectangle(Toolkit.getDefaultToolkit().getScreenSize());
            BufferedImage capture = new Robot().createScreenCapture(screenRect);
            ImageIO.write(capture, "png", new File(shotsDir, fname));
            diag("Screenshot saved: " + fname);
            // Build 82: auto-cleanup old screenshots (Julien's request).
            cleanupOldScreenshots(shotsDir);
            // Julien's request: also push the diag tail to GitHub so the
            // reviewer can diagnose without asking for a log paste.
            uploadDiagTailAsync(bundleDir, ts, stage);
        } catch (Exception e) {
            diag("Screenshot failed: " + e.getMessage());
        }
    }

    /**
     * Uploads the recent diag lines to GitHub as screenshots/{ts}_{stage}_diag.txt
     * using the token from bundle/github-token.txt (same one the screenshot
     * uploader uses). Fire-and-forget on a daemon thread — never blocks the tick.
     */
    private void uploadDiagTailAsync(File bundleDir, String ts, String stage) {
        final String lines;
        synchronized (TutorialIslandScript.class) {
            lines = String.join(System.lineSeparator(), diagTail);
        }
        if (lines.isEmpty()) return;
        Thread t = new Thread(() -> {
            try {
                File tokenFile = new File(bundleDir, "github-token.txt");
                if (!tokenFile.isFile()) {
                    diag("Diag upload skipped: no github-token.txt in bundle");
                    return;
                }
                String token = new String(Files.readAllBytes(tokenFile.toPath()),
                        StandardCharsets.UTF_8).trim();
                if (token.isEmpty()) return;
                String b64 = java.util.Base64.getEncoder().encodeToString(
                        lines.getBytes(StandardCharsets.UTF_8));
                String fname = (ts + "_" + stage + "_diag.txt")
                        .replaceAll("[^a-zA-Z0-9._-]", "_");
                String json = "{\"message\":" + jsonQuote("Diag tail " + fname)
                        + ",\"content\":" + jsonQuote(b64) + "}";
                java.net.URL url = new java.net.URL(
                        "https://api.github.com/repos/julienlemyre92-commits/tutorial-patches"
                        + "/contents/screenshots/" + fname);
                java.net.HttpURLConnection conn =
                        (java.net.HttpURLConnection) url.openConnection();
                conn.setRequestMethod("PUT");
                conn.setConnectTimeout(10000);
                conn.setReadTimeout(15000);
                conn.setDoOutput(true);
                conn.setRequestProperty("Accept", "application/vnd.github.v3+json");
                conn.setRequestProperty("Authorization", "Bearer " + token);
                conn.setRequestProperty("Content-Type", "application/json");
                byte[] body = json.getBytes(StandardCharsets.UTF_8);
                conn.getOutputStream().write(body);
                int code = conn.getResponseCode();
                if (code == 201 || code == 200) {
                    diag("Diag tail uploaded: " + fname);
                } else {
                    diag("Diag upload failed, HTTP " + code);
                }
            } catch (Exception e) {
                diag("Diag upload failed: " + e.getMessage());
            }
        });
        t.setDaemon(true);
        t.start();
    }

    /** Minimal JSON string escaper for the diag upload payload. */
    private static String jsonQuote(String s) {
        StringBuilder sb = new StringBuilder("\"");
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            switch (c) {
                case '"' -> sb.append("\\\"");
                case '\\' -> sb.append("\\\\");
                case '\n' -> sb.append("\\n");
                case '\r' -> sb.append("\\r");
                case '\t' -> sb.append("\\t");
                default -> {
                    if (c < 0x20) sb.append(String.format("\\u%04x", (int) c));
                    else sb.append(c);
                }
            }
        }
        return sb.append("\"").toString();
    }

    /**
     * Build 78: one-time self-repair of the update pipeline. The
     * raw.githubusercontent.com CDN caches version.txt (~5 min TTL), and
     * Check-Update.ps1 polled it with no cache-buster — it reported a stale
     * "Remote version: 76" for 45+ minutes after 77 was published, so the
     * Supervisor never applied the patch. This adds a per-poll cache-buster
     * to Check-Update.ps1's $versionUrl line. Idempotent (skips if already
     * present), backs up the original once, and never touches anything else
     * in the file. Failures are logged, never fatal.
     */
    private void ensureUpdatePipelineCacheBuster() {
        try {
            String jarPath = TutorialIslandScript.class.getProtectionDomain()
                .getCodeSource().getLocation().toURI().getPath();
            File bundleDir = new File(jarPath).getParentFile();
            File ps1 = new File(bundleDir, "Check-Update.ps1");
            if (!ps1.isFile()) {
                diag("Build 78: Check-Update.ps1 not found next to jar, skipping cache-buster repair");
                return;
            }
            String content = new String(Files.readAllBytes(ps1.toPath()), StandardCharsets.UTF_8);
            if (content.contains("?cb=")) {
                diag("Build 78: Check-Update.ps1 already cache-busted, nothing to do");
                return;
            }
            String oldLine = "$versionUrl = \"https://raw.githubusercontent.com/$repo/main/version.txt\"";
            if (!content.contains(oldLine)) {
                diag("Build 78: Check-Update.ps1 $versionUrl line not in expected form, skipping repair");
                return;
            }
            File bak = new File(bundleDir, "Check-Update.ps1.bak");
            if (!bak.isFile()) {
                Files.copy(ps1.toPath(), bak.toPath());
            }
            // In a PowerShell double-quoted string, $(...) is evaluated per
            // execution, so every poll gets a fresh timestamp -> fresh CDN key.
            String newLine = "$versionUrl = \"https://raw.githubusercontent.com/$repo/main/version.txt?cb=$([DateTimeOffset]::UtcNow.ToUnixTimeSeconds())\"";
            String updated = content.replace(oldLine, newLine);
            if (updated.equals(content)) {
                diag("Build 78: Check-Update.ps1 replacement had no effect, skipping write");
                return;
            }
            Files.write(ps1.toPath(), updated.getBytes(StandardCharsets.UTF_8));
            diag("Build 78: Check-Update.ps1 repaired — versionUrl is now cache-busted per poll (original backed up to Check-Update.ps1.bak)");
        } catch (Exception e) {
            diag("Build 78: Check-Update.ps1 repair failed (non-fatal): " + e);
        }
    }

    /**
     * Build 79: one-time self-repair so the Supervisor clears the RuneLite
     * cache when the plugin asks for it. The plugin writes a
     * "clear-cache-requested.txt" flag file in the bundle dir when it detects
     * cache corruption (tab bar not rendering after 5 script-switch attempts,
     * "Mismatch in overlaid cache archive hash" errors). This inserts a check
     * at the top of Supervisor.bat: if the flag exists, delete
     * %USERPROFILE%\.runelite\cache and remove the flag, before launching.
     * Idempotent (skips if already present), backs up the original once.
     * Failures are logged, never fatal.
     */
    private void ensureSupervisorCacheClear() {
        try {
            String jarPath = TutorialIslandScript.class.getProtectionDomain()
                .getCodeSource().getLocation().toURI().getPath();
            File bundleDir = new File(jarPath).getParentFile();
            File bat = new File(bundleDir, "Supervisor.bat");
            if (!bat.isFile()) {
                diag("Build 79: Supervisor.bat not found next to jar, skipping cache-clear repair");
                return;
            }
            String content = new String(Files.readAllBytes(bat.toPath()), StandardCharsets.UTF_8);
            if (content.contains("clear-cache-requested.txt")) {
                diag("Build 79: Supervisor.bat already handles cache-clear requests, nothing to do");
                return;
            }
            File bak = new File(bundleDir, "Supervisor.bat.bak");
            if (!bak.isFile()) {
                Files.copy(bat.toPath(), bak.toPath());
            }
            String block =
                "REM Build 79: auto-clear RuneLite cache when the plugin requests it.\r\n" +
                "if exist \"%~dp0clear-cache-requested.txt\" (\r\n" +
                "    echo [TutorialIsland] Plugin requested a RuneLite cache clear - clearing...\r\n" +
                "    rmdir /s /q \"%USERPROFILE%\\.runelite\\cache\" 2>nul\r\n" +
                "    del \"%~dp0clear-cache-requested.txt\" 2>nul\r\n" +
                "    echo [TutorialIsland] Cache cleared.\r\n" +
                ")\r\n";
            String updated;
            if (content.startsWith("@echo off")) {
                updated = "@echo off\r\n" + block + content.substring("@echo off".length());
            } else {
                updated = block + content;
            }
            Files.write(bat.toPath(), updated.getBytes(StandardCharsets.UTF_8));
            diag("Build 79: Supervisor.bat repaired - clears RuneLite cache when the plugin requests it (original backed up to Supervisor.bat.bak)");
        } catch (Exception e) {
            diag("Build 79: Supervisor.bat repair failed (non-fatal): " + e);
        }
    }

    /**
     * Build 79: writes the cache-clear request flag. Called when the plugin
     * detects cache corruption (tab bar not rendering). The Supervisor picks
     * this up on the next launch (see ensureSupervisorCacheClear) and clears
     * the cache while the game is not running — safe, unlike deleting it live.
     */
    private void requestCacheClear(String reason) {
        try {
            String jarPath = TutorialIslandScript.class.getProtectionDomain()
                .getCodeSource().getLocation().toURI().getPath();
            File bundleDir = new File(jarPath).getParentFile();
            File flag = new File(bundleDir, "clear-cache-requested.txt");
            if (flag.isFile()) return; // already requested, don't spam
            Files.write(flag.toPath(),
                ("Requested by Build 79 at " + new java.util.Date() + ": " + reason + "\n")
                .getBytes(StandardCharsets.UTF_8));
            diag("Build 79: cache corruption detected (" + reason + ") - wrote clear-cache-requested.txt, Supervisor will clear the cache on next launch");
        } catch (Exception e) {
            diag("Build 79: failed to write cache-clear flag (non-fatal): " + e);
        }
    }

    /** Call from the main tick: saves a screenshot every 2 minutes.
     *  Build 82: burst recording moved to a background thread (see
     *  startBurst), so this only handles the regular interval. */
    private void maybeAutoScreenshot() {
        long now = System.currentTimeMillis();
        if (now - lastScreenshotMs >= SCREENSHOT_INTERVAL_MS) {
            lastScreenshotMs = now;
            saveScreenshot("auto");
        }
    }

    /**
     * The patch version the Supervisor last applied, read from
     * bundle/patch-version.txt (written by Check-Update.ps1 after each
     * successful apply). This is the single source of truth shared with the
     * Supervisor; the hardcoded currentPatchVersion is only a fallback for
     * dev runs outside the bundle.
     */
    private int getAppliedPatchVersion() {
        try {
            String jarPath = TutorialIslandScript.class.getProtectionDomain()
                .getCodeSource().getLocation().toURI().getPath();
            File bundleDir = new File(jarPath).getParentFile();
            File versionFile = new File(bundleDir, "patch-version.txt");
            if (versionFile.isFile()) {
                String txt = new String(java.nio.file.Files.readAllBytes(versionFile.toPath())).trim();
                return Integer.parseInt(txt);
            }
        } catch (Exception e) {
            // fall through to the fallback constant
        }
        return currentPatchVersion;
    }

    /**
     * Checks GitHub for a newer patch version every 2 min.
     * If found, exits so the Supervisor can apply it and relaunch.
     */
    private void maybeCheckForUpdate() {
        long now = System.currentTimeMillis();
        if (now - lastUpdateCheckMs < UPDATE_CHECK_INTERVAL_MS) return;
        lastUpdateCheckMs = now;
        try {
            // Build 164 HELD: reverted to raw CDN. Both oracles must align
            // before API-triggered exits.
            java.net.URL url = new java.net.URL(
                    VERSION_URL + "?cb=" + System.currentTimeMillis());
            java.net.HttpURLConnection conn = (java.net.HttpURLConnection) url.openConnection();
            conn.setConnectTimeout(10000);
            conn.setReadTimeout(10000);
            try (java.io.BufferedReader br = new java.io.BufferedReader(
                    new java.io.InputStreamReader(conn.getInputStream()))) {
                String line = br.readLine();
                if (line != null) {
                    int remote = Integer.parseInt(line.trim());
                    int local = getAppliedPatchVersion();
                    if (remote > local) {
                        diag("New patch v" + remote + " available (current v" + local + ") - exiting for update");
                        saveScreenshot("update_available");
                        Microbot.status = "Tutorial Island: updating to v" + remote;
                        try { Thread.sleep(2000); } catch (InterruptedException ignored) {}
                        System.exit(0);
                    }
                }
            }
        } catch (Exception e) {
            // Network issues shouldn't kill the bot; just try again next time
        }
    }

    // ------------------------------------------------------------------
    // Framework
    // ------------------------------------------------------------------

    public boolean run(TutorialIslandConfig config) {
        this.config = config;
        diagClear();
        diag("Build 174 - DRAIN BEFORE CAST. Alex 23:45-23:46: 173 flew 630->640->650, then blocked: 'Terrova gives you air/mind runes' + 'Click here to continue' visible, but cast branch (!magicCastDone) went straight to castWindStrikeOnce() without draining dialogue. MAGIC TICK every 6-7s, cast=false, no spell issued. Fix: safeIsInDialogue()->dialogueTick() (171 Continue-first) at cast branch entry, before cast attempt. Runes must be accepted first. Keep varp 650->670 as cast completion. Keeps 173 landmark exit + 172 varp-authoritative.");
        // Build 167 (Alex): NO Y-heuristic restart derivation. Route progress
        // is re-derived from the goal each tick via findDoorOnPathTo, not from
        // RAM flags or Y thresholds.
        diag("Build 160 - NONBLOCKING WALK+LIVENESS. walkStep(WalkerState) replaces blocking walkTo; 610 chapel exit via handleDoorRouteTick; 670 departure retries until varp>=1000; varp-only cast truth. Keeps 159 thresholds.");
        diag("Build 154 - ADJACENT CLICKS. Review loop 2026-09-27: 153 made 9722 selectable but the reachability gates still blocked the click (findReachableAdjacentTile excludes own tile -> 'temporarily unreachable'/'no reachable adjacent' forever). Fix: player-adjacent counts as reachable in the selection-tick walk phase AND the phase-1 APPROACH handler -> direct click on 9722. ");
        diag("Build 153 - ADJACENT READY.  Alex 2026-09-27: Player already adjacent to door = ready to click, not no-adjacent. Bumbaa: valid approach tile means ready to interact. Fixes 9722 SKIP loop. ");
        diag("Build 142 live-check: expecting 'Build 142 DOOR' runtime lines and 9721/1535 never selected while no-adjacent. ");
        diag("Build 133 - 540 POLL-BOOTH GUARD. Alex 2026-09-27 20:27: Build 132 set 3 flags but MISSED bankPollBoothDone -- poll-booth click fired at 20:27:05. Varp 540 means 520 (poll booth) is done. Fix: 540 substate now sets ALL four flags (accountGuideDone, bankOpened, bankClosed, bankPollBoothDone). Exclusive exit substate. Keeps Build 132 - 540 SKIP REDO. ");
        diag("Build 132 - 540 SKIP REDO. Alex 2026-09-27 20:22: at varp=540 bot redid Account Guide (5s timeouts, false 'done') and booth ('I can't reach that!', opened=false) instead of EXIT. Varp 540 PROVES 530/531/532/510/520 are done. Fix: 540 substate sets accountGuideDone/bankOpened/bankClosed=true so doBank skips to exit/door logic. No false completion from timeouts. Keeps Build 131 - EXPLICIT 540 SUBSTATE. ");
        diag("Build 131 - EXPLICIT 540 SUBSTATE. Alex 2026-09-27 20:20: varp=540 is EXIT_ACCOUNT_GUIDE_ROOM (distinct step). Live: 'Click here to continue' dialogue blocks, doors are OPEN. Bot must dismiss dialogue FIRST, then cross door, verify varp 540->550. Keeps Build 130 - NO-PROGRESS GUARD. ");
        diag("Build 130 - NO-PROGRESS GUARD. Alex 2026-09-27 20:15: 20:15:16 diag showed PRAYER with talked1=true, 90x NO VERIFIED TARGET + script-915 while 'Moving on' dialogue blocked. Runtime was in PRAYER but varp=540 requires exit flow. Fix: halt tab retries after 20 failures with clear blocker log. Verified transition, not click attempt. Keeps Build 129 - UNAMBIGUOUS VARP LABELS. ");
        diag("Build 129 - UNAMBIGUOUS VARP LABELS. Alex: stale 'Build 121: varp' strings confused the active build. Now: 'VARP-281' and 'VARP 281 =' with no build number -- the startup banner identifies the build. Keeps Build 128 - CORRECTED VARP THRESHOLD. ");
        diag("Build 128 - CORRECTED VARP THRESHOLD. Alex wiki table: 540=Exit AG room (DO IT, not skip); 550=Talk Brace (PRAYER). Old >=540 skip was wrong. Keeps Build 127 - SCAN DATA-LOSS FIX. ");
        diag("Build 127 - SCAN DATA-LOSS FIX. Live 2026-09-27 20:04 (Build 125): the all-roots tab scan DID fire at fb==4 (~20:00:58, fresh Build-125 session) but its 'Build 125 SCAN:' output scrolled out of the 250-line diag tail (PRAYER loop logs ~6 lines/sec -> ~40s window < 60s upload interval) before the 20:01:51 upload, so the tab-strip location was lost. Fix: (1) re-scan every 10 fallbacks (fb=4,14,24...), (2) cache a one-line SCAN-SUMMARY re-diag'd on EVERY fallback so every uploaded tail carries the group numbers. Keeps Build 126 - RESET PRAYER ON BANK SKIP. ");
        diag("Build 126 - RESET PRAYER ON BANK SKIP. Live 2026-09-27 20:03 (Build 123/124): varp=540 bank-skip set bankDone=true but prayerTalked1=true persisted from the 19:28 run -- doPrayer() skipped 'walk to church' and tab-clicked while outdoors. Julien: 'you have to go through 2 doors in the bank where you did one of them' -- the bot must WALK with door handling, not tab-click. Fix: Build 123 skip now calls resetPrayerFlags() so PRAYER starts fresh and walks south through both doors. Keeps Build 125 - FIND THE TAB STRIP. ");
        diag("Build 125 - FIND THE TAB STRIP. Live 2026-09-27 19:56 (Build 124): the Build 120 widget dump PROVED the visible flashing prayer icon is NOT in groups 548/161/164 -- 548 has 96 children but is hidden=true, 161 and 164 have 0 children. Yet the icon is visibly flashing on screen (screenshot 19:56:38). The client is in resizable mode using a different toplevel (165=ToplevelDisplay? 80? 601?). Fix: when the tab icon misses 4x fallbacks, scanAllRootsForTabs() enumerates EVERY loaded widget root for visible icon-sized widgets -- no more guessing groups. Keeps Build 124 - TIMEOUT IS NOT COMPLETION. ");
        diag("Build 124 - TIMEOUT IS NOT COMPLETION. Live 2026-09-27 19:51 (Build 122): Account Guide Talk-to timed out 2x (19:50:42, 19:50:48, door-blocked), then 19:50:52 logged 'Account Guide done' -- the 150-tick fail-safe marked a FAILED dialogue as complete. Alex: 'Treat dialogue timeout as failure, not completion.' Fix: the 150-tick fail-safe now checks varp 281 -- only marks done if varp>=533 (game confirms step complete); otherwise resets counter for door recovery instead of fake-completing. Keeps Build 123 - VARP-AWARE BANK SKIP. ");
        diag("Build 123 - VARP-AWARE BANK SKIP. Live 2026-09-27 19:50 (Build 122): varp=540 (bank 'exit' step) but bot redid the Account Guide from scratch, getting door-blocked (5s click timeouts on 'Account Guide'). Julien: 'door never been fixeed' -- the door isn't broken, redoing completed steps is. Fix: doBank() reads varp 281 at entry; if >=540 (bank complete), marks bankDone=true immediately and returns -- PRAYER's walk handles the exit door. Keeps Build 122 - CIRCUIT BREAKER FIX. ");
        diag("Build 122 - CIRCUIT BREAKER FIX. Live 2026-09-27 19:46 (Build 121): varp-281 detector WORKED (varp=540 -> BANK, banner confirmed 19:44:53), circuit breaker FIRED at 19:46:35 after 15 booth clicks -- but the bot stayed in BANK! Root cause: the breaker set startStage=PRAYER, but startStage is only read once by initialState(); the state machine transitions BANK->PRAYER when bankDone==true. Fix: breaker now sets bankDone=true to trigger the real transition. Keeps Build 121 - VARP 281 GROUND TRUTH. ");
        diag("Build 121 - VARP 281 GROUND TRUTH. Live 2026-09-27 19:42 (Build 119): bot restarted INSIDE the bank, position-detector saw the booth and returned BANK -- but the game instruction said 'Exit through the door and follow the path to the chapel' (BANK already complete). Bot looped the booth 20+ times (opened=false) for 3min while the game waited for PRAYER. Julien: 'shamefull'. Fix: (1) detectStartStage reads varplayer 281 FIRST -- the game's own tutorial progress counter (OSRS Wiki, via Alex's research) -- mapping 510-540=BANK, 550-610=PRAYER, etc. Position fallback only if varp unreadable. (2) Circuit breaker: 15 booth clicks without opening forces PRAYER. Keeps Build 120 - PRAYER WIDGET DUMP. ");
        diag("Build 120 - PRAYER WIDGET DUMP. Live 2026-09-27 19:38 (Build 118/119): PRAYER tab icon INVISIBLE -- packed 548:69/161:64/164:64 all null AND WorldModel name-match finds nothing (age=MAX). Bot looped 'NO VERIFIED TARGET' + script-915 (attempts 24-38) with talked1=true tab=false. Alex's independent review: 'capture the actual client/widget layout'. Fix: when a tab icon misses 3x script fallbacks, dump ALL widgets in groups 548/161/164 (children 0-150) with name/actions/bounds/hidden to the diag -- no more guessing IDs. Keeps Build 119 - CHAPEL DOOR HANG FIX. ");
        diag("Build 119 - CHAPEL DOOR HANG FIX. Live 2026-09-27 19:28-19:32 (Build 118): bot reached the church (y<=3115) for the PRAYER stage, but Brother Brace is behind the chapel door -- talkToOnce's npc.click('Talk-to') HUNG the tick thread for 4min (auto-walk loops on 'recovery_target_walled'), and Julien saw it 'stuck at the door repeating actions'. Fix: (1) npc.click now runs with a 5s timeout via CompletableFuture so the tick ALWAYS survives; (2) if 3+ talk attempts produce no dialog, assume a closed door is blocking and clickDoorDirect('Open') before retrying. Keeps Build 118 - CHURCH NOT BANK. ");
        diag("Build 118 - CHURCH NOT BANK. Live 2026-09-27 19:19 (Build 117): client restarted with the character INSIDE the chapel ('speak to Brother Brace' instruction on screen), but detectStartStage returned BANK — the Banker's 40-tile radius reaches the church (~20 tiles away) and was checked BEFORE Brother Brace, so the bot redid the Account Guide (Julien saw the friends tab open) and bank booth while the game waited for the chapel step. Fix: Brother Brace within 20 tiles now returns PRAYER before the Banker check; the bank-booth-within-10 check still covers genuinely being inside the bank room. Keeps Build 117 - BOTTOM-LINE TAB ICONS. ");
        diag("Build 117 - BOTTOM-LINE TAB ICONS (group 164). Live 2026-09-27 19:09 (Build 116): PRAYER flashing-icon prompt STILL looped — packed 548:69/161:64 null AND Build 116's name-match scan of groups 548+161 found nothing. Root cause: Julien's client runs the resizable BOTTOM-LINE layout — tab icons live in group 164 (RuneLite WidgetInfo RESIZABLE_VIEWPORT_BOTTOM_LINE_*_ICON, verified against WidgetInfo bytecode: prayer = 164:64), a group the bot never scanned. Fix: name-match scan + packed ID lists now cover all three layouts (548 fixed, 161 resizable-side, 164 bottom-line); group-164 icons accepted when the official-WidgetInfo-mapped widget exists, is visible and icon-sized (logged), never a blind derived child. Keeps Build 116 - VERIFIED TAB TARGETS. ");
        diag("Build 116 - VERIFIED TAB TARGETS FOR ALL TABS. Live 2026-09-27 19:00 (Build 115): PRAYER flashing-icon prompt looped — packed 548:69/161:64 never resolved in the WorldModel cache, so the forced physical click never fired and the script-915 fallback looped without setting the game's tutorial flag. Root cause: packed IDs are sequence-derived, never verified against the widget tree (same trap as ACC_MAN 548:72 in Build 115). Fix: WorldModel now name-matches EVERY tab icon on GameTick (groups 548/161, smallest match wins); clickTabIcon uses the verified target for all tabs (fresh name-matched bounds, else name-verified packed bounds), never a blind derived child. Keeps Build 115 - VERIFIED ACC_MAN TARGET + BOOTH PROXIMITY GATE. ");
        diag("Build 115 - VERIFIED ACC_MAN TARGET + BOOTH PROXIMITY GATE. Live 2026-09-27 18:45: 15+ physical clicks at packed 548:72 bounds (576,186) never advanced the tutorial (Build 113 live 18:42:20, loop 18:42:53-18:44:38) — the 548:72/161:67 IDs were derived by sequence-continuation (varc index 8), NEVER verified against the widget tree. Fix: clickTabIcon(ACC_MAN) now uses a VERIFIED target — prefers the tree-anchored name-matched bounds (fresh <10s), else the packed bounds only if the sampled widget NAME contains 'account'; logs packed name+bounds and name-matched bounds+age on EVERY click so the diag proves the target (never a blind derived child). Also: booth 'I can't reach that!' (seen in 18:44:41 screenshot) — Build 109's text-based recovery never fired, so clickBoothDirect now has a PROXIMITY GATE: if the player is >4 tiles from the booth, walk adjacent FIRST instead of clicking (text-independent). Keeps Build 114 - FORCED PHYSICAL TAB CLICK.");
        diag("Build 114 - FORCED PHYSICAL TAB CLICK. Live 2026-09-27 18:45: root cause of the 18:35-18:39 booth loop (click booth -> 'Click on the flashing icon to open your Account Management menu' -> click icon -> click booth, opened=false): clickTabIcon's isTabCurrent() fast path SILENTLY returned true when the account panel was already open (opened via the script-915 fallback in an earlier build), so the game's flashing-icon tutorial flag was never set and the physical click NEVER happened — no 'MOUSE CLICKED ACC_MAN' line was ever logged across ~48 booth clicks. Build 113's ACC_MAN packed IDs were correct but never reached because of this fast path. Fix: clickTabIcon(tab, forcePhysical) overload; every tutorial 'flashing icon' prompt (account, quests, prayer, magic, combat, equipment, settings, dagger-inventory, generic tab branch, account-guide step) now bypasses the fast path and always performs the real mouse click. Operational switches (open inventory to wield) keep the fast path. Keeps Build 113 - ACC_MAN PHYSICAL CLICK. Live 2026-09-27 18:36: root cause of the 18:32-18:34 booth loop (click booth -> 'Click on the flashing icon to open your Account Management menu' -> click icon -> click booth, opened=false): clickTabIcon(ACC_MAN) had NO case in its packed-ID switch (ids stayed null) and WorldModel never sampled the account icon, so the flashing icon was NEVER physically clicked. The script-915 fallback opens the tab panel but does not set the game's 'clicked the flashing icon' tutorial flag, so the Account Guide step never truly completes. Fix: ACC_MAN packed IDs 548:72 / 161:67 (varc index 8) sampled in WorldModel, plus a per-tick name-matched fallback (widget name/actions containing 'account'). Keeps Build 112 - SINGLE SCRIPT FIX. Live 2026-09-27 18:28: patch 111 shipped with TWO competing scripts (TutorialIslandScript + TutorialIslandAgentScript) in the same jar — bot went silent for 13+ min after downloading it, no screenshots, likely startup conflict. This build removes the agent, plugin injects the single TutorialIslandScript again. Keeps Build 110 - ACCOUNT GUIDE FIRST. Live 2026-09-27 18:08: fresh run looped the bank booth forever (click booth -> the game re-popped the 'Account (Management)' instruction dialog: 'The guide here will tell you all about your account. Just click on him to hear what he's got to say.' -> dismiss -> click booth, opened=false) because the bot tried to open the bank BEFORE talking to the Account Guide. Live proof the official order is Account Guide -> bank booth -> poll booth -> exit: the instruction dialog names him while the bank never opens. Now: doAccountGuideStep runs FIRST in doBank (talk, account tab, talk again), before any booth click. Keeps Build 109 (can't-reach recovery); Build 108 (Account Guide gate recovery); Build 107 (tab switch async); Build 106 (dialog-transition); Build 105 (bank door stall); Build 104 (name cache); Build 103; Build 102 (event-driven); Build 101; Build 100; Build 99; Build 98; Build 97; Build 96; Build 95; Build 94; Build 93; Build 92; Build 91; Build 90; Build 89; Build 88; Build 87; Build 86; Build 85; Build 84; Build 83; Build 82; Build 81/80.");
        // Build 104: load the persisted object id->name cache so the first
        // find of the session doesn't pay the name-resolution cost again.
        loadObjNameCache();
        // REBUILD: register the event-driven world model (non-blocking reads).
        try {
            worldModel.register();
            diag("REBUILD: WorldModel registered on event bus");
        } catch (Exception e) {
            diag("REBUILD: WorldModel register failed: " + e);
        }
        ensureUpdatePipelineCacheBuster();
        ensureSupervisorCacheClear();
        Microbot.status = "Tutorial Island: starting...";

        mainScheduledFuture = scheduledExecutorService.scheduleWithFixedDelay(() -> {
            try {
                if (!Microbot.isLoggedIn()) return;
                if (pausedForManual) return;
                if (!startDetected) {
                    detectionTicks++;
                    Stage detected = detectStartStage();
                    // Only lock in CHAR_CREATOR if we can actually SEE the character
                    // creator (confirm button). Otherwise the NPC cache probably
                    // hasn't loaded yet — keep retrying instead of guessing wrong.
                    boolean confident = detected != Stage.CHAR_CREATOR || charCreatorVisible();
                    if (confident || detectionTicks >= DETECTION_TIMEOUT_TICKS) {
                        startStage = detected;
                        startDetected = true;
                        Microbot.status = "Tutorial Island: resuming from " + startStage;
                        diag("Detected start stage: " + startStage);
                    } else {
                        Microbot.status = "Tutorial Island: detecting current step...";
                        if (detectionTicks % 10 == 0) {
                            log.info("[TutorialIsland] Still detecting step (tick {})...", detectionTicks);
                        }
                        return; // wait for NPCs to load, don't start the machine yet
                    }
                }
                // Self-correction DISABLED for debugging — was possibly hanging the tick.
                // TODO: re-enable once we know the bot acts.
                if (false && startDetected && detectionTicks % 5 == 0
                        && System.currentTimeMillis() - lastStepBackMs > 10000) {
                    Stage live = detectStartStage();
                    Stage current = getCurrentState();
                    if (live.ordinal() < current.ordinal() && live != Stage.CHAR_CREATOR) {
                        diag("Stepping back " + current + " -> " + live + " (live detection)");
                        Microbot.status = "Tutorial Island: correcting to " + live;
                        resetDoneFrom(live);
                        forceState(live, "step-back correction");
                        lastStepBackMs = System.currentTimeMillis();
                    }
                }
                detectionTicks++;
                step();
                Stage nowState = getCurrentState();
                if (lastDiagState != nowState) {
                    diag("Stage: " + lastDiagState + " -> " + nowState);
                    lastDiagState = nowState;
                }
            } catch (Exception ex) {
                log.error("[TutorialIsland] Unexpected error in tick", ex);
                Global.sleep(2000, 3000);
            }
        }, 0, config.tickDelay(), TimeUnit.MILLISECONDS);

        return true;
    }

    @Override
    protected Stage initialState() {
        return startStage;
    }

    /**
     * Step checker: finds which tutorial section the player is currently in by
     * looking for the nearest instructor NPC (checked latest-first), so the
     * script resumes mid-tutorial instead of starting over.
     */
    private Stage detectStartStage() {
        if (Rs2Player.hasCompletedTutorialIsland()) return Stage.DONE;
        // Build 121: VARP 281 GROUND TRUTH. Live 2026-09-27 19:42 (Build 119):
        // bot restarted INSIDE the bank, detector saw the booth within 10
        // tiles and returned BANK -- but the game's tutorial instruction said
        // "Exit through the door and follow the path to the chapel. Once
        // there, speak to Brother Brace." The game had ALREADY completed BANK;
        // the bot looped the booth (opened=false) for 3+ minutes while the
        // game waited for PRAYER. Julien: "shamefull". Position-based detection
        // cannot distinguish "at the bank, bank not done" from "at the bank,
        // bank done". Varplayer 281 is the game's own tutorial progress counter
        // (OSRS Wiki: Learning the Ropes / Varplayer/281). Read it FIRST; only
        // fall back to position if unreadable. (Alex's independent research.)
        Stage varpStage = detectStageByVarp();
        if (varpStage != null) {
            diag("VARP-281 stage detection -> " + varpStage + " (overrides position)");
            return varpStage;
        }
        diag("VARP: 281 unreadable, falling back to position detection");
        // Build 76: the bank ladder's underground end sits ~20 tiles from
        // Vannaka, so nearest-instructor detection misfires as COMBAT there
        // (seen live: BANK for 45 min, then COMBAT after a restart with the
        // player unmoved at the ladder). The bank ladder itself (objects
        // 9727/9728, observed live in the bank-stage diag) is the reliable
        // bank-section signal: tutorial linearity guarantees combat is done
        // if the player reached it.
        if (nearBankLadder()) return Stage.BANK;
        if (npcReachable("Magic Instructor", 40)) return Stage.MAGIC;
        // Build 83: Banker BEFORE Brother Brace. They're ~20 tiles apart
        // (bank Y~3126, Brace Y~3106); the old order returned PRAYER while
        // standing at the bank, skipping the bank open entirely (Julien
        // caught this live). Julien's principle: know WHERE you are before
        // deciding WHAT stage you're at.
        // Booth tiebreaker: the bank booth is only within 10 tiles when the
        // player is actually inside the bank room — from the church (~17+
        // tiles away) it isn't, so a restart mid-prayer still detects PRAYER.
        if (findObjectFast("Bank booth", 10) != null) return Stage.BANK;
        // Build 118: Brother Brace BEFORE Banker. Live 2026-09-27 19:19
        // (Build 117): the client restarted while the character stood
        // INSIDE the chapel ("speak to Brother Brace" instruction visible),
        // but the detector returned BANK — the Banker's 40-tile radius
        // reaches the church (~20 tiles away), so it hijacked the PRAYER
        // detection and the bot redid the Account Guide + bank booth while
        // the game waited for the chapel step (Julien: "stuck near the
        // church bad pathfinding"). If Brace is within 20 tiles we're at
        // the church → PRAYER, regardless of the Banker. The booth check
        // above already covers genuinely being inside the bank room.
        if (npcReachable("Brother Brace", 20)) return Stage.PRAYER;
        if (npcReachable("Banker", 40)) return Stage.BANK;
        if (npcReachable("Brother Brace", 40)) return Stage.PRAYER;
        if (npcReachable("Combat Instructor", 40)) return Stage.COMBAT;
        if (npcReachable("Mining Instructor", 40)) return Stage.MINING;
        if (npcReachable("Quest Guide", 30)) return Stage.QUEST_GUIDE;
        if (npcReachable("Master Chef", 35)) return Stage.CHEF;
        if (npcReachable("Survival Expert", 35)) return Stage.SURVIVAL;
        if (npcReachable("Gielinor Guide", 30)) return Stage.GUIDE;
        return Stage.CHAR_CREATOR;
    }

    /** Build 121: read the game's own tutorial progress from varplayer 281.
     *  Returns the Stage the GAME thinks we're at, or null if unreadable.
     *  Mapping from OSRS Wiki (Learning the Ropes / Varplayer/281), via
     *  Alex's independent research 2026-09-27. This is ground truth --
     *  position-based detection can't tell "bank not done" from "bank done
     *  but standing at the bank". */
    private Stage detectStageByVarp() {
        try {
            Integer varpVal = Microbot.getClientThread().invoke(() -> {
                try {
                    return Microbot.getClient().getVarpValue(281);
                } catch (Exception e) {
                    return -1;
                }
            });
            if (varpVal == null || varpVal < 0) return null;
            int v = varpVal;
            diag("VARP: 281 = " + v);
            // Canonical OSRS Tutorial Island varp mapping (Alex 2026-09-27,
            // from https://oldschool.runescape.wiki/w/RuneScape:Varplayer/281)
            // Exact sub-steps: 510=Open Bank; 520=Close Bank/open Poll Booth;
            // 530=Talk Account Guide; 531=open Account Mgmt; 532=talk AG again;
            // 540=Exit AG room; 550=Talk Brother Brace; 560=open Prayer tab;
            // 570=talk Brace again; 580=open Friends; 600=talk Brace again;
            // 610=Exit chapel; 620+=Magic Instructor; 1000=completed.
            if (v >= 1000) return Stage.DONE;
            if (v >= 620) return Stage.MAGIC;      // 620-670: Magic Instructor
            if (v >= 610) return Stage.PRAYER;     // 610: Exit chapel (still prayer area)
            if (v >= 550) return Stage.PRAYER;     // 550-600: Brother Brace/chapel
            if (v >= 540) return Stage.BANK;       // 540: Exit Account Guide room
            if (v >= 510) return Stage.BANK;       // 510-532: bank/account steps
            if (v >= 370) return Stage.COMBAT;     // 370-500: Vannaka/rats
            if (v >= 260) return Stage.MINING;     // 260-360: Dezzick/furnace/anvil
            if (v >= 200) return Stage.QUEST_GUIDE; // 200-250: Quest Guide
            if (v >= 130) return Stage.CHEF;       // 130-170: Master Chef
            if (v >= 20) return Stage.SURVIVAL;    // 20-120: Survival Expert
            if (v >= 1) return Stage.GUIDE;        // 1-10: Gielinor Guide
            return null; // varp 0: not on tutorial or unreadable
        } catch (Exception e) {
            diag("VARP: 281 read failed: " + e);
            return null;
        }
    }

    /**
     * Build 134: Read varplayer 281 directly (the game's tutorial progress counter).
     * Returns null if unreadable. This is the completion gate -- no flag, click,
     * or coordinate heuristic counts. Only varp 281 >= 550 completes BANK.
     */
    private Integer getVarp281() {
        try {
            Integer varpVal = Microbot.getClientThread().invoke(() -> {
                try {
                    return Microbot.getClient().getVarpValue(281);
                } catch (Exception e) {
                    return -1;
                }
            });
            if (varpVal == null || varpVal < 0) return null;
            return varpVal;
        } catch (Exception e) {
            return null;
        }
    }

    /** Can we actually see the character creator screen right now? */
    private boolean charCreatorVisible() {
        return Rs2Widget.findWidget("Confirm") != null
                || Rs2Widget.findWidget("Accept") != null
                || npcReachable("Gielinor Guide", 30);
    }

    /** Build 123: read varplayer 281 (game's tutorial progress). Returns null if unreadable. */
    private Integer readVarp281() {
        try {
            return Microbot.getClientThread().invoke(() -> {
                try {
                    return Microbot.getClient().getVarpValue(281);
                } catch (Exception e) {
                    return null;
                }
            });
        } catch (Exception e) {
            return null;
        }
    }

    /** Clear done-flags for the given stage and everything after it. */
    private void resetDoneFrom(Stage s) {
        boolean reset = false;
        for (Stage st : Stage.values()) {
            if (st == s) reset = true;
            if (reset) setDone(st, false);
        }
    }

    private void setDone(Stage s, boolean v) {
        switch (s) {
            case CHAR_CREATOR: charCreatorDone = v; break;
            case GUIDE: guideDone = v; break;
            case SURVIVAL: survivalDone = v; break;
            case CHEF: chefDone = v; break;
            case QUEST_GUIDE: questGuideDone = v; break;
            case MINING: miningDone = v; break;
            case COMBAT: combatDone = v; break;
            case BANK: bankDone = v; break;
            case PRAYER: prayerDone = v; break;
            case MAGIC: magicDone = v; break;
            default: break;
        }
    }

    @Override
    protected List<Transition<Stage>> defineTransitions() {
        return List.of(
                Transition.<Stage>from(Stage.CHAR_CREATOR).when(() -> charCreatorDone, "charCreatorDone")
                        .because("Character creator done").goTo(Stage.GUIDE),
                Transition.<Stage>from(Stage.GUIDE).when(() -> guideDone, "guideDone")
                        .because("Guide done").goTo(Stage.SURVIVAL),
                Transition.<Stage>from(Stage.SURVIVAL).when(() -> survivalDone, "survivalDone")
                        .because("Survival done").goTo(Stage.CHEF),
                Transition.<Stage>from(Stage.CHEF).when(() -> chefDone, "chefDone")
                        .because("Chef done").goTo(Stage.QUEST_GUIDE),
                Transition.<Stage>from(Stage.QUEST_GUIDE).when(() -> questGuideDone, "questGuideDone")
                        .because("Quest guide done").goTo(Stage.MINING),
                Transition.<Stage>from(Stage.MINING).when(() -> miningDone, "miningDone")
                        .because("Mining done").goTo(Stage.COMBAT),
                Transition.<Stage>from(Stage.COMBAT).when(() -> combatDone, "combatDone")
                        .because("Combat done").goTo(Stage.BANK),
                Transition.<Stage>from(Stage.BANK).when(() -> bankDone, "bankDone")
                        .because("Bank done").goTo(Stage.PRAYER),
                Transition.<Stage>from(Stage.PRAYER).when(() -> prayerDone, "prayerDone")
                        .because("Prayer done").goTo(Stage.MAGIC),
                Transition.<Stage>from(Stage.MAGIC).when(() -> magicDone, "magicDone")
                        .because("Magic done").goTo(Stage.DONE)
        );
    }

    @Override
    protected void onState(Stage state) {
        if (Rs2Player.hasCompletedTutorialIsland()) {
            finish("Tutorial Island complete!");
            return;
        }
        // Auto-screenshot every 2 min for remote review via GitHub.
        maybeAutoScreenshot();
        // Check GitHub for newer patches every 5 min; exit for Supervisor to apply.
        maybeCheckForUpdate();
        // Global safety net: eat food whenever health drops to 70% or below.
        // Runs every tick; eatAt() only acts when HP is actually low.
        try {
            if (Rs2Player.eatAt(70)) {
                diag("Ate food (HP was <= 70%)");
            }
        } catch (Exception ignored) {}
        switch (state) {
            case CHAR_CREATOR -> doCharCreator();
            case GUIDE -> doGuide();
            case SURVIVAL -> doSurvival();
            case CHEF -> doChef();
            case QUEST_GUIDE -> doQuestGuide();
            case MINING -> doMining();
            case COMBAT -> doCombat();
            case BANK -> doBank();
            case PRAYER -> doPrayer();
            case MAGIC -> doMagic();
            case DONE -> finish("Tutorial Island complete!");
        }
    }

    @Override
    protected Stage onError(Stage state, Exception e) {
        log.error("[TutorialIsland] Error in state {}", state, e);
        Global.sleep(3000, 5000);
        return state; // retry the same state next tick
    }

    @Override
    public void shutdown() {
        // REBUILD: unregister the world model from the event bus.
        try {
            worldModel.unregister();
        } catch (Exception ignored) {}
        super.shutdown();
    }

    private void finish(String message) {
        Microbot.status = message;
        log.info("[TutorialIsland] {}", message);
        magicDone = true;
        shutdown();
    }

    private void pauseForManual(String reason) {
        pausedForManual = true;
        Microbot.status = "PAUSED: " + reason + " Then re-enable the plugin to resume.";
        log.warn("[TutorialIsland] Pausing for manual input: {}", reason);
        shutdown();
    }

    // ------------------------------------------------------------------
    // Shared helpers
    // ------------------------------------------------------------------

    /**
     * Is an instructor NPC both nearby AND actually reachable on foot?
     * Pure distance lies on Tutorial Island: the next instructor is often a
     * few tiles away through a closed door/wall ("I can't reach that!").
     */
    private boolean npcReachable(String name, int radius) {
        try {
            Rs2NpcModel npc = CompletableFuture.supplyAsync(() -> {
                try {
                    return Microbot.getRs2NpcCache().query()
                            .within(radius)
                            .withName(name)
                            .nearest();
                } catch (Exception e) {
                    return null;
                }
            }).get(2, TimeUnit.SECONDS);
            if (npc == null) return false;
            // Build 73: the NPC must be on the SAME PLANE (floor) as the
            // player. The 2D radius ignores floors, so without this the
            // Banker upstairs counted as "reachable" from the ladder base
            // downstairs: combatFinalLadder declared combatDone prematurely
            // and doBank stalled on openBank() forever because the Banker
            // can't be pathed to across floors.
            // Skip Rs2Tile.isTileReachable — it hangs. Just check the NPC
            // exists within radius on our plane; talkTo handles the actual
            // pathing.
            try {
                int npcPlane = npc.getWorldLocation().getPlane();
                net.runelite.api.Player local =
                        Microbot.getClient().getLocalPlayer();
                if (local != null && local.getWorldLocation() != null
                        && local.getWorldLocation().getPlane() != npcPlane) {
                    return false;
                }
            } catch (Exception e) {
                // Plane read failed — fall back to the radius-only check.
            }
            return true;
        } catch (TimeoutException e) {
            diag("npcReachable(" + name + ") timed out, assuming false");
            return false;
        } catch (Exception e) {
            log.warn("[TutorialIsland] npcReachable failed for {}", name, e);
            return false;
        }
    }

    /** Build 78: true if the bank ladder (either end) is within a few tiles.
     *  Observed live as game objects 9727 (underground end) / 9728 (top end)
     *  in the bank-stage diag. Tight radius: the rat pen is ~6+ tiles away,
     *  so a legitimate combat player at the fence must NOT match.
     *  Build 76 used the Rs2TileObjectCache query; it returned FALSE on the
     *  REBUILD: was a blocking invoke() scene scan. Now uses the event-driven
     *  Rs2TileObjectCache (non-blocking). If the cache hasn't populated yet
     *  (first tick), returns false and the stage detector retries next tick. */
    private boolean nearBankLadder() {
        try {
            Rs2TileObjectModel ladder = Microbot.getRs2TileObjectCache().query()
                    .within(10)
                    .withName("Ladder")
                    .nearest();
            return ladder != null;
        } catch (Exception e) {
            return false;
        }
    }

    /** Raw scene scan for the bank ladder. MUST run on the client thread. */
    private boolean scanForBankLadder() {
        try {
            net.runelite.api.Client client = Microbot.getClient();
            net.runelite.api.Player lp = client.getLocalPlayer();
            if (lp == null) return false;
            WorldPoint pp = lp.getWorldLocation();
            if (pp == null) return false;
            net.runelite.api.coords.LocalPoint local = lp.getLocalLocation();
            if (local == null) return false;
            net.runelite.api.Tile[][][] tiles = client.getScene().getTiles();
            int z = client.getPlane();
            int px = local.getSceneX();
            int py = local.getSceneY();
            int checked = 0;
            for (int x = Math.max(0, px - 6); x < Math.min(tiles[z].length, px + 7); x++) {
                for (int y = Math.max(0, py - 6); y < Math.min(tiles[z][x].length, py + 7); y++) {
                    net.runelite.api.Tile tile = tiles[z][x][y];
                    if (tile == null) continue;
                    for (net.runelite.api.GameObject obj : tile.getGameObjects()) {
                        if (obj == null) continue;
                        checked++;
                        int id = obj.getId();
                        boolean idMatch = id == 9727 || id == 9728;
                        boolean nameMatch = false;
                        if (!idMatch) {
                            try {
                                net.runelite.api.ObjectComposition comp =
                                        client.getObjectDefinition(id);
                                if (comp != null && comp.getName() != null
                                        && comp.getName().toLowerCase().contains("ladder")) {
                                    nameMatch = true;
                                }
                            } catch (Exception ignored) { }
                        }
                        if ((idMatch || nameMatch)
                                && obj.getWorldLocation() != null
                                && obj.getWorldLocation().distanceTo(pp) <= 5) {
                            diag("Build 78: bank ladder scan: found id " + id
                                    + (nameMatch && !idMatch ? " (name match)" : "")
                                    + " at distance "
                                    + obj.getWorldLocation().distanceTo(pp));
                            return true;
                        }
                    }
                }
            }
            diag("Build 78: bank ladder scan: no ladder within 5 tiles ("
                    + checked + " game objects checked)");
            return false;
        } catch (Exception e) {
            diag("Build 78: bank ladder scan failed: " + e);
            return false;
        }
    }

    private Rs2NpcModel findNpc(String name) {
        try {
            return Microbot.getRs2NpcCache().query()
                    .within(30)
                    .withName(name)
                    .nearest();
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * Build 166 (Alex): snapshot-driven talk. Same race-free pattern as
     * talkToOnce: snapshot find, explicit walkStep travel, direct walk-free
     * invoke when adjacent, then wait for the dialogue.
     */
    private boolean talkTo(String npcName) {
        WorldModel.NpcSnapshot snap = findNpcSnapshot(npcName);
        if (snap == null || snap.tile == null) {
            diag("Build 166 talk: '" + npcName + "' not in NPC snapshot (not nearby)");
            return false;
        }
        WorldPoint pp = worldModel.playerPos;
        if (pp == null) return false;
        int dist = Math.abs(pp.getX() - snap.tile.getX())
                 + Math.abs(pp.getY() - snap.tile.getY());
        if (dist > 2) {
            WorldPoint adj = closestAdjacentTile(snap.tile, pp);
            if (adj != null) {
                try { Rs2Walker.walkStep(adj, 0); }
                catch (Exception e) {
                    diag("Build 166 talk: walkStep failed: " + e.getClass().getSimpleName());
                }
            }
            return false;
        }
        diag("Build 166 talk: '" + snap.name + "' id=" + snap.id + " idx=" + snap.index
            + " at " + snap.tile);
        if (!clickNpcDirect(snap, "Talk-to")) {
            diag("Click on '" + npcName + "' did nothing");
            return false;
        }
        return Global.sleepUntil(() -> safeIsInDialogue(), 10000);
    }

    /**
     * Build 166 (Alex): was supplyAsync(findNpc).get(2s) with a discarded
     * future -- findNpc's withName blocks on getName()/ClientThread.invoke and
     * the zombie thread kept running after timeout. Now snapshot-based, zero
     * blocking, zero futures. Callers needing the model should prefer
     * findNpcSnapshot + findNpcModelById.
     */
    private Rs2NpcModel findNpcTimeout(String name) {
        WorldModel.NpcSnapshot snap = findNpcSnapshot(name);
        if (snap == null) return null;
        return findNpcModelByIdIndex(snap.id, snap.index);
    }

    /** Click through "Click here to continue" dialogue. Returns false if paused for manual. */
    private boolean spamDialogue() {
        return spamDialogue(60000);
    }

    /**
     * Smart tutorial-instruction follower: reads what the dialog actually says
     * and does what it asks — opening tabs for UI prompts, performing world
     * actions for "click a tree"-style prompts. This replaces hardcoding every
     * prompt — the tutorial tells us what it wants. Only called when we're in
     * a dialog with no continue button, which is exactly the tutorial's
     * "do this" prompts. Returns true if it handled something.
     */
    // Build 97: Cache the widget-scanned dialog text. The full tree scan takes
    // ~24s; doing it every tick while in a dialogue causes the 2-minute hangs
    // Julien reported everywhere (bank->poll, bar->anvil, etc.). The dialog
    // doesn't change between ticks, so reuse the cached body while the title
    // (which reads reliably via API) is unchanged.
    private String cachedDialogTitle = "";
    private String cachedDialogBody = "";
    private boolean dialogCacheValid = false;

    // Build 98: Shared cached dialog-body lookup. Both followTutorialInstruction()
    // and pollBoothStillWanted() were scanning independently; the poll-booth
    // retry loop scans EVERY tick after the first click (pollClickedOnce=true),
    // causing 15-24s ticks and 90s silences (Julien's <2s rule violated).
    private String getDialogBodyCached(String title, String body) {
        if (title == null) title = "";
        if (body == null) body = "";
        if (!body.isBlank()) {
            // API gave us text; update cache.
            cachedDialogTitle = title;
            cachedDialogBody = body;
            dialogCacheValid = true;
            return body;
        }
        // Body blank: use cache if same dialog, else use WorldModel's
        // event-sampled dialog text (REBUILD: was scanDialogTextFromWidgets(),
        // a 24s recursive tree walk via blocking invoke()).
        if (dialogCacheValid && title.equals(cachedDialogTitle)) {
            return cachedDialogBody;
        }
        String sampled = "";
        try {
            WorldModel.DialogSnapshot snap = worldModel.getDialog();
            if (snap.open) {
                sampled = snap.body;
                if (!title.isBlank() && snap.title.isBlank()) {
                    // WorldModel didn't capture a title; keep the passed one.
                } else if (!snap.title.isBlank()) {
                    title = snap.title;
                }
            }
        } catch (Exception ignored) {}
        cachedDialogTitle = title;
        cachedDialogBody = sampled;
        dialogCacheValid = true;
        return sampled;
    }

    private boolean followTutorialInstruction() {
        // STATE-BASED: after the stats button, the tutorial wants the dagger.
        // (Dialog text is often empty, so don't rely on reading it.)
        if (statsButtonClicked) {
            try {
                boolean hasDagger = net.runelite.client.plugins.microbot.util.inventory.Rs2Inventory.contains("Bronze dagger");
                if (hasDagger) {
                    diag("State: stats done, dagger in inv -> equipping");
                    clickTabIcon(InterfaceTab.INVENTORY);
                    Global.sleep(600, 900);
                    net.runelite.client.plugins.microbot.util.inventory.Rs2Inventory.wield("Bronze dagger");
                    Global.sleep(800, 1200);
                    // If dagger left inventory, it's equipped — clear the flag
                    if (!net.runelite.client.plugins.microbot.util.inventory.Rs2Inventory.contains("Bronze dagger")) {
                        diag("State: dagger equipped, clearing statsButtonClicked");
                        statsButtonClicked = false;
                    }
                    // Advance the dialog ("Well done...") so we don't loop
                    try { Rs2Dialogue.clickContinue(); } catch (Exception ignored) {}
                    try { Rs2Keyboard.keyPress(KeyEvent.VK_SPACE); } catch (Exception ignored) {}
                    Global.sleep(600, 900);
                    return true;
                } else {
                    // No dagger in inventory — assume it's already equipped.
                    // Click continue to advance past the "equip dagger" dialog,
                    // then clear the flag so we move on to the instructor.
                    diag("State: no dagger in inv, clicking continue to advance");
                    try { Rs2Dialogue.clickContinue(); } catch (Exception ignored) {}
                    try { Rs2Keyboard.keyPress(KeyEvent.VK_SPACE); } catch (Exception ignored) {}
                    Global.sleep(600, 900);
                    statsButtonClicked = false;
                    return true;
                }
            } catch (Exception e) {
                diag("Dagger equip state check failed: " + e);
            }
        }
        String title, body;
        try {
            title = safeGetQuestion();
            body = safeGetDialogueText();
        } catch (Exception e) {
            return false;
        }
        if (title == null) title = "";
        if (body == null) body = "";
        // Fallback: if API returns empty, use cached widget scan.
        // Build 98: shared getDialogBodyCached() so the poll-booth check
        // benefits from the same cache (was scanning every tick independently).
        body = getDialogBodyCached(title, body);
        String text = (title + " " + body).toLowerCase();
        if (text.isBlank()) return false;
        String snippet = text.length() > 90 ? text.substring(0, 90) + "..." : text;
        String tl = title.toLowerCase();

        // Skill-instruction dialogs are titled with the skill name, and the title
        // reads reliably even when the body text doesn't. Map them to world actions.
        if (tl.contains("woodcutting")) {
            diag("Instruction 'Woodcutting' -> chopping a tree");
            dismissDialog();
            interactObject("Tree", "Chop down");
            return true;
        }
        if (tl.contains("fishing")) {
            diag("Instruction 'Fishing' -> netting a fishing spot");
            dismissDialog();
            interactNpc("Fishing spot", "Net");
            return true;
        }
        if (tl.contains("firemaking")) {
            // Need logs before we can light. If none, dismiss and let the
            // state logic chop some first.
            if (!Rs2Inventory.contains("Logs")) {
                diag("Instruction 'Firemaking' but no logs — dismissing to chop first");
                dismissDialog();
                return true;
            }
            diag("Instruction 'Firemaking' -> lighting logs");
            dismissDialog();
            Rs2Inventory.combine("Tinderbox", "Logs");
            return true;
        }
        if (tl.contains("cooking")) {
            // Need a fire before we can cook. If none, dismiss and let the
            // state logic make one first (chop -> light).
            if (findObjectFast("Fire", 12) == null) {
                diag("Instruction 'Cooking' but no fire — dismissing to make fire first");
                dismissDialog();
                return true;
            }
            diag("Instruction 'Cooking' -> cooking shrimp on the fire");
            dismissDialog();
            useItemOnObject("Raw shrimps", "Fire");
            return true;
        }

        // --- World actions: dismiss the info dialog, then do the thing. ---
        if ((text.contains("tree") && (text.contains("cut") || text.contains("chop") || text.contains("woodcutting")))
                || text.contains("click a nearby tree")) {
            diag("Dialog wants woodcutting ('" + snippet.trim() + "') -> chopping a tree");
            dismissDialog();
            interactObject("Tree", "Chop down");
            return true;
        }
        if (text.contains("fishing spot") || (text.contains("shrimp") && text.contains("net"))
                || text.contains("catch") && text.contains("shrimp")) {
            diag("Dialog wants fishing ('" + snippet.trim() + "') -> netting");
            dismissDialog();
            interactNpc("Fishing spot", "Net");
            return true;
        }
        if ((text.contains("light") || text.contains("firemaking")) && text.contains("logs")
                || text.contains("make a fire")) {
            if (!Rs2Inventory.contains("Logs")) {
                diag("Dialog wants firemaking but no logs — dismissing to chop first");
                dismissDialog();
                return true;
            }
            diag("Dialog wants firemaking ('" + snippet.trim() + "') -> lighting logs");
            dismissDialog();
            Rs2Inventory.combine("Tinderbox", "Logs");
            return true;
        }
        if (text.contains("cook") && (text.contains("shrimp") || text.contains("fire"))) {
            if (findObjectFast("Fire", 12) == null) {
                diag("Dialog wants cooking but no fire — dismissing to make fire first");
                dismissDialog();
                return true;
            }
            diag("Dialog wants cooking ('" + snippet.trim() + "') -> cooking shrimp");
            dismissDialog();
            useItemOnObject("Raw shrimps", "Fire");
            return true;
        }

        // --- UI tab prompts. ---
        InterfaceTab tab = null;
        String why = null;
        if (text.contains("backpack") || text.contains("inventory") || text.contains("given an item")) {
            tab = InterfaceTab.INVENTORY; why = "inventory";
        } else if (text.contains("bar graph") || text.contains("skills menu") || text.contains("gained some experience")) {
            tab = InterfaceTab.SKILLS; why = "skills";
        } else if (text.contains("prayer")) {
            tab = InterfaceTab.PRAYER; why = "prayer";
        } else if (text.contains("spellbook") || text.contains("magic icon")) {
            tab = InterfaceTab.MAGIC; why = "magic";
        } else if (text.contains("worn equipment") || text.contains("wield") || text.contains("equip")) {
            // "flashing button with a shield and helmet... Click on it now"
            // — the stats button is already visible, click it directly.
            if (text.contains("flashing button") || text.contains("shield and helmet")) {
                diag("Dialog wants the shield/helmet stats button -> clicking");
                clickEquipmentStatsIcon();
                Global.sleep(800, 1200);
                try { Rs2Dialogue.clickContinue(); } catch (Exception ignored) {}
                return true;
            }
            // "Click your dagger to equip it." — wield the bronze dagger from inventory.
            if (text.contains("dagger") && text.contains("equip")) {
                diag("Dialog wants the dagger equipped -> wielding bronze dagger");
                // Ensure inventory tab is open (physical click for flashing prompt)
                clickTabIcon(InterfaceTab.INVENTORY, true);
                Global.sleep(600, 900);
                try {
                    net.runelite.client.plugins.microbot.util.inventory.Rs2Inventory.wield("Bronze dagger");
                } catch (Exception e) {
                    diag("Wield dagger failed: " + e);
                }
                Global.sleep(800, 1200);
                try { Rs2Dialogue.clickContinue(); } catch (Exception ignored) {}
                return true;
            }
            tab = InterfaceTab.EQUIPMENT; why = "equipment";
        } else if (text.contains("quest journal") || text.contains("quest list")) {
            tab = InterfaceTab.QUESTS; why = "quests";
        } else if (text.contains("account management")) {
            // Build 108: the Account Guide's "open your Account Management
            // menu" prompt (also says "flashing icon" — must win over the
            // generic flashing-icon default below, which guesses QUESTS).
            tab = InterfaceTab.ACC_MAN; why = "account management";
        } else if (text.contains("flashing icon")) {
            // "Click on the flashing icon..." — determine which tab from context.
            // "to the left of your inventory" = quests tab.
            if (text.contains("left of your inventory") || text.contains("quest")) {
                tab = InterfaceTab.QUESTS; why = "quests (flashing)";
            } else if (text.contains("prayer")) {
                tab = InterfaceTab.PRAYER; why = "prayer (flashing)";
            } else if (text.contains("magic") || text.contains("spellbook")) {
                tab = InterfaceTab.MAGIC; why = "magic (flashing)";
            } else if (text.contains("inventory") || text.contains("backpack")) {
                tab = InterfaceTab.INVENTORY; why = "inventory (flashing)";
            } else {
                // Default: quests is the most common flashing tab in tutorial
                tab = InterfaceTab.QUESTS; why = "quests (flashing default)";
            }
        } else if (text.contains("attack style") || text.contains("combat icon")) {
            tab = InterfaceTab.COMBAT; why = "combat";
        } else if (text.contains("wrench") || text.contains("settings") || text.contains("game options")) {
            tab = InterfaceTab.SETTINGS; why = "settings";
        }

        if (tab != null) {
            diag("Dialog wants the " + why + " tab ('" + snippet.trim() + "') -> clicking icon");
            // Physically click the tab icon — the tutorial's "flashing icon"
            // requires a real mouse click, not a script tab-switch.
            boolean clicked = clickTabIcon(tab, true);
            if (!clicked) {
                diag("Tab icon click failed for " + tab + ", retrying physical click once");
                clicked = clickTabIcon(tab, true);
            }
            // After opening the equipment tab, the tutorial wants the stats
            // icon (helmet/shield, bottom of Worn Equipment) clicked.
            if (tab == InterfaceTab.EQUIPMENT) {
                Global.sleep(800, 1200);
                clickEquipmentStatsIcon();
            }
            // The dialog typically says "open your X, then click continue" —
            // after switching the tab, also click continue so we don't loop.
            Global.sleep(800, 1200);
            try { Rs2Dialogue.clickContinue(); } catch (Exception ignored) {}
            try { Rs2Keyboard.keyPress(KeyEvent.VK_SPACE); } catch (Exception ignored) {}
            return true;
        }
        return false;
    }

    /** True if the client's toplevel-panel varc already shows this tab.
     *  Rs2Tab's cache is fed by MicrobotPlugin's VarClientIntChanged hook. */
    private boolean isTabCurrent(InterfaceTab tab) {
        try {
            return Rs2Tab.isCurrentTab(tab);
        } catch (Exception e) {
            return false;
        }
    }

    /** Switch tabs via the client's own script 915 (the same code path a
     *  real tab-button click runs). Needs no visible widget — recovery for a
     *  missing/unrendered tab bar. Blocking invoke: returns after the client
     *  thread has run the script. */
    private void switchTabViaScript(InterfaceTab tab) {
        try {
            int idx = tab.getVarcIntIndex();
            if (idx < 0) {
                diag("switchTabViaScript: no varc index for " + tab);
                return;
            }
            // REBUILD: fire-and-forget — use async invoke(Runnable), not blocking Supplier.
            Microbot.getClientThread().invoke(() -> {
                Microbot.getClient().runScript(TAB_SWITCH_CLIENT_SCRIPT, idx);
            });
            diag("switchTabViaScript: ran client script 915 -> " + tab);
        } catch (Exception e) {
            diag("switchTabViaScript failed: " + e);
        }
    }

    /** Physically click a tab icon widget (for tutorial "flashing icon" prompts
     *  which require a real mouse click, not a script tab-switch).
     *  Uses Rs2Widget.getWidget(packedId) — the same method Microbot's own
     *  getSpellBookTab() uses. Tries both fixed and resizable IDs.
     *  Build 76: fast path when the tab is already current (client varc), and
     *  a client-script fallback when the tab buttons aren't rendered at all. */
    private boolean clickTabIcon(InterfaceTab tab) {
        return clickTabIcon(tab, false);
    }

    /** Build 114: forcePhysical bypasses the isTabCurrent() fast path.
     *  Tutorial "flashing icon" prompts REQUIRE a real mouse click on the
     *  icon even when the tab is already current — the game's tutorial flag
     *  is only set by the physical click. The fast path silently returned
     *  true when the account panel was already open (opened via the
     *  script-915 fallback in an earlier build), so the "Click on the
     *  flashing icon to open your Account Management menu" instruction
     *  looped forever with the click never physically performed (seen live
     *  2026-09-27 18:35->18:39: ~48 booth clicks, opened=false, and NO
     *  "MOUSE CLICKED ACC_MAN" line ever logged). All tutorial-prompt tab
     *  switches use forcePhysical=true; operational switches (open
     *  inventory to wield) keep the fast path so they never toggle a
     *  visible tab closed. */
    private boolean clickTabIcon(InterfaceTab tab, boolean forcePhysical) {
        // Fast path: already on this tab (observed via client varc) — no
        // click needed. Unblocks callers when the tab bar isn't rendered but
        // the wanted tab is already displayed. SKIPPED for forced tutorial
        // prompts, which need the real click regardless.
        if (!forcePhysical && isTabCurrent(tab)) {
            tabClickMisses.put(tab, 0);
            return true;
        }
        if (forcePhysical) {
            diag("clickTabIcon " + tab + ": FORCED physical click (tutorial prompt, skipping current-tab fast path)");
        }
        try {
            // Build 116: EVERY tab uses a VERIFIED target (tree-anchored
            // name-matched bounds, else name-verified packed bounds) — never
            // a blind sequence-derived packed child. Live 2026-09-27 19:00
            // (Build 115): PRAYER's packed 548:69/161:64 never resolved in
            // the WorldModel cache, so the forced physical click never
            // fired and the script-915 fallback looped without setting the
            // game's flashing-icon tutorial flag (the Build 114 lesson).
            // Same trap as ACC_MAN's 548:72 (Build 115) — the packed IDs
            // were derived, never verified against the widget tree.
            if (clickTabIconVerified(tab)) {
                tabClickMisses.put(tab, 0);
                // Build 63: no fixed sleep — one click per tick; the caller
                // re-verifies on the next tick.
                return true;
            }
            diag("clickTabIcon " + tab + ": no verified target this tick — counting miss");
        } catch (Exception e) {
            diag("clickTabIcon failed: " + e);
        }
        // Widget lookup failed entirely. Count the miss; after a few in a
        // row the tab buttons are presumably not rendered (seen 2026-09-27:
        // blank stone row where the buttons were), so fall back to the
        // client's own tab-switch script, which needs no visible widget.
        int misses = tabClickMisses.getOrDefault(tab, 0) + 1;
        tabClickMisses.put(tab, misses);
        if (misses >= TAB_MISS_FALLBACK_AFTER) {
            tabClickMisses.put(tab, 0);
            int fb = tabScriptFallbacks.getOrDefault(tab, 0) + 1;
            tabScriptFallbacks.put(tab, fb);
            // Build 130: NO-PROGRESS GUARD. Alex 2026-09-27 20:15: bot looped
            // script-915 90x with NO VERIFIED TARGET while "Moving on" dialogue
            // blocked everything. If 20 fallbacks fail with no state change,
            // HALT retries and log a clear blocker instead of spamming.
            // Verified transition, not click attempt.
            if (fb > 20) {
                diag("Build 130 NO-PROGRESS GUARD: " + tab + " tab failed " + fb + "x with no state change -- HALTING retries. Blocker: check dialogue/widget/tile. Will not retry until state changes.");
                return false;
            }
            diag("clickTabIcon " + tab + ": button missing " + misses + "x in a row — script-switch fallback (attempt " + fb + ")");
            switchTabViaScript(tab);
            // Build 120: WIDGET DUMP. Live 2026-09-27 19:38 (Build 118): PRAYER
            // tab icon invisible -- packed 548:69/161:64/164:64 all null AND
            // name-match finds nothing. Instead of guessing IDs, dump the
            // actual widget tree so the diag shows what's really there.
            // (Alex's independent review: "capture the actual client/widget
            // layout and confirm which tab interface opens".)
            if (fb == 3) {
                dumpTabBarWidgets(tab);
            }
            // Build 127: SCAN DATA-LOSS FIX. Live 2026-09-27 20:04 (Build 125):
            // scanAllRootsForTabs() DID fire at fb==4 (~20:00:58 in the fresh
            // Build-125 session) but its output scrolled out of the 250-line
            // diag tail (PRAYER loop logs ~6 lines/sec -> ~40s window < 60s
            // upload interval) before the next upload, so the finding was
            // lost. Fix: (1) re-scan every 10 fallbacks after the first
            // (fb=4,14,24...), (2) cache a one-line summary and re-diag it on
            // EVERY fallback so every uploaded tail carries the result.
            if (fb >= 4 && (fb - 4) % 10 == 0) {
                scanAllRootsForTabs();
            }
            if (lastTabScanSummary != null) {
                diag("Build 127 SCAN-SUMMARY: " + lastTabScanSummary);
            }
            // Build 107: switchTabViaScript is async (fire-and-forget) — the
            // script hasn't run yet when we get here, so isTabCurrent() would
            // always be false. Don't check immediately; return false and let
            // the next tick's isTabCurrent() fast-path detect the switch.
            if (fb == 5) {
                diag("!!! TAB BAR NOT RENDERED for " + tab + " after 5 script switches. " +
                     "The in-game tab buttons are not visible (blank stone row). " +
                     "Client shows cache errors ('Mismatch in overlaid cache archive hash', worlds lookup failures) — " +
                     "clear the RuneLite cache or restart the client. Bot keeps retrying.");
                requestCacheClear("tab bar not rendered for " + tab + " after 5 script switches");
            }
        }
        return false;
    }

    /** Build 124: click a tab icon at a VERIFIED target — generalized from
     *  Build 115's ACC_MAN fix. Prefers the tree-anchored name-matched
     *  bounds (fresh <10s); else uses a packed target when the widget
     *  EXISTS, is visible and icon-sized. The Build 115/116 name-keyword
     *  requirement is DROPPED: live 2026-09-27 19:24 proved tab icon
     *  widgets have EMPTY names (548:72 resolved with name=''), so no
     *  name check can ever pass for them. Safety now comes from the IDs
     *  themselves: every packed ID is a ComponentID-verified
     *  stone/icon (gameval InterfaceID), never a derived guess.
     *  Build 124 root cause (live 19:33, Build 118): the PRAYER prompt
     *  looped with NO VERIFIED TARGET because (a) Build 117's 164:59-65
     *  "TABs" were actually the bottom-line ICONs (real TABs are
     *  164:52-58), (b) the name check could never pass on empty names,
     *  (c) client.getWidget(group,child) alone returned null for 161:xx
     *  icons — WorldModel now resolves via three paths (mixin, @Component
     *  packed, roots walk). Logs every candidate so the diag proves the
     *  target. */
    private boolean clickTabIconVerified(InterfaceTab tab) {
        int[] ids = null;
        String expectKw = "";
        // Build 120: per-tab IDs are ComponentID-verified stones + icons
        // across all three layouts (fixed 548, resizable-side 161,
        // bottom-line 164). Order per tab: fixed stone, resizable stone,
        // bottom-line stone, resizable icon, bottom-line icon (+fixed icon
        // where verified).
        switch (tab) {
            case COMBAT:    ids = new int[]{35913792, 10551355, 10747956, 10551362, 10747963}; expectKw = "combat"; break;
            case SKILLS:    ids = new int[]{35913793, 10551356, 10747957, 10551363, 10747964}; expectKw = "stat"; break;
            case QUESTS:    ids = new int[]{35913794, 10551357, 10747958, 10551364, 10747965}; expectKw = "quest"; break;
            case INVENTORY: ids = new int[]{35913795, 10551358, 10747959, 10551365, 10747966}; expectKw = "inventory"; break;
            case EQUIPMENT: ids = new int[]{35913796, 10551359, 10747960, 10551366, 10747967}; expectKw = "equipment"; break;
            case PRAYER:    ids = new int[]{35913797, 10551360, 10747961, 10551367, 10747968, 35913804}; expectKw = "prayer"; break;
            case MAGIC:     ids = new int[]{35913798, 10551361, 10747962, 10551368, 10747969}; expectKw = "magic"; break;
            case SETTINGS:  ids = new int[]{35913780, 10551343, 10747951}; expectKw = "setting"; break;
            case ACC_MAN:   ids = new int[]{35913800, 10551363}; expectKw = "account"; break;
            case FRIENDS:   ids = new int[]{10747950}; expectKw = "friend"; break;
            case MUSIC:     ids = new int[]{10747953}; expectKw = "music"; break;
            case LOGOUT:    ids = new int[]{10747938}; expectKw = "log"; break;
            case EMOTES:    ids = new int[]{10747952}; expectKw = "emote"; break;
            default: break;
        }
        try {
            StringBuilder cand = new StringBuilder();
            java.awt.Rectangle packedB = null;
            String packedWhy = "";
            if (ids != null) {
                for (int pid : ids) {
                    java.awt.Rectangle b = worldModel.getWidgetBoundsPacked(pid);
                    String nm = worldModel.getTabWidgetName(pid);
                    cand.append("[").append(pid >>> 16).append(":").append(pid & 0xFFFF)
                        .append(" name='").append(nm).append("' bounds=").append(rectStr(b)).append("] ");
                    if (b == null) continue;
                    // Build 120: accept the FIRST resolving packed ID that
                    // is icon-sized. IDs are ComponentID-verified (not
                    // derived), and tab icon names are empty (proven live),
                    // so no name check — existence + visibility + size is
                    // the verification. The sampler only caches visible
                    // widgets with positive bounds.
                    if (packedB == null && b.width > 0 && b.height > 0
                            && b.width <= 120 && b.height <= 120) {
                        packedB = b;
                        packedWhy = "packed(" + (pid >>> 16) + ":" + (pid & 0xFFFF)
                                + ",ComponentID-verified,name='" + nm + "')";
                    }
                }
            }
            java.awt.Rectangle nmB = null;
            String nmName = "";
            long nmAge = Long.MAX_VALUE;
            try {
                WorldModel.TabIconHit hit = worldModel.getTabIconHit(tab);
                if (hit != null && hit.bounds != null) {
                    nmB = hit.bounds;
                    nmName = hit.name;
                    nmAge = System.currentTimeMillis() - hit.time;
                }
            } catch (Exception ignored) {}
            diag("Build 124: " + tab + " check: " + cand.toString()
                    + "| name-matched name='" + nmName + "' bounds=" + rectStr(nmB)
                    + " age=" + nmAge + "ms");
            // Build 124: log WorldModel's throttled tab-strip tree diagnostic
            // when it changes — shows exactly what each lookup path
            // (mixin/packed/roots) returns for the prayer stone+icon.
            try {
                String tsd = worldModel.getTabStripDiag();
                if (tsd != null && !tsd.isEmpty() && !tsd.equals(lastLoggedTabStripDiag)) {
                    lastLoggedTabStripDiag = tsd;
                    diag(tsd);
                }
            } catch (Exception ignored) {}
            java.awt.Rectangle target;
            String whyTarget;
            if (nmB != null && nmAge < 10000) {
                target = nmB;
                whyTarget = "name-matched(" + nmName + ")";
            } else if (packedB != null) {
                target = packedB;
                whyTarget = packedWhy;
            } else {
                diag("clickTabIcon " + tab
                        + ": NO VERIFIED TARGET (no packed ID resolved, name-matched stale/missing)");
                return false;
            }
            int x = (int) target.getCenterX();
            int y = (int) target.getCenterY();
            diag("clickTabIcon " + tab + ": clicking " + whyTarget + " at " + x + "," + y);
            Microbot.getMouse().click(x, y);
            diag("MOUSE CLICKED " + tab + " tab icon (" + whyTarget + ")");
            return true;
        } catch (Exception e) {
            diag("clickTabIconVerified failed: " + e);
            return false;
        }
    }

    private static String rectStr(java.awt.Rectangle r) {
        if (r == null) return "null";
        return "[" + r.x + "," + r.y + " " + r.width + "x" + r.height + "]";
    }

    /** Build 120: dump ALL widgets in the tab-bar groups (548/161/164) with
     *  their index, name, actions, bounds, and hidden status. Called when a
     *  tab icon can't be found after 3 script fallbacks. The diag output
     *  shows exactly what the client is rendering, so we stop guessing IDs.
     *  Runs on the client thread via invoke to get live widget data. */
    private void dumpTabBarWidgets(InterfaceTab forTab) {
        try {
            diag("Build 120: WIDGET DUMP for " + forTab + " -- scanning groups 548/161/164, children 0-150");
            String result = Microbot.getClientThread().invoke(() -> {
                StringBuilder sb = new StringBuilder();
                net.runelite.api.Client client = Microbot.getClient();
                for (int group : new int[]{548, 161, 164}) {
                    int found = 0;
                    for (int child = 0; child < 150; child++) {
                        net.runelite.api.widgets.Widget w;
                        try { w = client.getWidget(group, child); }
                        catch (Exception e) { continue; }
                        if (w == null) continue;
                        found++;
                        String name = "";
                        try { if (w.getName() != null) name = w.getName(); } catch (Exception ignored) {}
                        String actions = "";
                        try {
                            String[] acts = w.getActions();
                            if (acts != null) {
                                for (String a : acts) if (a != null) actions += a + "|";
                            }
                        } catch (Exception ignored) {}
                        java.awt.Rectangle b = null;
                        try {
                            net.runelite.api.Point p = w.getCanvasLocation();
                            java.awt.Rectangle wb = w.getBounds();
                            if (wb != null) b = wb;
                        } catch (Exception ignored) {}
                        boolean hidden = true;
                        try { hidden = w.isHidden(); } catch (Exception ignored) {}
                        // Only log widgets that have a name, actions, or are icon-sized (likely tab icons)
                        if (!name.isEmpty() || !actions.isEmpty() || (b != null && b.width > 0 && b.width <= 60 && b.height > 0 && b.height <= 60)) {
                            sb.append("  ").append(group).append(":").append(child)
                              .append(" name='").append(name).append("'")
                              .append(" actions='").append(actions).append("'")
                              .append(" bounds=").append(b == null ? "null" : "[" + b.x + "," + b.y + " " + b.width + "x" + b.height + "]")
                              .append(" hidden=").append(hidden).append("\n");
                        }
                    }
                    sb.append("  [group ").append(group).append(": ").append(found).append(" non-null children]\n");
                }
                return sb.toString();
            });
            // Log in chunks to avoid overly long single lines
            for (String line : result.split("\n")) {
                if (!line.trim().isEmpty()) diag("Build 120 DUMP: " + line);
            }
        } catch (Exception e) {
            diag("Build 120: widget dump failed: " + e);
        }
    }

    /** Build 125: scan ALL widget roots to find the tab strip.
     *  Live 2026-09-27 19:56 (Build 124): the 548/161/164 dump proved the
     *  visible (flashing) prayer icon is NOT in those groups — 548 is hidden,
     *  161/164 are empty. This scans every loaded root interface for
     *  visible, icon-sized widgets (likely tab icons) and logs where they
     *  are. Runs on the client thread; results via diag(). */
    private void scanAllRootsForTabs() {
        try {
            diag("Build 125: ALL-ROOTS SCAN -- looking for the visible tab strip");
            String result = Microbot.getClientThread().invoke(() -> {
                StringBuilder sb = new StringBuilder();
                net.runelite.api.Client client = Microbot.getClient();
                net.runelite.api.widgets.Widget[] roots;
                try {
                    roots = client.getWidgetRoots();
                } catch (Exception e) {
                    return "getWidgetRoots failed: " + e;
                }
                if (roots == null) return "roots null";
                sb.append("roots=").append(roots.length).append("\n");
                for (net.runelite.api.widgets.Widget root : roots) {
                    if (root == null) continue;
                    int gid;
                    try {
                        gid = root.getId();
                    } catch (Exception ignored) {
                        continue;
                    }
                    // Normalize to group ID
                    int group = gid;
                    if ((gid >>> 16) != 0 && (gid & 0xFFFF) == 0) {
                        group = gid >>> 16; // packed as group<<16
                    } else if (gid > 0xFFFF) {
                        group = gid >>> 16; // packed group:child
                    }
                    int iconCount = 0;
                    StringBuilder icons = new StringBuilder();
                    // Scan children 0-200 for visible icon-sized widgets
                    for (int child = 0; child < 200; child++) {
                        net.runelite.api.widgets.Widget w;
                        try {
                            w = client.getWidget(group, child);
                        } catch (Exception e) {
                            continue;
                        }
                        if (w == null) continue;
                        boolean hidden;
                        try {
                            hidden = w.isHidden();
                        } catch (Exception e) {
                            continue;
                        }
                        if (hidden) continue;
                        java.awt.Rectangle b;
                        try {
                            b = w.getBounds();
                        } catch (Exception e) {
                            continue;
                        }
                        if (b == null || b.width < 15 || b.width > 60
                                || b.height < 15 || b.height > 60) continue;
                        iconCount++;
                        if (iconCount <= 10) {
                            String nm = "";
                            try {
                                if (w.getName() != null) nm = w.getName();
                            } catch (Exception ignored) {}
                            icons.append("    ").append(group).append(":").append(child)
                                .append(" '").append(nm).append("'")
                                .append(" [").append(b.x).append(",").append(b.y)
                                .append(" ").append(b.width).append("x").append(b.height)
                                .append("]\n");
                        }
                    }
                    if (iconCount > 0) {
                        sb.append("  group ").append(group)
                          .append(" (raw ").append(gid).append("): ")
                          .append(iconCount).append(" visible icon-sized widgets\n");
                        sb.append(icons);
                    }
                }
                return sb.toString();
            });
            for (String line : result.split("\n")) {
                if (!line.trim().isEmpty()) diag("Build 125 SCAN: " + line);
            }
            // Build 127: cache a compact one-line summary (group numbers with
            // visible icon-sized widgets) so it can be re-diag'd on every
            // fallback -- the full SCAN block scrolls out of the 250-line tail.
            StringBuilder groups = new StringBuilder();
            for (String line : result.split("\n")) {
                String t = line.trim();
                if (t.startsWith("group ")) {
                    // "group 165 (raw 10813440): 12 visible icon-sized widgets"
                    int sp = t.indexOf(' ');
                    int sp2 = t.indexOf(' ', sp + 1);
                    if (groups.length() > 0) groups.append(",");
                    groups.append(sp2 > 0 ? t.substring(sp + 1, sp2) : t.substring(sp + 1));
                }
            }
            lastTabScanSummary = "iconGroups=[" + groups + "]";
            diag("Build 127 SCAN-SUMMARY: " + lastTabScanSummary);
        } catch (Exception e) {
            diag("Build 125: all-roots scan failed: " + e);
        }
    }

    /** Click the flashing shield/helmet button in the bottom-left of Worn Equipment.
     *  The tutorial says: "In the bottom left corner, you will notice a flashing
     *  button with a shield and helmet on it... Click on it now."
     *  BRUTE FORCE: iterate child IDs in group 387 to find the button widget. */
    private boolean clickEquipmentStatsIcon() {
        // REBUILD: was blocking invoke() with brute-force child ID scan.
        // Now uses WorldModel's event-sampled 387:2 bounds (non-blocking).
        // The brute-force fallback is removed; 387:2 is verified via Widget Inspector.
        try {
            java.awt.Rectangle b = worldModel.getWidgetBounds(387, 2);
            if (b != null) {
                int x = b.x + b.width / 2;
                int y = b.y + b.height / 2;
                diag("clickEquipmentStatsIcon: using WorldModel 387:2 at " + x + "," + y);
                Microbot.getMouse().click(x, y);
                diag("MOUSE CLICKED equipment stats icon");
                // Build 63: no fixed sleep — one click per tick.
                statsButtonClicked = true;
                diag("statsButtonClicked = true, next: equip dagger");
                return true;
            } else {
                diag("clickEquipmentStatsIcon: 387:2 not in WorldModel cache, retry next tick");
                return false;
            }
        } catch (Exception e) {
            diag("clickEquipmentStatsIcon failed: " + e);
        }
        return false;
    }

    /** Search widget tree for a tab icon by name in actions/text. */
    private boolean findTabByName(net.runelite.api.widgets.Widget w, String searchFor, java.awt.Rectangle[] out) {
        if (w == null || w.isHidden()) return false;
        try {
            // Check actions (e.g. "View Quests")
            String[] actions = w.getActions();
            if (actions != null) {
                for (String a : actions) {
                    if (a != null && a.toLowerCase().contains(searchFor)) {
                        java.awt.Rectangle b = w.getBounds();
                        if (b != null && b.width > 0 && b.width < 100) { // Tab icons are small
                            out[0] = b;
                            return true;
                        }
                    }
                }
            }
            String text = w.getText();
            if (text != null && text.toLowerCase().contains(searchFor)) {
                java.awt.Rectangle b = w.getBounds();
                if (b != null && b.width > 0 && b.width < 100) {
                    out[0] = b;
                    return true;
                }
            }
            // Check name (e.g. widget name might be "Prayer")
            String name = w.getName();
            if (name != null && name.toLowerCase().contains(searchFor)) {
                java.awt.Rectangle b = w.getBounds();
                if (b != null && b.width > 0 && b.width < 100) {
                    out[0] = b;
                    return true;
                }
            }
            net.runelite.api.widgets.Widget[] children = w.getChildren();
            if (children != null) {
                for (net.runelite.api.widgets.Widget child : children) {
                    if (findTabByName(child, searchFor, out)) return true;
                }
            }
        } catch (Exception e) { /* ignore */ }
        return false;
    }

    /** Scan widgets directly for dialog text (fallback when Rs2Dialogue returns empty).
     *  Looks for long text in the chatbox/dialog area. */
    private String scanDialogTextFromWidgets() {
        // FIX: use invoke(Supplier) — Runnable is async.
        try {
            String result = Microbot.getClientThread().invoke(() -> {
                try {
                    StringBuilder best = new StringBuilder();
                    for (net.runelite.api.widgets.Widget root : Microbot.getClient().getWidgetRoots()) {
                        if (root == null) continue;
                        findDialogTextRecursive(root, best);
                    }
                    return best.toString();
                } catch (Exception e) {
                    return "";
                }
            });
            return result != null ? result : "";
        } catch (Exception e) {
            return "";
        }
    }

    private void findDialogTextRecursive(net.runelite.api.widgets.Widget w, StringBuilder best) {
        if (w == null || w.isHidden()) return;
        try {
            String text = w.getText();
            // Dialog text is typically long (>20 chars) and in the chatbox area (y > 200)
            if (text != null && text.length() > 20 && text.length() > best.length()) {
                java.awt.Rectangle b = w.getBounds();
                // Chatbox is in lower half of screen, exclude tab bar (y < 500)
                if (b != null && b.y > 200 && b.y < 500) {
                    String lower = text.toLowerCase();
                    // Skip glitch text, keep real dialog
                    if (!lower.contains("mismatch") && !lower.contains("archive hash")) {
                        best.setLength(0);
                        best.append(text);
                    }
                }
            }
            net.runelite.api.widgets.Widget[] children = w.getChildren();
            if (children != null) {
                for (net.runelite.api.widgets.Widget child : children) {
                    findDialogTextRecursive(child, best);
                }
            }
        } catch (Exception e) { /* ignore */ }
    }
    private void dumpTabBarCandidates() {
        try {
            Microbot.getClientThread().invoke(() -> {
                try {
                    int count = 0;
                    for (net.runelite.api.widgets.Widget root : Microbot.getClient().getWidgetRoots()) {
                        if (root == null) continue;
                        count += dumpTabCandidatesRecursive(root, 0);
                        if (count > 20) break;
                    }
                    diag("Tab bar scan: found " + count + " candidates");
                } catch (Exception e) {
                    diag("Tab bar scan failed: " + e);
                }
            });
        } catch (Exception e) {
            diag("dumpTabBarCandidates failed: " + e);
        }
    }

    private int dumpTabCandidatesRecursive(net.runelite.api.widgets.Widget w, int depth) {
        int found = 0;
        if (w == null || w.isHidden() || depth > 8) return 0;
        try {
            java.awt.Rectangle b = w.getBounds();
            // Tab icons are small squares (~30x30) in the lower part of screen
            if (b != null && b.width >= 20 && b.width <= 40 && b.height >= 20 && b.height <= 40 && b.y > 300) {
                StringBuilder sb = new StringBuilder();
                sb.append("TabCandidate: ").append(b.x).append(",").append(b.y).append(" ").append(b.width).append("x").append(b.height);
                String name = w.getName();
                if (name != null && !name.isEmpty()) sb.append(" name=").append(name);
                String text = w.getText();
                if (text != null && !text.isEmpty() && text.length() < 30) sb.append(" text=").append(text);
                String[] actions = w.getActions();
                if (actions != null) {
                    for (String a : actions) {
                        if (a != null && !a.isEmpty()) sb.append(" action=").append(a);
                    }
                }
                diag(sb.toString());
                found++;
            }
            net.runelite.api.widgets.Widget[] children = w.getChildren();
            if (children != null) {
                for (net.runelite.api.widgets.Widget child : children) {
                    found += dumpTabCandidatesRecursive(child, depth + 1);
                    if (found > 20) break;
                }
            }
        } catch (Exception e) { /* ignore */ }
        return found;
    }

    /** Try to get rid of an informational dialog: space, then click the dialog. */
    private void dismissDialog() {
        try {
            Rs2Keyboard.keyPress(KeyEvent.VK_SPACE);
        } catch (Exception ignored) {
        }
        // Build 97: dialog is closing; invalidate the cached scan text.
        dialogCacheValid = false;
        Global.sleep(600, 900);
    }

    /** Safe wrappers: the base Rs2Dialogue methods can NPE internally on odd
     *  dialog states. These catch it, log which one failed, and return a safe
     *  default so the bot keeps running instead of crashing. */
    private boolean safeIsInDialogue() {
        try {
            return Rs2Dialogue.isInDialogue();
        } catch (Exception e) {
            log.warn("[TutorialIsland] isInDialogue threw {}, assuming false", e.toString());
            return false;
        }
    }

    private boolean safeHasContinue() {
        try {
            return Rs2Dialogue.hasContinue();
        } catch (Exception e) {
            log.warn("[TutorialIsland] hasContinue threw {}, assuming false", e.toString());
            return false;
        }
    }

    private boolean safeHasSelectAnOption() {
        try {
            return Rs2Dialogue.hasSelectAnOption();
        } catch (Exception e) {
            log.warn("[TutorialIsland] hasSelectAnOption threw {}, assuming false", e.toString());
            return false;
        }
    }

    private String safeGetQuestion() {
        try {
            String q = Rs2Dialogue.getQuestion();
            return q == null ? "" : q;
        } catch (Exception e) {
            log.warn("[TutorialIsland] getQuestion threw {}, assuming empty", e.toString());
            return "";
        }
    }

    private String safeGetDialogueText() {
        try {
            String t = Rs2Dialogue.getDialogueText();
            return t == null ? "" : t;
        } catch (Exception e) {
            log.warn("[TutorialIsland] getDialogueText threw {}, assuming empty", e.toString());
            return "";
        }
    }

    /** True if the "dialog" is actually the client's cache-warning text glitched
     *  into the dialog widget — not a real game dialog. Safe to ignore. */
    private boolean isGlitchDialog() {
        String t = (safeGetQuestion() + " " + safeGetDialogueText()).toLowerCase();
        if (t.contains("mismatch") || t.contains("overlaid") || t.contains("archive hash")) {
            return true;
        }
        // Fallback: check WorldModel's event-sampled dialog text.
        // REBUILD: was a blocking invoke() widget-tree walk.
        try {
            WorldModel.DialogSnapshot snap = worldModel.getDialog();
            String wt = (snap.title + " " + snap.body).toLowerCase();
            return wt.contains("mismatch") || wt.contains("overlaid") || wt.contains("archive hash");
        } catch (Exception e) {
            return false;
        }
    }

    private boolean widgetContainsGlitch(net.runelite.api.widgets.Widget w) {
        if (w == null || w.isHidden()) return false;
        try {
            String text = w.getText();
            if (text != null) {
                String lower = text.toLowerCase();
                if (lower.contains("mismatch") || lower.contains("overlaid cache") || lower.contains("archive hash")) {
                    return true;
                }
            }
            net.runelite.api.widgets.Widget[] children = w.getChildren();
            if (children != null) {
                for (net.runelite.api.widgets.Widget child : children) {
                    if (widgetContainsGlitch(child)) return true;
                }
            }
        } catch (Exception e) { /* ignore */ }
        return false;
    }

    // Recursively search widget tree for "Click here to continue", store coords in out[0], out[1]
    // Returns true if found. Must be called on client thread.
    private boolean findContinueCoords(net.runelite.api.widgets.Widget w, int[] out) {
        if (w == null || w.isHidden()) return false;
        try {
            String text = w.getText();
            if (text != null && text.contains("Click here to continue")) {
                java.awt.Rectangle bounds = w.getBounds();
                if (bounds != null && bounds.width > 0) {
                    out[0] = bounds.x + bounds.width / 2;
                    out[1] = bounds.y + bounds.height / 2;
                    return true;
                }
            }
            net.runelite.api.widgets.Widget[] children = w.getChildren();
            if (children != null) {
                for (net.runelite.api.widgets.Widget child : children) {
                    if (findContinueCoords(child, out)) return true;
                }
            }
        } catch (Exception e) { /* ignore */ }
        return false;
    }

    private boolean spamDialogue(long timeoutMs) {
        long deadline = System.currentTimeMillis() + timeoutMs;
        int unknownStuck = 0;
        while (System.currentTimeMillis() < deadline && !pausedForManual) {
            if (checkIronmanPause()) return false;
            if (isGlitchDialog()) {
                diag("Ignoring client glitch dialog (cache warnings, not a real dialog)");
                return true;
            }
            if (safeHasSelectAnOption()) {
                // Don't just return — actually pick the right option.
                // (Previously returned true for "caller handles", but callers didn't.)
                int opt = chooseDialogueOption();
                // Quest Guide special case: after the tab is clicked, the only
                // option dialog is "Would you like to hear about quests again?"
                // -> always pick option 2 ("Nope, I'm ready to move on!").
                // The dialog text is unreadable via API, so use state instead.
                // Pick 2 if: tab already clicked, OR we're in the Quest Guide
                // stage (the only 2-option dialog there is "hear again?").
                boolean inQuestGuide = false;
                try {
                    inQuestGuide = getCurrentState() == Stage.QUEST_GUIDE;
                } catch (Exception ignored) {}
                // Build 158 (Alex): scope the option-2 override to Quest Guide
                // ONLY. questTabClicked persists from earlier and corrupts
                // later dialogue choices (Prayer/Magic stages).
                if (inQuestGuide) {
                    opt = 2;
                    diag("Quest Guide option: picking 2 (move on)");
                }
                diag("spamDialogue selecting option " + opt);
                clickDialogueOption(opt);
                Global.sleep(900, 1300);
                continue;
            }
            // Ask the instruction follower FIRST: it only acts on dialogs it
            // recognizes (skill titles, tab keywords), so this is safe. This
            // avoids getting stuck silently on a bogus "continue" detection.
            if (safeIsInDialogue() && followTutorialInstruction()) {
                unknownStuck = 0;
                Global.sleep(900, 1300);
                continue;
            }
            if (safeHasContinue()) {
                if (unknownStuck == 0) {
                    diag("Clicking continue on: '" + safeGetQuestion() + "'");
                }
                // Belt and suspenders: click the widget AND press space.
                // If the widget click doesn't register, space will.
                // Try direct widget click via client thread as fallback.
                try { Rs2Dialogue.clickContinue(); } catch (Exception ignored) {}
                try { Rs2Keyboard.keyPress(KeyEvent.VK_SPACE); } catch (Exception ignored) {}
                // REBUILD: removed the "nuclear option" full widget-tree walk
                // (blocking invoke, expensive). Rs2Dialogue.clickContinue()
                // + Space above is sufficient; retry next tick if needed.
                unknownStuck = 0;
            } else if (!safeIsInDialogue()) {
                return true;
            } else {
                // In a dialog we don't recognize and can't continue:
                // mash space like a human would.
                unknownStuck++;
                dismissDialog();
                if (unknownStuck % 8 == 0) {
                    String q = "";
                    try { q = safeGetQuestion() + " / " + safeGetDialogueText(); } catch (Exception ignored) {}
                    if (q.length() > 140) q = q.substring(0, 140) + "...";
                    diag("Mashing space on unrecognized dialog (" + unknownStuck + " tries): '" + q + "'");
                }
            }
            Global.sleep(450, 750);
        }
        boolean done = !safeIsInDialogue();
        if (!done) {
            String q = "";
            try { q = safeGetQuestion() + " / " + safeGetDialogueText(); } catch (Exception ignored) {}
            if (q.length() > 140) q = q.substring(0, 140) + "...";
            diag("Dialog timed out after " + (timeoutMs / 1000) + "s. Still showing: '" + q + "'");
        }
        return done;
    }

    /**
     * Handles dialogue that may contain option prompts: picks the first option
     * (used for the Guide's experience question), clicks continue otherwise.
     */
    private boolean dialogueWithFirstOption() {
        long deadline = System.currentTimeMillis() + 90000;
        while (System.currentTimeMillis() < deadline && !pausedForManual) {
            if (checkIronmanPause()) return false;
            if (safeHasSelectAnOption()) {
                // Smart option selection: don't always pick option 1.
                // For "hear about quests again?" pick "move on". For "how many
                // to cook?" pick 1. Otherwise default to 1.
                int optionToPick = chooseDialogueOption();
                diag("Selecting dialogue option " + optionToPick);
                Rs2Dialogue.keyPressForDialogueOption(optionToPick);
            } else if (safeHasContinue()) {
                Rs2Dialogue.clickContinue();
            } else if (!safeIsInDialogue()) {
                return true;
            } else if (followTutorialInstruction()) {
                Global.sleep(900, 1300);
            }
            Global.sleep(450, 750);
        }
        return !safeIsInDialogue();
    }

    /** Click a dialogue option by index (1-based) using the mouse.
     *  More reliable than keyPressForDialogueOption when the client is laggy. */
    private boolean clickDialogueOption(int index) {
        try {
            // REBUILD: was blocking invoke(). Rs2Dialogue.getDialogueOptions()
            // uses non-blocking Rs2Widget.getWidget() internally.
            java.util.List<Widget> options = null;
            try {
                options = Rs2Dialogue.getDialogueOptions();
            } catch (Exception e) {
                // fall through to null
            }
            if (options != null && options.size() >= index) {
                Widget w = options.get(index - 1);
                java.awt.Rectangle b = w.getBounds();
                if (b != null && b.width > 0) {
                    int x = (int) b.getCenterX();
                    int y = (int) b.getCenterY();
                    diag("Clicking dialogue option " + index + " at " + x + "," + y);
                    Microbot.getMouse().click(x, y);
                    Global.sleep(800, 1200);
                    return true;
                }
            }
            // Fallback to keypress
            diag("Option widget not found, using keypress for option " + index);
            Rs2Dialogue.keyPressForDialogueOption(index);
            Global.sleep(800, 1200);
            return true;
        } catch (Exception e) {
            diag("clickDialogueOption failed: " + e);
            return false;
        }
    }
    private int chooseDialogueOption() {
        try {
            String question = safeGetQuestion();
            if (question == null) question = "";
            String q = question.toLowerCase();
            java.util.List<Widget> options = Rs2Dialogue.getDialogueOptions();
            if (options == null || options.isEmpty()) return 1;
            // "Would you like to hear about X again?" -> pick "No"/"move on"/"Nope"
            if (q.contains("hear about") && q.contains("again")) {
                for (int i = 0; i < options.size(); i++) {
                    String t = options.get(i).getText();
                    if (t != null) {
                        String tl = t.toLowerCase();
                        if (tl.contains("move on") || tl.contains("nope") || 
                            (tl.contains("no") && !tl.contains("know"))) {
                            diag("Question '" + question + "' -> picking '" + t + "' (option " + (i+1) + ")");
                            return i + 1;
                        }
                    }
                }
            }
            // "How many would you like to cook?" -> pick 1 (or the first numeric)
            if (q.contains("how many")) {
                return 1;
            }
            // Default: option 1
            return 1;
        } catch (Exception e) {
            return 1;
        }
    }

    /** If any dialogue option mentions ironman, stop and let the user answer by hand. */
    private boolean checkIronmanPause() {
        if (!safeHasSelectAnOption()) return false;
        try {
            for (Widget w : Rs2Dialogue.getDialogueOptions()) {
                String t = w.getText();
                if (t != null && t.toLowerCase().contains("ironman")) {
                    pauseForManual("answer the Ironman question yourself,");
                    return true;
                }
            }
            String q = safeGetQuestion();
            if (q != null && q.toLowerCase().contains("ironman")) {
                pauseForManual("answer the Ironman question yourself,");
                return true;
            }
        } catch (Exception e) {
            log.debug("[TutorialIsland] ironman check failed", e);
        }
        return false;
    }

    /** Fast object find: scans the loaded scene directly (no 2-min cache wait),
     *  wraps the GameObject in Rs2TileObjectModel so .click() works.
     *  Falls back to the cache query if the scene scan misses.
     *  NOTE: scene queries MUST run on the client thread. */
    private Rs2TileObjectModel findObjectFast(String name, int radius) {
        // REBUILD: was a blocking invoke() scene scan (90s+ hangs). Now delegates
        // to the event-driven Rs2TileObjectCache query which never blocks.
        // A cache miss returns null; caller retries next tick.
        return findObject(name, radius);
    }

    private Rs2TileObjectModel findObject(String name, int radius) {
        try {
            // Build 104: ZERO blocking client-thread invokes in steady state.
            // Build 103's .within(radius).withName(name).nearest() still
            // called the blocking getName() (~450ms) on every object within
            // radius -- ~29 objects in the bank x 450ms = the 13.2s
            // "booth find took 13221ms (HANG!)" seen live 17:02:38/17:02:57.
            // Now: distance filter is pure math on the non-blocking Rs2Player
            // state cache, names come from the id->name cache (resolved once
            // per session, persisted to disk), and nearest is computed
            // manually. Same semantics as before (nearest match within
            // radius), no blocking calls once names are cached.
            WorldPoint playerLoc = Rs2Player.getWorldLocation();
            if (playerLoc == null) return null;
            Rs2TileObjectModel best = null;
            int bestDist = Integer.MAX_VALUE;
            java.util.List<Rs2TileObjectModel> all =
                    Microbot.getRs2TileObjectCache().query().toList();
            for (Rs2TileObjectModel o : all) {
                WorldPoint wp;
                try {
                    wp = o.getWorldLocation();
                } catch (Exception e) {
                    continue;
                }
                if (wp == null || wp.distanceTo(playerLoc) > radius) continue;
                String n = cachedObjectName(o);
                if (n == null || !n.equalsIgnoreCase(name)) continue;
                int d = wp.distanceTo(playerLoc);
                if (d < bestDist) {
                    bestDist = d;
                    best = o;
                }
            }
            return best;
        } catch (Exception e) {
            return null;
        }
    }

    /** Build 104: resolve a tile object's name via the per-session id->name
     *  cache. Rs2TileObjectModel.getName() does a blocking
     *  ClientThread.invoke() (~450ms) on EVERY call; resolving once per id
     *  and reusing turns every repeat query non-blocking. */
    private String cachedObjectName(Rs2TileObjectModel obj) {
        int id;
        try {
            id = obj.getId();
        } catch (Exception e) {
            return null;
        }
        String cached = objNameCache.get(id);
        if (cached != null) return cached;
        String name = null;
        try {
            name = obj.getName();
        } catch (Exception ignored) {}
        if (name != null && !name.isEmpty()) {
            objNameCache.put(id, name);
            maybeSaveObjNameCache();
        }
        return name;
    }

    /** Build 104: load the persisted id->name cache (written by
     *  maybeSaveObjNameCache). Fail-open: any problem -> resolve live. */
    private void loadObjNameCache() {
        try {
            java.util.Properties p = new java.util.Properties();
            try (java.io.FileInputStream in =
                         new java.io.FileInputStream(OBJNAME_CACHE_PATH)) {
                p.load(in);
            }
            int rev = -1;
            try {
                rev = Microbot.getClient().getRevision();
            } catch (Exception ignored) {}
            if (!p.getProperty("__rev", "-1").equals(String.valueOf(rev))) {
                return; // game updated: ids may map to different names now
            }
            for (String k : p.stringPropertyNames()) {
                if (k.equals("__rev")) continue;
                try {
                    objNameCache.put(Integer.parseInt(k), p.getProperty(k));
                } catch (NumberFormatException ignored) {}
            }
            if (!objNameCache.isEmpty()) {
                diag("Build 104: loaded " + objNameCache.size()
                        + " cached object names (rev " + rev + ")");
            }
        } catch (Exception ignored) {
            // no cache file yet -- resolve live
        }
    }

    /** Build 104: persist the id->name cache, throttled to one write per
     *  30s. Keeps restarts (frequent during debugging) from paying the
     *  ~13s name-resolution cost again. */
    private void maybeSaveObjNameCache() {
        long now = System.currentTimeMillis();
        if (now - objNameCacheLastSave < 30000) return;
        objNameCacheLastSave = now;
        try {
            java.util.Properties p = new java.util.Properties();
            int rev = -1;
            try {
                rev = Microbot.getClient().getRevision();
            } catch (Exception ignored) {}
            p.setProperty("__rev", String.valueOf(rev));
            for (java.util.Map.Entry<Integer, String> e : objNameCache.entrySet()) {
                p.setProperty(String.valueOf(e.getKey()), e.getValue());
            }
            try (java.io.FileOutputStream out =
                         new java.io.FileOutputStream(OBJNAME_CACHE_PATH)) {
                p.store(out, "TutorialIslandScript object id->name cache");
            }
        } catch (Exception ignored) {}
    }

    /** Fast object find that scans the loaded scene directly instead of waiting
     *  for the Rs2TileObjectCache to populate. Returns the nearest matching
     *  GameObject's world location, or null if not in the scene.
     *  NOTE: scene queries MUST run on the client thread. */
    private WorldPoint findObjectInScene(String name, int radius) {
        // REBUILD: was a blocking invoke() scene scan. Now uses the
        // event-driven cache (non-blocking). Returns null on cache miss.
        try {
            Rs2TileObjectModel m = findObject(name, radius);
            return m != null ? m.getWorldLocation() : null;
        } catch (Exception e) {
            return null;
        }
    }

    private boolean interactObject(String name, String action) {
        Rs2TileObjectModel obj = findObjectTimeout(name, 25);
        if (obj == null) {
            diag("Wanted to click '" + action + "' on '" + name + "' but it is not nearby");
            return false;
        }
        WorldPoint objPos = obj.getWorldLocation();
        // Never path INTO the object: doors sit in walls, so their own tile is
        // not walkable and the click's auto-walk spins replanning forever.
        // Walk to an adjacent walkable tile first, then click directly.
        if (Rs2Player.getWorldLocation().distanceTo(objPos) > 4) {
            WorldPoint standTile = adjacentWalkable(objPos);
            if (standTile != null) {
                Microbot.status = "Tutorial Island: walking to " + name + "...";
                Rs2Walker.walkTo(standTile);
                sleepUntil(() -> Rs2Player.getWorldLocation().distanceTo(objPos) <= 5, 9000);
            }
        }
        if (!Rs2Camera.isTileOnScreen(obj.getLocalLocation())) {
            Rs2Camera.turnTo(obj);
        }
        boolean ok = obj.click(action);
        sleep(900, 1400);
        return ok;
    }

    /**
     * Click an action on an NPC (fishing spots are NPCs, not objects!).
     * Walks to the bank/shore first instead of pathing into the NPC's tile.
     */
    private boolean interactNpc(String name, String action) {
        Rs2NpcModel npc = findNpc(name);
        if (npc == null) {
            diag("Wanted to click '" + action + "' on '" + name + "' but it is not nearby");
            Microbot.status = "Tutorial Island: looking for " + name + "...";
            sleep(600, 900);
            return false;
        }
        WorldPoint npcPos = npc.getWorldLocation();
        if (Rs2Player.getWorldLocation().distanceTo(npcPos) > 6) {
            WorldPoint standTile = adjacentWalkable(npcPos);
            if (standTile != null) {
                Microbot.status = "Tutorial Island: walking to " + name + "...";
                Rs2Walker.walkTo(standTile);
                sleepUntil(() -> Rs2Player.getWorldLocation().distanceTo(npcPos) <= 7, 9000);
            }
        }
        boolean ok = npc.click(action);
        sleep(900, 1400);
        return ok;
    }

    /** Nearest walkable tile next to the given point (never the point itself). */
    private WorldPoint adjacentWalkable(WorldPoint p) {
        WorldPoint player = Rs2Player.getWorldLocation();
        WorldPoint best = null;
        int bestDist = Integer.MAX_VALUE;
        for (int dx = -2; dx <= 2; dx++) {
            for (int dy = -2; dy <= 2; dy++) {
                if (dx == 0 && dy == 0) continue;
                WorldPoint t = p.dx(dx).dy(dy);
                try {
                    if (Rs2Tile.isTileReachable(t)) {
                        int d = player.distanceTo(t);
                        if (d < bestDist) {
                            bestDist = d;
                            best = t;
                        }
                    }
                } catch (Exception ignored) {
                }
            }
        }
        return best;
    }

    /** Use an inventory item on a nearby game object (e.g. raw shrimps -> fire). */
    private boolean useItemOnObject(String itemName, String objectName) {
        Rs2TileObjectModel obj = findObject(objectName, 20);
        if (obj == null) {
            log.warn("[TutorialIsland] Object not found: {}", objectName);
            return false;
        }
        if (!Rs2Inventory.use(itemName)) {
            log.warn("[TutorialIsland] Could not select item: {}", itemName);
            return false;
        }
        Global.sleep(300, 600);
        return obj.click("");
    }

    private boolean waitForItem(String itemName, int timeoutMs) {
        diag("Waiting for '" + itemName + "' (up to " + (timeoutMs / 1000) + "s)...");
        boolean got = Global.sleepUntil(() -> Rs2Inventory.contains(itemName), timeoutMs);
        diag(got ? "Got '" + itemName + "'" : "Timed out waiting for '" + itemName + "'");
        return got;
    }

    private void waitForStill() {
        Global.sleepUntil(() -> !Rs2Player.isMoving() && !Rs2Player.isAnimating(), 15000);
    }

    // ------------------------------------------------------------------
    // Stages
    // ------------------------------------------------------------------

    private void doCharCreator() {
        Microbot.status = "Tutorial Island: character creator";
        // Only hunt for the confirm button if we're actually at the start.
        if (npcReachable("Gielinor Guide", 30) || Rs2Widget.findWidget("Confirm") != null) {
            // Look for the confirm button for a while, then click it.
            long deadline = System.currentTimeMillis() + 25000;
            boolean confirmed = false;
            while (System.currentTimeMillis() < deadline) {
                Widget btn = Rs2Widget.findWidget("Confirm");
                if (btn == null) btn = Rs2Widget.findWidget("Accept");
                if (btn != null) {
                    Rs2Widget.clickWidget(btn);
                    confirmed = true;
                    break;
                }
                Global.sleep(800, 1200);
            }
            if (confirmed) {
                Global.sleepUntil(() -> Rs2Widget.findWidget("Confirm") == null
                        && Rs2Widget.findWidget("Accept") == null, 15000);
                // A display-name prompt may appear; that needs a human.
                Global.sleep(2000, 3000);
                Widget namePrompt = Rs2Widget.findWidget("display name");
                if (namePrompt == null) namePrompt = Rs2Widget.findWidget("Display name");
                if (namePrompt != null) {
                    pauseForManual("choose your display name,");
                    return;
                }
            }
        }
        charCreatorDone = true;
    }

    private void doGuide() {
        Microbot.status = "Tutorial Island: Gielinor Guide";
        if (npcReachable("Survival Expert", 35)) {
            guideDone = true;
            return;
        }
        if (!talkTo("Gielinor Guide")) return;
        if (!dialogueWithFirstOption()) return; // answers the experience question with option 1

        // He asks you to open the settings tab — PHYSICAL CLICK, not hotkey.
        clickTabIcon(InterfaceTab.SETTINGS, true);

        if (!talkTo("Gielinor Guide")) return;
        if (!spamDialogue()) return;

        // Leave through the door.
        interactObject("Door", "Open");
        if (Global.sleepUntil(() -> npcReachable("Survival Expert", 35), 30000)) {
            guideDone = true;
        }
    }

    private boolean survivalTalked = false;

    private void doSurvival() {
        try {
            doSurvivalInner();
        } catch (Exception e) {
            log.warn("[TutorialIsland] doSurvival caught {}, retrying next tick", e.toString());
            Global.sleep(1500, 2500);
        }
    }

    // Inventory check with timeout — Rs2Inventory.contains() can hang
    // indefinitely when the inventory cache is empty (it blocks on the
    // client thread). If it doesn't return in 2s, assume false so the
    // tick keeps running instead of freezing.
    private boolean invContains(String name) {
        try {
            return CompletableFuture.supplyAsync(() -> {
                try {
                    return Rs2Inventory.contains(name);
                } catch (Exception e) {
                    return false;
                }
            }).get(2, TimeUnit.SECONDS);
        } catch (TimeoutException e) {
            diag("invContains(" + name + ") timed out, assuming false");
            return false;
        } catch (Exception e) {
            return false;
        }
    }

    // Build 70: live inventory read straight from the item container on the
    // client thread, bypassing Rs2Inventory's static cache. Root cause of the
    // post-restart TALK_VANNAKA loop: after the Build 69 relaunch,
    // invContains("Shortbow") returned false on every tick for minutes while
    // the shortbow sat visibly in the inventory, so the combat fast-forward
    // never fired and the bot re-talked Vannaka forever (each talk re-opens
    // the "Rat ranging" info dialog; dismissing it changes nothing, so the
    // state never advances). Rs2Inventory.items() only repopulates when its
    // static list is empty and otherwise trusts ItemContainerChanged events;
    // on a fresh session that trust is misplaced. This reads the live
    // container every call via the blocking invoke(Supplier) form.
    private boolean invHasDirect(String name) {
        // REBUILD: was a blocking invoke() direct inventory read (bypassed the
        // cache due to staleness). Now uses Rs2Inventory.contains() which reads
        // the event-driven inventory cache (non-blocking). If the cache hasn't
        // updated yet, returns false and the caller retries next tick.
        try {
            return net.runelite.client.plugins.microbot.util.inventory.Rs2Inventory.contains(name);
        } catch (Exception e) {
            return false;
        }
    }

    /** Non-logging variant of invContains for the staleness comparison above. */
    private boolean invContainsQuiet(String name) {
        try {
            return CompletableFuture.supplyAsync(() -> {
                try {
                    return Rs2Inventory.contains(name);
                } catch (Exception e) {
                    return false;
                }
            }).get(2, TimeUnit.SECONDS);
        } catch (Exception e) {
            return false;
        }
    }

    // Build 71: live WORN-equipment read straight from the equipment container
    // on the client thread, bypassing Rs2Equipment's cache the same way
    // invHasDirect bypasses Rs2Inventory's. Used for the sword+shield
    // fast-forward and bow-worn checks on fresh sessions.
    private boolean equipmentHasDirect(String name) {
        // REBUILD: was blocking invoke() direct container read. Now uses
        // Rs2Equipment.all() which reads the event-driven in-memory cache
        // (non-blocking).
        try {
            return net.runelite.client.plugins.microbot.util.equipment.Rs2Equipment
                .all(name, false)
                .findAny()
                .isPresent();
        } catch (Exception e) {
            return false;
        }
    }

    // Build 71: comma-separated inventory names via live container read, for
    // the STUCK_NO_BOW diagnostic so Julien can see exactly what the bot holds.
    private String inventoryNamesDirect() {
        // REBUILD: was blocking invoke(). Now uses Rs2Inventory.all()
        // (event-driven cache, non-blocking).
        try {
            java.util.List<net.runelite.client.plugins.microbot.util.inventory.Rs2ItemModel> items =
                net.runelite.client.plugins.microbot.util.inventory.Rs2Inventory.all();
            if (items == null || items.isEmpty()) return "(empty)";
            StringBuilder sb = new StringBuilder();
            for (net.runelite.client.plugins.microbot.util.inventory.Rs2ItemModel item : items) {
                if (item == null) continue;
                if (sb.length() > 0) sb.append(", ");
                sb.append(item.getName());
                if (item.getQuantity() > 1) sb.append(" x").append(item.getQuantity());
            }
            return sb.length() == 0 ? "(empty)" : sb.toString();
        } catch (Exception e) {
            return "(error: " + e.getMessage() + ")";
        }
    }

    // Object find with timeout — findObject can also hang on cache access.
    // Increased to 10s: the tile object cache is slow to populate.
    private Rs2TileObjectModel findObjectTimeout(String name, int radius) {
        // 1. Fast scene scan (milliseconds, not minutes)
        Rs2TileObjectModel obj = findObjectFast(name, radius);
        if (obj != null) return obj;

        // 2. Camera sweep: rotate left/right and pitch up/down, rescanning.
        //    If the object is loaded but off-screen, this brings it into view.
        diag("findObjectTimeout: '" + name + "' not found, sweeping camera");
        try {
            // Rotate right (3 steps)
            for (int i = 0; i < 3; i++) {
                Rs2Keyboard.keyPress(KeyEvent.VK_RIGHT);
                Global.sleep(350, 500);
                Rs2Keyboard.keyRelease(KeyEvent.VK_RIGHT);
                obj = findObjectFast(name, radius);
                if (obj != null) return obj;
            }
            // Pitch up (look down at ground)
            Rs2Keyboard.keyPress(KeyEvent.VK_UP);
            Global.sleep(350, 500);
            Rs2Keyboard.keyRelease(KeyEvent.VK_UP);
            obj = findObjectFast(name, radius);
            if (obj != null) return obj;
            // Rotate left (3 steps)
            for (int i = 0; i < 3; i++) {
                Rs2Keyboard.keyPress(KeyEvent.VK_LEFT);
                Global.sleep(350, 500);
                Rs2Keyboard.keyRelease(KeyEvent.VK_LEFT);
                obj = findObjectFast(name, radius);
                if (obj != null) return obj;
            }
            // Pitch down (look at horizon)
            Rs2Keyboard.keyPress(KeyEvent.VK_DOWN);
            Global.sleep(350, 500);
            Rs2Keyboard.keyRelease(KeyEvent.VK_DOWN);
            obj = findObjectFast(name, radius);
            if (obj != null) return obj;
        } catch (Exception ignored) {}

        // 3. Cache fallback (short timeout, fail fast)
        try {
            return CompletableFuture.supplyAsync(() -> {
                try {
                    return findObject(name, radius);
                } catch (Exception e) {
                    return null;
                }
            }).get(5, TimeUnit.SECONDS);
        } catch (TimeoutException e) {
            diag("findObject(" + name + ") timed out, assuming null");
            return null;
        } catch (Exception e) {
            return null;
        }
    }

    // Direct object find — MUST run on client thread (scene queries fail from background threads).
    // Does a RAW SCENE SCAN (like WebWalk) — bypasses the broken cache entirely.
    // Looks for Tutorial Island doors/gates by ID: Gate 9708, Door 9709, etc.
    private boolean clickDoorDirect(String action) {
        return clickDoorDirect(action, 10);
    }

    /** REBUILD: was blocking invoke(Supplier). Now calls the non-blocking
     *  cache-based inner directly (no client thread needed). */
    private boolean clickDoorDirect(String action, int radius) {
        try {
            return clickDoorDirectInner(action, radius);
        } catch (Exception e) {
            diag("Door find failed: " + e.toString());
            return false;
        }
    }

    /** Build 90: BANK BOOTH PHYSICAL LEFT-CLICK. Same failure mode as the
     *  poll booth (fixed in Build 88): Rs2TileObjectModel.click("Use") goes
     *  through Microbot.doInvoke -> mouse.click(point, entry), which opens
     *  the right-click menu but never selects the "Use" row -- the click
     *  returns true unconditionally yet the bank never opens. Observed live
     *  2026-09-27 15:29-15:38: the bot clicked the bank booth with "Use"
     *  EVERY tick for 9+ minutes ("Build 74: clicked bank booth with 'Use':
     *  true") while Rs2Bank.isOpen() stayed false -- the 15:38:07
     *  screenshot shows the player standing at the booth with the flashing
     *  tutorial arrow and no bank interface open. "Use" is the tutorial
     *  booth's default/left-click menu entry (Build 74), so a plain
     *  physical left-click fires it -- the exact Build 88 poll-booth fix,
     *  now applied to the bank booth. Verified completion stays the same:
     *  Rs2Bank.isOpen() stable for 3 ticks (Build 84). */
    private void clickBoothDirect(String action) {
        try {
            // Build 101: cache-only queries (same root cause as the poll
            // booth: findObjectFast()'s blocking invoke() scene scan has
            // hung 90s+ on a cold cache). The event-driven
            // Rs2TileObjectCache query never blocks; a miss retries next
            // tick instead of hanging this one.
            Rs2TileObjectModel booth = findObject("Bank booth", 15);
            if (booth == null) {
                // Try a looser name in case the object is just "Booth".
                booth = findObject("Booth", 15);
            }
            if (booth == null) return;
            // Build 115: PROXIMITY GATE (text-independent "I can't reach
            // that!" fix). Live 2026-09-27 18:44 the bot clicked the booth
            // every ~2s from too far away; the game answered "I can't reach
            // that!" every time (visible in the 18:44:41 screenshot), and the
            // Build 109 text-based recovery never fired (dialog text not
            // readable at check time). Never click a booth we can't reach —
            // walk adjacent first; the click happens on a later tick.
            try {
                WorldPoint bp = booth.getWorldLocation();
                WorldPoint pp = null;
                try { pp = Rs2Player.getWorldLocation(); } catch (Exception ignored) {}
                if (bp != null && pp != null && pp.distanceTo(bp) > 4) {
                    diag("Build 115: player " + pp.distanceTo(bp)
                            + " tiles from booth — walking adjacent before clicking");
                    walkAdjacentToBooth();
                    return;
                }
            } catch (Exception e) {
                diag("Build 115: booth proximity check failed: " + e);
            }
            if (!Rs2Camera.isTileOnScreen(booth.getLocalLocation())) {
                Rs2Camera.turnTo(booth);
            }
            // Build 104: the tile can read "on screen" while the object's
            // actual click point projects off-screen. Turn to face it and
            // retry next tick instead of clicking a doomed point.
            if (!isClickPointOnScreen(booth)) {
                diag("Build 104: bank booth click point off-screen, turning camera");
                Rs2Camera.turnTo(booth);
                return;
            }
            if (leftClickObject(booth)) {
                diag("Build 94: physically left-clicked bank booth");
                // Build 121: CIRCUIT BREAKER. Live 2026-09-27 19:42 (Build 119):
                // bot clicked the booth 20+ times with opened=false while the
                // game instruction said "go to the chapel" (BANK already done).
                // If the booth won't open after 15 clicks, the stage is wrong
                // -- stop clicking and force PRAYER (walk to chapel).
                boothClickCount++;
                if (boothClickCount >= 15) {
                    diag("Build 121: BANK STUCK -- booth clicked 15x, never opened. Game has likely advanced past BANK. Forcing PRAYER stage.");
                    boothClickCount = 0;
                    // Build 121 fix: the state machine transitions BANK->PRAYER
                    // when bankDone==true (line 712), NOT via startStage (which
                    // is only read once by initialState()). Set bankDone to
                    // trigger the real transition.
                    bankDone = true;
                    resetPrayerFlags();
                }
            } else {
                diag("Build 94: leftClickObject missed (booth off-screen?), retry next tick");
            }
        } catch (Exception e) {
            diag("Build 94: clickBoothDirect failed: " + e);
        }
    }

    /** Build 109: is the "I can't reach that!" dialog open? */
    private boolean cantReachDialogOpen() {
        if (!safeIsInDialogue()) return false;
        String body = "";
        try { body = safeGetDialogueText(); } catch (Exception ignored) {}
        if (body == null) body = "";
        body = getDialogBodyCached("", body);
        return body.toLowerCase().contains("reach that");
    }

    /** Build 109: walk adjacent to the bank booth. The pathfinder routes to
     *  the object's tile and stops adjacent (it can't walk into the booth).
     *  Called after the game answers a booth click with "I can't reach
     *  that!" — the click is retried next tick from the new position. */
    private void walkAdjacentToBooth() {
        try {
            Rs2TileObjectModel booth = findObject("Bank booth", 15);
            if (booth == null) booth = findObject("Booth", 15);
            if (booth == null) {
                diag("Build 109: no booth found to walk to");
                return;
            }
            WorldPoint bp = booth.getWorldLocation();
            if (bp == null) return;
            diag("Build 109: walking adjacent to bank booth at " + bp);
            Rs2Walker.walkTo(bp);
        } catch (Exception e) {
            diag("Build 109: walk to booth failed: " + e);
        }
    }

    /** Build 85: click the POLL BOOTH (separate from the bank booth). The
     *  tutorial requires clicking it after the bank is closed.
     *  Build 87: the return value is NOT trusted (Rs2TileObjectModel.click
     *  returns true unconditionally) -- the caller verifies via the game's
     *  instruction dialog and retries. One attempt per call. */
    private boolean clickPollBoothDirect() {
        try {
            long t0 = System.currentTimeMillis();
            Rs2TileObjectModel booth;
            // Build 101: cache-only query, NEVER a blocking scene scan.
            // Build 99's timing diagnostic proved findObjectFast()'s
            // client-thread invoke() scene scan BLOCKED 90.3s on the first
            // poll-booth attempt of the session (diag 2026-09-27 16:30:31
            // -> 16:32:01 "booth find took 90300ms (HANG!)"):
            // cachedPollBoothPos is only populated AFTER the first
            // successful find, so a cold cache fell through to the full
            // blocking scan. Per repo house rules, object queries must use
            // the event-driven Rs2TileObjectCache (findObject), which never
            // blocks; a cache miss retries on the next tick.
            booth = findObject("Poll booth", 15);
            long t1 = System.currentTimeMillis();
            if (t1 - t0 > 2000) {
                diag("Build 101: booth find took " + (t1 - t0) + "ms (HANG!)");
            }
            if (booth == null) {
                diag("Build 101: poll booth not in object cache this tick, retrying next tick");
                return false;
            }
            // Cache the position for next time.
            try {
                net.runelite.api.coords.WorldPoint wp = booth.getWorldLocation();
                if (wp != null) cachedPollBoothPos = wp;
            } catch (Exception ignored) {}
            if (!Rs2Camera.isTileOnScreen(booth.getLocalLocation())) {
                long tc0 = System.currentTimeMillis();
                Rs2Camera.turnTo(booth);
                long tc1 = System.currentTimeMillis();
                if (tc1 - tc0 > 2000) {
                    diag("Build 99: camera turnTo took " + (tc1 - tc0) + "ms (HANG!)");
                }
            }
            // Build 104: the tile can read "on screen" while the object's
            // actual click point projects off-screen (seen live
            // 17:02:38/17:02:57: poll booth found, click point (-46,315),
            // leftClickObject refused it, retry loop never turned the camera
            // because isTileOnScreen(tile) was true -- deterministic miss
            // loop). Turn to face it and retry next tick instead.
            if (!isClickPointOnScreen(booth)) {
                diag("Build 104: poll booth click point off-screen, turning camera");
                Rs2Camera.turnTo(booth);
                return false;
            }
            // Build 88: PHYSICAL LEFT-CLICK. Rs2TileObjectModel.click("Use")
            // goes through Microbot.doInvoke -> mouse.click(point, entry),
            // which opens the right-click menu but never selects the "Use"
            // row (observed live 2026-09-27 15:02:08 and 15:19:46: menu stuck
            // open on "Use Poll booth", action never fired, and Build 87's
            // Escape+retry loop just re-opens the menu forever). "Use" is the
            // top/default menu entry (highlighted in both screenshots), so a
            // plain left-click fires it -- exactly what the tutorial asks for
            // ("click on the indicated poll booth").
            if (leftClickObject(booth)) {
                diag("Build 88: physically left-clicked poll booth");
                return true;
            }
            diag("Build 88: leftClickObject missed (booth off-screen?), retry next tick");
            return false;
        } catch (Exception e) {
            diag("Build 85: clickPollBoothDirect failed: " + e);
            return false;
        }
    }

    /** Build 87: tri-state check of the game's own tutorial instruction.
     *  Returns TRUE if the readable instruction still asks for the poll
     *  booth, FALSE if readable and moved past it, NULL if the instruction
     *  text is blank/unreadable (caller must fail closed, not guess).
     *  Build 89: match "poll booth" (the object), NOT "poll" -- the
     *  post-click 'Moving on' instruction itself says 'Polls are run
     *  periodically...', so the old substring matched forever and the
     *  step never verified complete. */
    private Boolean pollBoothStillWanted() {
        try {
            String title = safeGetQuestion();
            String body = safeGetDialogueText();
            // Build 98: use cached dialog body (was calling scanDialogTextFromWidgets()
            // directly every tick after pollClickedOnce=true -> 15-24s ticks).
            body = getDialogBodyCached(title, body);
            // Build 94: if the dialog title is "Moving on", the poll is DONE.
            // The widget scan picks up "Poll booth" from the open right-click
            // menu, so text.contains("poll booth") stays true forever even
            // though the dialog is the post-poll "Moving on". Julien caught
            // this live 2026-09-27: the bot kept re-clicking the booth with
            // the "Moving on" dialog up instead of exiting to prayer.
            if (title != null && title.toLowerCase().contains("moving on")) {
                return false;
            }
            String text = (title + " " + body).toLowerCase();
            if (text.isBlank()) return null;
            return text.contains("poll booth");
        } catch (Exception e) {
            return null;
        }
    }

    /** Build 65: raw scene scan for the nearest gate/door/ladder-like object.
     *  When {@code gateOnly} is true, only objects whose name contains "gate"
     *  match (used for the rat pen gate). Returns the TileObject or null.
     *  MUST run on the client thread. */
    private Rs2TileObjectModel findGateObjectInner(boolean gateOnly) {
        return findGateObjectInner(gateOnly, 10);
    }

    private Rs2TileObjectModel findGateObjectInner(boolean gateOnly, int radius) {
        // REBUILD: was a raw client-thread scene scan (blocking invoke).
        // Now uses the event-driven Rs2TileObjectCache (non-blocking).
        // Matches doors/gates/ladders by name; falls back to null on cache miss.
        try {
            Rs2TileObjectModel byName;
            if (gateOnly) {
                byName = Microbot.getRs2TileObjectCache().query()
                        .within(radius)
                        .withNameContains("gate")
                        .nearest();
            } else {
                // Try door, gate, ladder by name.
                byName = Microbot.getRs2TileObjectCache().query()
                        .within(radius)
                        .withNameContains("door")
                        .nearest();
                if (byName == null) {
                    byName = Microbot.getRs2TileObjectCache().query()
                            .within(radius)
                            .withNameContains("gate")
                            .nearest();
                }
                if (byName == null) {
                    byName = Microbot.getRs2TileObjectCache().query()
                            .within(radius)
                            .withNameContains("ladder")
                            .nearest();
                }
            }
            return byName;
        } catch (Exception e) {
            return null;
        }
    }
    private boolean clickDoorDirectInner(String action) {
        return clickDoorDirectInner(action, 10);
    }

    private boolean clickDoorDirectInner(String action, int radius) {
        // REBUILD: findGateObjectInner now returns Rs2TileObjectModel from the
        // non-blocking cache (was raw TileObject from blocking scene scan).
        Rs2TileObjectModel found = findGateObjectInner(false, radius);
        if (found != null) {
            try {
                boolean clicked = found.click(action);
                diag("Cache query: click('" + action + "') returned " + clicked);
                return clicked;
            } catch (Exception e) {
                diag("Cache query: click failed: " + e);
                return false;
            }
        }
        diag("Cache query: no door/gate found within " + radius + " tiles");
        return false;
    }

    // Build 134 (Alex 2026-09-27): Door substate helpers.
    // Each door crossing is a verified transition, not a click-and-hope.

    /**
     * Find the specific door object for the given exit substate.
     * Door-1: the Account Guide's room door (north, y > 3127 area).
     * Door-2: the bank building's south door (y ~3125).
     * Returns null if no door found in the scene.
     */
    private Rs2TileObjectModel findExitDoorForSubstate(int doorNum, WorldPoint playerPos) {
        try {
            // Use the existing door-finding logic, but filter by expected Y range.
            Rs2TileObjectModel found = findGateObjectInner(false, 10);
            if (found == null) return null;

            WorldPoint doorTile = null;
            try {
                doorTile = found.getWorldLocation();
            } catch (Exception ignored) {}

            if (doorNum == 1) {
                // Door-1 should be north (the Account Guide room door).
                // Accept if it's north of the player or in the expected range.
                if (doorTile != null && playerPos != null) {
                    // Door-1 is the room exit; it should be nearby and roughly
                    // at the same Y or slightly south of the room interior.
                    return found;
                }
                return found;
            } else {
                // Door-2: the bank's south door at y~3125.
                if (doorTile != null && doorTile.getY() >= 3123 && doorTile.getY() <= 3127) {
                    return found;
                }
                // Fallback: return whatever door was found if it's south of player.
                if (doorTile != null && playerPos != null && doorTile.getY() < playerPos.getY()) {
                    return found;
                }
                return found;
            }
        } catch (Exception e) {
            diag("Build 134: findExitDoorForSubstate failed: " + e);
            return null;
        }
    }

    private String getObjectNameSafe(Rs2TileObjectModel obj) {
        try {
            return obj.getName() != null ? obj.getName() : "unknown";
        } catch (Exception e) {
            return "unknown";
        }
    }

    private int getObjectIdSafe(Rs2TileObjectModel obj) {
        try {
            return obj.getId();
        } catch (Exception e) {
            return -1;
        }
    }

    private WorldPoint getObjectTileSafe(Rs2TileObjectModel obj) {
        try {
            return obj.getWorldLocation();
        } catch (Exception e) {
            return null;
        }
    }

    private boolean isDoorReachable(Rs2TileObjectModel door, WorldPoint playerPos) {
        try {
            if (door == null || playerPos == null) return false;
            WorldPoint doorTile = getObjectTileSafe(door);
            if (doorTile == null) return false;
            // Check if the door tile or an adjacent tile is reachable.
            // Use Rs2Tile.isTileReachable for the door's position.
            return Rs2Tile.isTileReachable(doorTile);
        } catch (Exception e) {
            return false;
        }
    }

    private boolean tilesEqual(WorldPoint a, WorldPoint b) {
        if (a == null && b == null) return true;
        if (a == null || b == null) return false;
        return a.getX() == b.getX() && a.getY() == b.getY() && a.getPlane() == b.getPlane();
    }

    private boolean strEqual(String a, String b) {
        if (a == null && b == null) return true;
        if (a == null || b == null) return false;
        return a.equals(b);
    }

    private String truncate(String s, int maxLen) {
        if (s == null) return "null";
        if (s.length() <= maxLen) return s;
        return s.substring(0, maxLen) + "...";
    }

    private String getDialogueTextSafe() {
        try {
            // Try to get current dialogue text via Rs2Dialogue.
            String q = Rs2Dialogue.getQuestion();
            if (q != null && !q.isEmpty()) return q;
            String dt = Rs2Dialogue.getDialogueText();
            if (dt != null && !dt.isEmpty()) return dt;
            return "";
        } catch (Exception e) {
            return "";
        }
    }

    private void logCompactSceneSnapshot() {
        try {
            WorldPoint p = Rs2Player.getWorldLocation();
            diag("Build 134 SNAPSHOT: player=" + p
                    + ", varp281=" + getVarp281()
                    + ", dialogue=" + truncate(getDialogueTextSafe(), 80));
            // Log nearby objects (doors, NPCs).
            // This is a compact snapshot, not a full scan.
            diag("Build 134 SNAPSHOT: doorTarget=" + bankDoorTargetDesc
                    + ", doorSubstate=" + bankExitDoor);
        } catch (Exception e) {
            diag("Build 134 SNAPSHOT failed: " + e);
        }
    }

    // Build 136 (Alex 2026-09-27): SHARED DOOR ROUTE HANDLER v2.
    // Fixes Build 135 looping (alternating Door/9722 and Door/9721):
    // 1) Holds ONE pending target (ID+tile) and before-tile across action.
    //    Next tick verifies against SAME door via verifyDoorCrossing().
    //    Only clears on actual side crossing.
    // 2) findSouthBlockingDoor() enumerates ALL doors, filters for south,
    //    picks nearest qualifying (not just nearest overall).
    // 3) Watchdog uses STABLE target (pending ID), not switching desc.
    // 4) Distinguishes temporarily unreachable from no blocker.
    private boolean handleDoorRouteTick(WorldPoint playerPos, String routeName, WorldPoint goalTile) {
        try {
            if (playerPos == null) return false;
            // Build 167 (Alex): goal drives the route. The door selector only
            // returns doors ON THE PATH to goalTile -- never any nearby door.

            // Build 137 (Alex): PHASED PENDING STATE.
            // Phase 1 APPROACH: walk to adjacent; when adjacent, click once -> Phase 2.
            // Phase 2 CLICKED: observe; if crossed -> clear; else after N ticks -> Phase 3.
            // Phase 3 VERIFY: bounded retry or replan.
            // Also: (varp,tile,dialogue,target) no-progress watchdog for PRAYER path.
            Integer rvNow = getVarp281();
            String rdNow = getDialogueTextSafe();
            String rtNow = pendingDoorId != -1 ? "door/" + pendingDoorId : "none";
            boolean rUnchanged = (rvNow != null && rvNow == routeLastVarp)
                    && tilesEqual(playerPos, routeLastTile)
                    && strEqual(rdNow, routeLastDialogue)
                    && strEqual(rtNow, routeLastTarget);
            if (rUnchanged) {
                routeStuckTicks++;
            } else {
                routeStuckTicks = 0;
                routeLastVarp = rvNow != null ? rvNow : -1;
                routeLastTile = playerPos;
                routeLastDialogue = rdNow;
                routeLastTarget = rtNow;
            }
            if (routeStuckTicks >= 8) {
                // Build 138: Watchdog triggers REPLAN (not "latch").
                // Records the failed door ID so findSouthBlockingDoor skips it.
                diag("Build 138 DOOR STUCK (" + routeName + "): (varp=" + rvNow
                        + ",tile=" + playerPos + ",target=" + rtNow
                        + ") unchanged for 8 ticks. Replanning with different target.");
                logCompactSceneSnapshot();
                if (pendingDoorId != -1) {
                    triedDoorIds.add(pendingDoorId);
                }
                pendingDoorId = -1;
                pendingDoorTile = null;
                pendingTileBefore = null;
                pendingClickTile = null;
                pendingDoorTicks = 0;
                pendingPhase = 0;
                verifyRetryIssued = false;
                routeStuckTicks = 0;
                // Fall through to select new door (different ID)
            }

            if (pendingDoorId != -1 && pendingDoorTile != null) {
                pendingDoorTicks++;
                // Build 138: Check crossing using CLICK-TIME tile (not selection-time).
                // pendingClickTile is set when we click; pendingTileBefore is fallback.
                WorldPoint crossRef = pendingClickTile != null ? pendingClickTile : pendingTileBefore;
                if (crossRef != null) {
                    // Build 152 (Alex): pass door orientation so EW doors accept X-crossing.
                    String crossOrient = getDoorOrientation(pendingDoorId, pendingDoorTile);
                    boolean crossed = verifyDoorCrossing(crossRef, playerPos, pendingDoorTile, crossOrient);
                    if (crossed) {
                        diag("Build 138 DOOR (" + routeName + "): CROSSED door " + pendingDoorId
                                + " at " + pendingDoorTile + ": " + crossRef + " -> " + playerPos);
                        // Build 161 (Alex): record directed completion -- don't
                        // re-select this door. Prevents 9722 east->west reversal.
                        completedDoorIds.add(pendingDoorId);
                        diag("Build 161 DOOR: door " + pendingDoorId + " marked COMPLETED (crossed " + crossOrient + ")");
                        // Build 165 (Alex): track southward exit. If Y decreased,
                        // we're heading south toward Brace -- don't go back north.
                        if (playerPos.getY() < crossRef.getY()) {
                            bankExitedSouth = true;
                            diag("Build 165 DOOR: confirmed SOUTH exit (" + crossRef.getY()
                                    + " -> " + playerPos.getY() + "), bankExitedSouth=true");
                        }
                        pendingDoorId = -1;
                        pendingDoorTile = null;
                        pendingTileBefore = null;
                        pendingClickTile = null;
                        pendingDoorTicks = 0;
                        pendingPhase = 0;
                        verifyRetryIssued = false;
                        routeStuckTicks = 0;
                        bankDoorTargetDesc = null;
                        // Clear walker target on successful crossing (phase exit).
                        try {
                            Rs2Walker.setTarget(null, "tutorial-door-reset");
                        } catch (Exception e) {}
                        return true;
                    }
                }

                if (pendingPhase == 1) {
                    // APPROACH: walk to adjacent; re-evaluate each tick.
                    // Build 162 (Alex): check adjacency FIRST. findReachableAdjacentTile
                    // excludes player's own tile, so if already adjacent it returns the
                    // OPPOSITE tile, causing 9721 oscillation (3125,3123<->3125,3125).
                    WorldPoint adj = isPlayerAdjacentToDoor(pendingDoorTile, playerPos)
                        ? playerPos
                        : findReachableAdjacentTile(pendingDoorTile, playerPos);
                    if (adj == null) {
                        // Truly no reachable adjacent and not adjacent: wait.
                        diag("Build 137 DOOR (" + routeName + "): phase APPROACH, door " + pendingDoorId
                                + " no reachable adjacent. Waiting.");
                        return true;
                    }
                    int dist = Math.abs(playerPos.getX() - adj.getX())
                             + Math.abs(playerPos.getY() - adj.getY());
                    if (dist > 1) {
                        // Build 144: detect walk stall. If player hasn't moved toward
                        // target in 5 ticks, the walker's pathfinding is blocked
                        // (isTileReachable true but no path). Fall back to direct
                        // door click and let the game's own pathfinder handle it.
                        boolean sameTarget = lastWalkTarget != null && tilesEqual(lastWalkTarget, adj);
                        boolean playerMoved = lastPlayerPosForWalk == null
                            || !tilesEqual(lastPlayerPosForWalk, playerPos);
                        if (sameTarget && !playerMoved) {
                            walkStallTicks++;
                        } else {
                            walkStallTicks = 0;
                        }
                        lastWalkTarget = adj;
                        lastPlayerPosForWalk = playerPos;
                        if (walkStallTicks >= 5) {
                            diag("Build 144 DOOR (" + routeName + "): walkTo " + adj
                                    + " stalled 5 ticks (no movement). Falling back to"
                                    + " direct door click for " + pendingDoorId);
                            walkStallTicks = 0;
                            // Fall through to click logic below (don't return).
                        } else {
                            // Build 145 (Alex): capture walkTo boolean (true=ARRIVED).
                            // Log before/after/dist to distinguish failed path from no-op.
                            WorldPoint walkBefore = playerPos;
                            int distBefore = Math.abs(walkBefore.getX() - adj.getX())
                                           + Math.abs(walkBefore.getY() - adj.getY());
                            boolean walkOk = false;
                            try {
                                // Build 160 (Alex): walkStep is non-blocking --
                                // sets target, returns WalkerState, one step per
                                // tick. walkTo(target,0) stalled 82s per call.
                                WalkerState ws = Rs2Walker.walkStep(adj, 0);
                                walkOk = (ws == WalkerState.ARRIVED);
                                if (prayerStallTicks % 20 == 0) {
                                    diag("Build 160 DOOR: walkStep(" + adj + ",0) -> " + ws);
                                }
                            } catch (Exception e) {
                                diag("Build 145 DOOR (" + routeName + "): walkStep(" + adj
                                        + ") threw " + e.getClass().getSimpleName());
                            }
                            // Build 146 (Alex): re-read FRESH position after walk.
                            // playerPos is the pre-tick snapshot; use Rs2Player.
                            WorldPoint walkAfter = null;
                            try {
                                walkAfter = Rs2Player.getWorldLocation();
                            } catch (Exception e) {}
                            if (walkAfter == null) walkAfter = walkBefore; // fallback
                            int distAfter = Math.abs(walkAfter.getX() - adj.getX())
                                          + Math.abs(walkAfter.getY() - adj.getY());
                            // Build 148 (Alex): walker lie detection. The boolean is not
                            // enough in this client — require ACTUAL TILE CHANGE.
                            boolean actuallyMoved = !tilesEqual(walkBefore, walkAfter);
                            if (walkOk && !actuallyMoved) {
                                diag("Build 148 DOOR (" + routeName + "): WALKER LIED! walkTo("
                                        + adj + ") returned true but player stayed at "
                                        + walkBefore + ". Forcing direct door click for "
                                        + pendingDoorId);
                                // Fall through to door click logic below (don't return).
                            } else {
                                diag("Build 148 DOOR (" + routeName + "): walkTo " + adj
                                        + " result=" + walkOk
                                        + " moved=" + actuallyMoved
                                        + " before=" + walkBefore + "(dist=" + distBefore + ")"
                                        + " after=" + walkAfter + "(dist=" + distAfter + ")"
                                        + " door=" + pendingDoorId);
                                return true;
                            }
                        }
                    } else {
                        // Adjacent: click ONCE on the SPECIFIC pending door, move to CLICKED.
                        // Build 139 (Alex): NO generic fallback. If findDoorByIdTile()
                        // misses, hold position and replan (don't click a different object
                        // while pendingDoorId claims the original).
                        Rs2TileObjectModel dobj = findDoorByIdTile(pendingDoorId, pendingDoorTile);
                        if (dobj == null) {
                            diag("Build 139 DOOR (" + routeName + "): phase APPROACH, door "
                                    + pendingDoorId + " not found at " + pendingDoorTile
                                    + ". Holding, will replan.");
                            // Mark as tried so we pick a different door next.
                            triedDoorIds.add(pendingDoorId);
                            pendingDoorId = -1;
                            pendingDoorTile = null;
                            pendingTileBefore = null;
                            pendingClickTile = null;
                            pendingDoorTicks = 0;
                            pendingPhase = 0;
                            verifyRetryIssued = false;
                            return true; // Tick consumed (replan next tick)
                        }
                        boolean clicked = false;
                        try { clicked = dobj.click("Open"); } catch (Exception e) {}
                        // Build 138: Capture CLICK-TIME tile (not selection-time).
                        pendingClickTile = playerPos;
                        verifyRetryIssued = false;
                        diag("Build 139 DOOR (" + routeName + "): phase APPROACH->CLICKED, clicked=" + clicked
                                + " on door " + pendingDoorId + ", clickTile=" + pendingClickTile);
                        pendingPhase = 2; // CLICKED
                        pendingDoorTicks = 0; // Reset for CLICKED phase timeout
                        return true;
                    }
                } else if (pendingPhase == 2) {
                    // CLICKED: observe for up to 5 ticks, then go to VERIFY.
                    // Build 141 (Alex): If the door DISAPPEARS after Open, it's likely
                    // OPEN (not missing). Check if the doorway tile is now traversable;
                    // if yes, walk through to the far side instead of replanning.
                    Rs2TileObjectModel cdoor = findDoorByIdTile(pendingDoorId, pendingDoorTile);
                    if (cdoor == null && pendingDoorTile != null) {
                        // Door object gone. Is the doorway traversable?
                        // Build 142 (Alex): onDoor alone is not proof; require fresh
                        // traversability check. If player is on the tile, that's
                        // supporting evidence, but traversable must be true.
                        boolean traversable = false;
                        try {
                            traversable = Rs2Tile.isTileReachable(pendingDoorTile);
                        } catch (Exception e) {}
                        boolean onDoor = tilesEqual(playerPos, pendingDoorTile);
                        // Require traversable=true; onDoor is corroborating, not sufficient.
                        if (traversable) {
                            // Build 155: shared walkthrough entry (was the inline
                            // Build 144/151 block; orientation logic moved to
                            // computeDoorFarSide()).
                            enterWalkthrough(routeName, playerPos, "door " + pendingDoorId
                                    + " OPEN (disappeared, traversable=" + traversable + ")");
                            return true;
                        }
                        // Not traversable and not on door: genuinely missing, fall through
                        // to normal CLICKED timeout handling below.
                    }
                    if (pendingDoorTicks >= 5) {
                        diag("Build 137 DOOR (" + routeName + "): phase CLICKED->VERIFY, door " + pendingDoorId
                                + " no crossing after 5 ticks. Replanning.");
                        pendingPhase = 3;
                    } else {
                        // Waiting for door animation/crossing.
                        return true;
                    }
                }

                if (pendingPhase == 4) {
                    // Build 141 WALKTHROUGH: door is open, walk to far side.
                    // Build 144: track closest approach to door each tick.
                    if (pendingDoorTile != null && playerPos != null) {
                        int dDist = Math.abs(playerPos.getX() - pendingDoorTile.getX())
                                  + Math.abs(playerPos.getY() - pendingDoorTile.getY());
                        if (dDist < walkthroughMinDoorDist) walkthroughMinDoorDist = dDist;
                    }
                    if (walkthroughTarget != null) {
                        int wdist = Math.abs(playerPos.getX() - walkthroughTarget.getX())
                                  + Math.abs(playerPos.getY() - walkthroughTarget.getY());
                        if (wdist <= 1) {
                            // Arrived at far side. Verify with FAR-SIDE check (not strict crossing).
                            // Build 143 (Alex): verifyDoorCrossing is for small click-verifications;
                            // WALKTHROUGH covers 5+ tiles, so check far-side arrival instead:
                            // player south of door + X near door + started at/north of door Y.
                            // Strict helper rejected legit (3133,3124)->(3130,3122) in simulation.
                            WorldPoint wtRef = pendingClickTile != null ? pendingClickTile : pendingTileBefore;
                            // Build 144: require doorway transit (minDist<=1), not just far-side.
                            // Walk-around-the-fence could reach far side without through-door.
                            // Build 152: pass orientation for EW far-side acceptance.
                            String wtOrient = getDoorOrientation(pendingDoorId, pendingDoorTile);
                            boolean farSide = wtRef != null
                                && verifyWalkthroughFarSide(wtRef, playerPos, pendingDoorTile, wtOrient);
                            boolean throughDoorway = walkthroughMinDoorDist <= 1;
                            boolean crossed = farSide && throughDoorway;
                            if (crossed) {
                                diag("Build 144 DOOR (" + routeName + "): WALKTHROUGH CROSSED door "
                                        + pendingDoorId + ": " + wtRef + " -> " + playerPos
                                        + " (far-side OK, doorway minDist=" + walkthroughMinDoorDist + ")");
                                // Build 162 (Alex): WALKTHROUGH success must ALSO record
                                // completion, not just CLICK success. Prevents re-selection.
                                completedDoorIds.add(pendingDoorId);
                                diag("Build 162 DOOR: door " + pendingDoorId + " marked COMPLETED (walkthrough)");
                                // Build 165 (Alex): track southward exit.
                                if (wtRef != null && playerPos.getY() < wtRef.getY()) {
                                    bankExitedSouth = true;
                                    diag("Build 165 DOOR: confirmed SOUTH exit (walkthrough "
                                            + wtRef.getY() + " -> " + playerPos.getY() + ")");
                                }
                                // Clear walker target on successful crossing.
                                try {
                                    Rs2Walker.setTarget(null, "tutorial-door-reset");
                                } catch (Exception e) {}
                            } else {
                                diag("Build 144 DOOR (" + routeName + "): WALKTHROUGH "
                                        + (farSide ? "far-side OK" : "far-side FAIL")
                                        + ", doorway " + (throughDoorway ? "OK" : "FAIL")
                                        + " (minDist=" + walkthroughMinDoorDist + ")"
                                        + " (ref=" + wtRef + ",now=" + playerPos + ",door=" + pendingDoorTile + ")."
                                        + (crossed ? "" : " Marking tried, replanning (NOT success)."));
                            }
                            // Mark tried either way to prevent immediate reselect loop.
                            if (pendingDoorId != -1) triedDoorIds.add(pendingDoorId);
                            pendingDoorId = -1;
                            pendingDoorTile = null;
                            pendingTileBefore = null;
                            pendingClickTile = null;
                            walkthroughTarget = null;
                            pendingDoorTicks = 0;
                            pendingPhase = 0;
                            verifyRetryIssued = false;
                            // Build 156: reset attempt counter on crossing
                            // (success or fail -- new door gets fresh attempts).
                            walkthroughDoorId = -1;
                            walkthroughAttempts = 0;
                            return true;
                        } else {
                            // Keep walking to far side.
                            // Build 155: fresh-tile movement watchdog. The walker
                            // can report success while the player never moves
                            // (door still closed / path blocked through the
                            // doorway). Require the tile to actually change.
                            WorldPoint fresh = null;
                            try { fresh = Rs2Player.getWorldLocation(); } catch (Exception e) {}
                            if (fresh == null) fresh = playerPos;
                            if (walkthroughLastPos != null && tilesEqual(fresh, walkthroughLastPos)) {
                                walkthroughStuckTicks++;
                            } else {
                                walkthroughStuckTicks = 0;
                            }
                            walkthroughLastPos = fresh;
                            if (walkthroughStuckTicks >= 4) {
                                // Build 156: bounded retry. The door may still be
                                // closed (false 'disappeared' when player stands on
                                // its tile). Re-click Open up to 3x before parking.
                                if (walkthroughAttempts < 3) {
                                    diag("Build 156 DOOR (" + routeName + "): WALKTHROUGH STUCK, no tile change for "
                                            + walkthroughStuckTicks + " ticks walking to " + walkthroughTarget
                                            + " (at " + fresh + "). Attempt " + walkthroughAttempts
                                            + "/3 failed -- re-trying Open+walk (door may still be closed).");
                                    // Clear pending but DON'T park in blockedDoorIds.
                                    // Remove from triedDoorIds so it can be re-selected.
                                    if (pendingDoorId != -1) {
                                        triedDoorIds.remove(pendingDoorId);
                                    }
                                    pendingDoorId = -1;
                                    pendingDoorTile = null;
                                    pendingTileBefore = null;
                                    pendingClickTile = null;
                                    walkthroughTarget = null;
                                    walkthroughLastPos = null;
                                    walkthroughStuckTicks = 0;
                                    pendingDoorTicks = 0;
                                    pendingPhase = 0;
                                    verifyRetryIssued = false;
                                    // walkthroughDoorId/Attempts kept for next enterWalkthrough
                                    return true;
                                }
                                diag("Build 156 DOOR (" + routeName + "): WALKTHROUGH BLOCKED after "
                                        + walkthroughAttempts + " attempts, no tile change for "
                                        + walkthroughStuckTicks + " ticks walking to " + walkthroughTarget
                                        + " (at " + fresh + "). Parking door.");
                                parkBlockedDoor(routeName);
                                return true;
                            }
                            if (pendingDoorTicks > 10) {
                                diag("Build 141 DOOR (" + routeName + "): WALKTHROUGH timeout, abandoning.");
                                parkBlockedDoor(routeName);
                                return true;
                            }
                            diag("Build 141 DOOR (" + routeName + "): WALKTHROUGH walking to " + walkthroughTarget);
                            // Build 156: capture walkTo result and far-side walkability
                            // for diagnostics (walker may fail silently).
                            // Build 156 (Alex): Rs2Walker.walkTo(WorldPoint) uses
                            // ShortestPathConfig.reachedDistance() default 5 -- a
                            // 2-tile walk returns ARRIVED without moving. Use the
                            // (WorldPoint,int) overload with distance 0 for exact
                            // doorway targets.
                            boolean walkOk = false;
                            boolean farWalkable = false;
                            try {
                                farWalkable = Rs2Tile.isWalkable(walkthroughTarget);
                            } catch (Exception e) {}
                            try {
                                // Build 160 (Alex): walkStep is non-blocking --
                                // one step per tick, returns WalkerState.
                                // walkTo(target,0) stalled 82s per call.
                                WalkerState ws = Rs2Walker.walkStep(walkthroughTarget, 0);
                                walkOk = (ws == WalkerState.ARRIVED);
                                if (prayerStallTicks % 20 == 0) {
                                    diag("Build 160 DOOR (" + routeName + "): walkStep(" + walkthroughTarget + ",0) -> " + ws);
                                }
                                // Build 160 (Alex): reset walker target only on
                                // terminal states, not every MOVING tick.
                                if (ws == WalkerState.UNREACHABLE || ws == WalkerState.EXIT) {
                                    try {
                                        Rs2Walker.setTarget(null, "tutorial-door-reset");
                                        diag("Build 160 DOOR: walker target reset (" + ws + ")");
                                    } catch (Exception re) {}
                                }
                            } catch (Exception e) {
                                diag("Build 156 DOOR (" + routeName + "): walkStep(" + walkthroughTarget
                                        + ",0) threw " + e.getClass().getSimpleName());
                            }
                            if (!walkOk || !farWalkable) {
                                diag("Build 156 DOOR (" + routeName + "): walkTo(" + walkthroughTarget
                                        + ",0) result=" + walkOk + ", farSide walkable=" + farWalkable
                                        + " (at " + fresh + ")");
                            }
                            return true;
                        }
                    } else {
                        // No target, clear.
                        pendingPhase = 0;
                    }
                }

                if (pendingPhase == 3) {
                    // Build 138: VERIFY with ONE bounded retry (latched, not every tick).
                    if (pendingDoorTicks >= 8) {
                        diag("Build 138 DOOR (" + routeName + "): phase VERIFY timeout, door " + pendingDoorId
                                + ". Clearing pending, replanning from " + playerPos);
                        triedDoorIds.add(pendingDoorId); // Remember to pick different
                        pendingDoorId = -1;
                        pendingDoorTile = null;
                        pendingTileBefore = null;
                        pendingClickTile = null;
                        pendingDoorTicks = 0;
                        pendingPhase = 0;
                        verifyRetryIssued = false;
                        // Fall through to select new door (different ID)
                    } else if (!verifyRetryIssued) {
                        // Build 155 (review loop): the Open click already happened
                        // in the APPROACH phase. Re-clicking the same still-closed
                        // door is the infinite loop (door 9722 never leaves the
                        // cache, so the disappearance gate never fires). Instead,
                        // take the ONE bounded walkthrough attempt: walk the
                        // far-side route now and verify the tile actually moves.
                        verifyRetryIssued = true;
                        enterWalkthrough(routeName, playerPos,
                            "VERIFY: door " + pendingDoorId
                            + " still present after Open (no disappearance) -- taking bounded walkthrough attempt");
                        return true;
                    } else {
                        // Retry already issued, waiting for timeout.
                        return true;
                    }
                }
            }

            // STEP 2: No pending door. Select a new target.
            // Build 167 (Alex): goal-directed -- ONLY a door on the path to
            // goalTile, never any eligible nearby door.
            WorldModel.DoorSnapshot doorSnap = findDoorOnPathTo(playerPos, goalTile);
            if (doorSnap == null) {
                // Build 155: every candidate is parked as blocked -- report and
                // hold instead of walking into the door or looping forever.
                if (doorRouteBlocked) {
                    // Build 160 (Alex): clear walker target on phase exit.
                    try {
                        Rs2Walker.setTarget(null, "tutorial-door-reset");
                    } catch (Exception e) {}
                    if (routeStuckTicks < 2 || routeStuckTicks % 10 == 0) {
                        diag("Build 155 DOOR (" + routeName + "): ROUTE BLOCKED on doors " + blockedDoorIds
                                + ". Holding at " + playerPos + " (needs help / new patch).");
                    }
                    return true; // Tick consumed (waiting, not walking into wall)
                }
                // Build 163 (Alex): if no eligible south-blocking door exists,
                // WALK SOUTH.
                diag("Build 163 DOOR (" + routeName + "): no eligible south blocker, walking south.");
                return false;
            }

            int doorId = doorSnap.id;
            WorldPoint doorTile = doorSnap.tile;
            String doorName = doorSnap.name;

            // Build 137: Hold pending target, start in APPROACH phase.
            pendingDoorId = doorId;
            pendingDoorTile = doorTile;
            pendingTileBefore = playerPos;
            pendingDoorTicks = 0;
            pendingPhase = 1; // APPROACH

            String doorAction = "Open";
            // Use STABLE target desc based on pending ID (not switching).
            bankDoorTargetDesc = doorName + "/" + doorId + "/" + doorAction + "@" + doorTile;

            // Check reachability via adjacent tiles.
            // Build 154 (review loop): player already adjacent to the door is
            // ready-to-click, not unreachable. Use the player's own tile as the
            // approach tile so the !reachable gate below doesn't block the
            // direct click (findReachableAdjacentTile excludes the own tile).
            boolean alreadyAdjacent = isPlayerAdjacentToDoor(doorTile, playerPos);
            WorldPoint adjacentTile = alreadyAdjacent ? playerPos
                    : findReachableAdjacentTile(doorTile, playerPos);
            boolean reachable = adjacentTile != null;

            diag("Build 136 DOOR (" + routeName + "): PENDING target=" + bankDoorTargetDesc
                    + ", player=" + playerPos
                    + ", adjacent=" + adjacentTile
                    + ", reachable=" + reachable);

            if (!reachable) {
                diag("Build 136 DOOR (" + routeName + "): door " + doorId + " temporarily unreachable. Holding pending, waiting.");
                // Keep pending; do not clear. Wait for reachability.
                return true;
            }

            // ONE action per tick.
            int distToAdjacent = adjacentTile != null
                    ? Math.abs(playerPos.getX() - adjacentTile.getX())
                      + Math.abs(playerPos.getY() - adjacentTile.getY())
                    : 999;
            // Build 153: if player is already adjacent (including on their own tile),
            // that's ready-to-click, not a walk target.
            boolean readyToClick = adjacentTile != null && tilesEqual(adjacentTile, playerPos)
                || isPlayerAdjacentToDoor(doorTile, playerPos);
            if (distToAdjacent > 1 && !readyToClick) {
                diag("Build 136 DOOR (" + routeName + "): walking to adjacent " + adjacentTile
                        + " for door " + doorId);
                // Build 161 (Alex): non-blocking walkStep, not blocking walkTo.
                try {
                    WalkerState aws = Rs2Walker.walkStep(adjacentTile, 0);
                    if (routeStuckTicks % 20 == 0) {
                        diag("Build 161 DOOR: approach walkStep -> " + aws);
                    }
                } catch (Exception e) {
                    diag("Build 161 DOOR: approach walkStep failed: " + e.getClass().getSimpleName());
                }
                return true;
            } else {
                boolean clicked = false;
                try {
                    // Build 166: get model by ID/tile (no name lookup, no blocking).
                    Rs2TileObjectModel clickObj = findDoorByIdTile(doorId, doorTile);
                    if (clickObj != null) {
                        clicked = clickObj.click(doorAction);
                    } else {
                        diag("Build 166 DOOR (" + routeName + "): model not in cache for click");
                    }
                } catch (Exception e) {
                    diag("Build 136 DOOR (" + routeName + "): click failed: " + e);
                }
                // Build 152 (Alex): Set click-time state in BOTH click paths.
                // Without this, next tick sees phase=APPROACH and replans.
                pendingClickTile = playerPos;
                pendingPhase = 2; // CLICKED
                pendingDoorTicks = 0;
                verifyRetryIssued = false;
                if (clicked) {
                    diag("Build 152 DOOR (" + routeName + "): clicked '" + doorAction
                            + "' on door " + doorId + ", clickTile=" + pendingClickTile
                            + ", phase->CLICKED. Waiting for crossing.");
                } else {
                    diag("Build 152 DOOR (" + routeName + "): click false on door " + doorId
                            + ", clickTile=" + pendingClickTile + ", phase->CLICKED.");
                }
                return true;
            }
        } catch (Exception e) {
            diag("Build 136 handleDoorRouteTick (" + routeName + ") failed: " + e);
            return false;
        }
    }

    // Build 137: Find a specific door by ID and tile (for pending re-click).
    private Rs2TileObjectModel findDoorByIdTile(int doorId, WorldPoint doorTile) {
        try {
            var all = Microbot.getRs2TileObjectCache().query()
                    .within(12)
                    .toList();
            if (all == null) return null;
            for (Rs2TileObjectModel m : all) {
                try {
                    if (getObjectIdSafe(m) == doorId && tilesEqual(getObjectTileSafe(m), doorTile)) {
                        return m;
                    }
                } catch (Exception ignored) {}
            }
            return null;
        } catch (Exception e) {
            return null;
        }
    }

    // Build 136: Check if ANY door exists nearby (to distinguish "no blocker"
    // from "temporarily unreachable").
    private boolean hasAnyDoorNearby(WorldPoint playerPos) {
        // Build 162 (Alex): exclude completed doors -- a completed door nearby
        // is not a reason to wait. Return false so caller walks south.
        try {
            var doors = Microbot.getRs2TileObjectCache().query()
                    .within(10)
                    .withNameContains("door")
                    .toList();
            if (doors != null) {
                for (Rs2TileObjectModel d : doors) {
                    try {
                        int did = getObjectIdSafe(d);
                        if (!completedDoorIds.contains(did)
                                && !blockedDoorIds.contains(did)) {
                            return true;
                        }
                    } catch (Exception ignored) {}
                }
            }
            var gates = Microbot.getRs2TileObjectCache().query()
                    .within(10)
                    .withNameContains("gate")
                    .toList();
            if (gates != null) {
                for (Rs2TileObjectModel g : gates) {
                    try {
                        int gid = getObjectIdSafe(g);
                        if (!completedDoorIds.contains(gid)
                                && !blockedDoorIds.contains(gid)) {
                            return true;
                        }
                    } catch (Exception ignored) {}
                }
            }
            return false;
        } catch (Exception e) {
            return false;
        }
    }

    // Build 135: Find a door/gate south of the player that blocks the path.
    // Returns the nearest door/gate object, or null if none found.
    // Build 136 (Alex): ENUMERATE and FILTER south doors.
    // Old code took nearest() then returned null if it was north — never
    // searching for a qualifying south blocker. Now: get ALL doors/gates,
    // filter to those south of (or level with) player, pick nearest qualifying.
    /**
     * Build 166 (Alex): Find south-blocking door from WorldModel snapshots.
     * Replaces blocking cache queries (withNameContains -> getName() ->
     * ClientThread.invoke, 10s stall per call). Reads pre-sampled
     * (id, tile, name, actions) from GameTick -- zero blocking.
     * Returns DoorSnapshot, or null if none qualifies.
     */
    /**
     * Build 167 (Alex): ROUTE-EDGE door selection via Rs2PathApi.
     * Replaces global nearby-door selection. Logic:
     *  1. Get active route; require isReady() and targets containing our goal.
     *  2. Take the walkable path; find index nearest the player.
     *  3. Inspect FORWARD adjacent edges from the player's position.
     *  4. For each edge, Rs2Tile.isEdgePassable(from, to) -- if blocked,
     *     find the closed door at that edge (fresh "Open" action).
     *  5. Return ONLY that door. Null = no door blocks the route.
     * Never globally selects nearby doors before navigation.
     */
    private WorldModel.DoorSnapshot findDoorOnPathTo(WorldPoint playerPos, WorldPoint goal) {
        // Build 140 (Alex): Reset tried-set only on MEANINGFUL state change.
        Integer tcv = getVarp281();
        int tcvv = tcv != null ? tcv : -1;
        boolean varpChanged = tcvv != triedSetVarp;
        boolean movedFar = false;
        if (triedSetTile != null && playerPos != null) {
            int d = Math.abs(playerPos.getX() - triedSetTile.getX())
                  + Math.abs(playerPos.getY() - triedSetTile.getY());
            movedFar = d > 5;
        } else if (triedSetTile == null && playerPos != null) {
            movedFar = true;
        }
        if (varpChanged || movedFar) {
            if (!triedDoorIds.isEmpty()) {
                diag("Build 140 DOOR: tried-set " + triedDoorIds + " cleared"
                        + " (varpChanged=" + varpChanged + ",movedFar=" + movedFar
                        + ",tile=" + playerPos + ")");
            }
            triedDoorIds.clear();
            if (!blockedDoorIds.isEmpty()) {
                diag("Build 155 DOOR: blocked-set " + blockedDoorIds + " cleared (new situation)");
            }
            blockedDoorIds.clear();
            doorRouteBlocked = false;
            triedSetVarp = tcvv;
            triedSetTile = playerPos;
        }
        try {
            if (playerPos == null || goal == null) return null;
            // Build 149 (Alex): COMMIT TO ONE DOOR. Check snapshots for pending.
            if (pendingDoorId != -1 && pendingDoorTile != null) {
                java.util.List<WorldModel.DoorSnapshot> snaps = worldModel.doorSnapshots.get();
                if (snaps != null) {
                    for (WorldModel.DoorSnapshot s : snaps) {
                        if (s.id == pendingDoorId && tilesEqual(s.tile, pendingDoorTile)) {
                            return s;
                        }
                    }
                }
                // Committed door gone from snapshots -- fall through to re-select.
            }
            // Build 167 (Alex): ROUTE-BASED. Only a ready route whose targets
            // contain our goal is usable.
            net.runelite.client.plugins.microbot.util.walker.Rs2ActiveRouteStatus route = null;
            try {
                route = net.runelite.client.plugins.microbot.util.walker.Rs2PathApi.getActiveRouteStatus();
            } catch (Exception ignored) {}
            if (route == null || !route.isReady()) {
                return null; // No ready route -- not a door problem.
            }
            java.util.Set<WorldPoint> targets = null;
            try { targets = route.getTargets(); } catch (Exception ignored) {}
            if (targets == null || !targets.contains(goal)) {
                return null; // Route isn't for our goal.
            }
            java.util.List<WorldPoint> path = null;
            // Build 168 (Alex): use getRawPath(), NOT getWalkablePath().
            // The installed Pathfinder runs PathSmoother.smooth(rawPath);
            // the smoothed path merges LOS runs up to 10 tiles, so door
            // edges hide inside long segments that the old Manhattan!=1
            // check discarded. Raw path is tile-by-tile.
            try { path = route.getRawPath(); } catch (Exception ignored) {}
            if (path == null || path.size() < 2) {
                return null;
            }
            // Find path index nearest the player (start of forward edges).
            int startIdx = 0;
            int bestD = Integer.MAX_VALUE;
            for (int i = 0; i < path.size(); i++) {
                WorldPoint wp = path.get(i);
                if (wp == null) continue;
                int d = Math.abs(wp.getX() - playerPos.getX())
                      + Math.abs(wp.getY() - playerPos.getY());
                if (d < bestD) { bestD = d; startIdx = i; }
            }
            // Inspect FORWARD adjacent edges (next few only).
            for (int i = startIdx; i < path.size() - 1 && i - startIdx < 4; i++) {
                WorldPoint from = path.get(i);
                WorldPoint to = path.get(i + 1);
                if (from == null || to == null) continue;
                if (from.getPlane() != to.getPlane()) continue;
                // Build 168 (Alex): adjacent = Chebyshev distance 1
                // (max(absdx,absdy)==1), covers diagonals. Diagonal blockers
                // are checked via findDoorAtEdge, which only matches doors
                // at/near the edge endpoints -- not every nearby door.
                int cdx = Math.abs(from.getX() - to.getX());
                int cdy = Math.abs(from.getY() - to.getY());
                if (Math.max(cdx, cdy) != 1) continue; // Not adjacent.
                boolean passable = true;
                try {
                    passable = Rs2Tile.isEdgePassable(from, to);
                } catch (Exception ignored) {}
                if (!passable) {
                    WorldModel.DoorSnapshot door = findDoorAtEdge(from, to);
                    if (door != null) {
                        diag("Build 168 DOOR: route edge " + from + "->" + to
                            + " blocked by door " + door.id + "@" + door.tile
                            + " (goal=" + goal + ")");
                        return door;
                    }
                    // Edge blocked but no door there -- not door-handlable.
                    diag("Build 168 DOOR: route edge " + from + "->" + to
                        + " impassable, no door found (obstacle, not door)");
                    return null;
                }
            }
            return null; // Forward edges all passable -- no door to handle.
        } catch (Exception e) {
            return null;
        }
    }

    /** Find a closed door snapshot at (or adjacent to) a blocked route edge. */
    private WorldModel.DoorSnapshot findDoorAtEdge(WorldPoint from, WorldPoint to) {
        try {
            java.util.List<WorldModel.DoorSnapshot> snaps = worldModel.doorSnapshots.get();
            if (snaps == null) return null;
            for (WorldModel.DoorSnapshot s : snaps) {
                if (s.tile == null) continue;
                // Door at/near either endpoint of the blocked edge.
                int dFrom = Math.abs(s.tile.getX() - from.getX())
                          + Math.abs(s.tile.getY() - from.getY());
                int dTo = Math.abs(s.tile.getX() - to.getX())
                        + Math.abs(s.tile.getY() - to.getY());
                if (dFrom > 1 && dTo > 1) continue;
                if (blockedDoorIds.contains(s.id)) continue;
                if (triedDoorIds.contains(s.id)) continue;
                if (completedDoorIds.contains(s.id)) continue;
                // Build 166: require fresh "Open" action.
                if (!s.hasOpenAction()) continue;
                return s;
            }
        } catch (Exception ignored) {}
        return null;
    }

    // Build 135: Find a reachable tile adjacent to the door.
    // The door tile itself is a wall; we need to stand next to it to interact.
    // Build 153 (Alex/Bumbaa): if the player is ALREADY adjacent to the door,
    // that's "ready to interact" — not a failure. The no-self-target filter
    // in findReachableAdjacentTile wrongly rejects this case.
    private boolean isPlayerAdjacentToDoor(WorldPoint doorTile, WorldPoint playerPos) {
        if (doorTile == null || playerPos == null) return false;
        try {
            int dist = Math.abs(doorTile.getX() - playerPos.getX())
                     + Math.abs(doorTile.getY() - playerPos.getY());
            return dist == 1;
        } catch (Exception e) {
            return false;
        }
    }

    private WorldPoint findReachableAdjacentTile(WorldPoint doorTile, WorldPoint playerPos) {
        if (doorTile == null) return null;
        try {
            // Check 4 adjacent tiles (N, S, E, W) for reachability.
            // Build 150 (Alex): EXCLUDE the player's own tile. If the player is
            // already on the closest adjacent, that's a CLICK trigger, not a
            // walk target. Returning the player's tile causes walkTo(true) with
            // zero movement (the "walker lied" false positive).
            int[][] offsets = {{0, 1}, {0, -1}, {1, 0}, {-1, 0}};
            WorldPoint best = null;
            int bestDist = Integer.MAX_VALUE;
            for (int[] off : offsets) {
                WorldPoint adj = new WorldPoint(
                    doorTile.getX() + off[0],
                    doorTile.getY() + off[1],
                    doorTile.getPlane());
                // Skip if this IS the player's tile.
                if (playerPos != null && tilesEqual(adj, playerPos)) {
                    continue;
                }
                try {
                    if (Rs2Tile.isTileReachable(adj)) {
                        int dist = playerPos != null
                            ? Math.abs(playerPos.getX() - adj.getX())
                              + Math.abs(playerPos.getY() - adj.getY())
                            : 0;
                        if (dist < bestDist) {
                            bestDist = dist;
                            best = adj;
                        }
                    }
                } catch (Exception ignored) {}
            }
            return best;
        } catch (Exception e) {
            return null;
        }
    }

    // Build 139 (Alex): Strict crossing verification.
    // Requires a traversable transition THROUGH the door boundary:
    // - Exactly ONE axis flips sides (not both = walked around a corner).
    // - The non-flipping axis stays within 1 of the door (didn't go around).
    // - Total movement is small (1-4 tiles; more = unrelated walking).
    // - Uses click-time tile, not selection-time.
    private boolean verifyDoorCrossing(WorldPoint tileBefore, WorldPoint tileAfter, WorldPoint doorTile) {
        return verifyDoorCrossing(tileBefore, tileAfter, doorTile, null);
    }

    // Build 151 (Alex): orientation-aware crossing. EW doors accept X-axis;
    // NS doors require Y-axis (southbound). Null orientation = south-only (147 behavior).
    private boolean verifyDoorCrossing(WorldPoint tileBefore, WorldPoint tileAfter,
                                       WorldPoint doorTile, String orientation) {
        if (tileBefore == null || tileAfter == null || doorTile == null) return false;
        try {
            int dx = doorTile.getX();
            int dy = doorTile.getY();

            int movedX = Math.abs(tileAfter.getX() - tileBefore.getX());
            int movedY = Math.abs(tileAfter.getY() - tileBefore.getY());
            int totalMoved = movedX + movedY;
            if (totalMoved < 1 || totalMoved > 4) return false;

            // Which side of the door (-1, 0, 1) for each axis.
            int beforeY = Integer.compare(tileBefore.getY(), dy);
            int afterY = Integer.compare(tileAfter.getY(), dy);
            int beforeX = Integer.compare(tileBefore.getX(), dx);
            int afterX = Integer.compare(tileAfter.getX(), dx);

            boolean crossedY = (beforeY > 0 && afterY < 0) || (beforeY < 0 && afterY > 0);
            boolean crossedX = (beforeX > 0 && afterX < 0) || (beforeX < 0 && afterX > 0);

            // Build 151 (Alex): orientation-aware. EW doors (9721/9722 bank):
            // X-axis crossing is legitimate. NS doors (church gate): require Y.
            boolean isEW = "EW".equals(orientation);
            if (isEW) {
                // East-west door: X must flip sides, Y stays hugging the door.
                if (crossedX && !crossedY) {
                    return Math.abs(tileBefore.getY() - dy) <= 1
                        && Math.abs(tileAfter.getY() - dy) <= 1;
                }
                return false;
            }
            // Build 147 (Alex): For NS fence/gate doors, crossing means
            // NORTH-TO-SOUTH (Y-axis). Require crossedY; reject same-Y X flips.
            if (crossedY && !crossedX) {
                // Through-door on Y: X must stay hugging the door (no going around).
                // Also require actual southward progress: afterY must be < 0 (south side).
                boolean huggingX = Math.abs(tileBefore.getX() - dx) <= 1
                    && Math.abs(tileAfter.getX() - dx) <= 1;
                boolean wentSouth = afterY < 0; // ended on south side of door
                return huggingX && wentSouth;
            }
            // X-flip alone (same Y) = lateral shuffle past the door, NOT a crossing.
            // Both flipped (corner walk) or neither flipped = not a crossing.
            return false;
        } catch (Exception e) {
            return false;
        }
    }

    // Build 151 (Alex): Door orientation. Bank doors 9721/9722 at y=3124 are
    // EAST-WEST (player crosses on X-axis). Church gate 1512/1516 near y=3119
    // is NORTH-SOUTH (player crosses on Y-axis, southbound).
    // Returns "EW" for east-west, "NS" for north-south, null if unknown.
    private String getDoorOrientation(int doorId, WorldPoint doorTile) {
        // Known east-west bank doors
        if (doorId == 9721 || doorId == 9722) return "EW";
        // Known north-south church gates
        if (doorId == 1512 || doorId == 1516) return "NS";
        // Heuristic: if door is at y=3124 (bank row), likely EW
        if (doorTile != null && doorTile.getY() == 3124) return "EW";
        // If door is south of player by 3+ tiles, likely NS gate
        return null; // Unknown — caller decides
    }

    // Build 155: orientation-aware far-side target (extracted from the old
    // Build 151 inline block in phase 2). EW doors: X±2 (east default).
    // NS/unknown doors: south (Y-2).
    private WorldPoint computeDoorFarSide(int doorId, WorldPoint doorTile, WorldPoint playerPos) {
        if (doorTile == null) return null;
        String orient = getDoorOrientation(doorId, doorTile);
        if ("EW".equals(orient)) {
            int dir = playerPos != null ? Integer.compare(doorTile.getX(), playerPos.getX()) : 1;
            if (dir == 0) dir = 1; // Default east if aligned
            WorldPoint farSide = new WorldPoint(
                doorTile.getX() + (dir * 2), doorTile.getY(), doorTile.getPlane());
            diag("Build 155 DOOR: EW door " + doorId + ", farSide=" + farSide + " (X-axis)");
            return farSide;
        }
        WorldPoint farSide = new WorldPoint(
            doorTile.getX(), doorTile.getY() - 2, doorTile.getPlane());
        diag("Build 155 DOOR: NS/unknown door " + doorId + ", farSide=" + farSide + " (Y-axis)");
        return farSide;
    }

    // Build 155: shared WALKTHROUGH entry. Resets the doorway-proximity
    // tracker AND the fresh-tile movement watchdog baseline.
    // Build 156: tracks attempts per door for bounded retry.
    private void enterWalkthrough(String routeName, WorldPoint playerPos, String reason) {
        WorldPoint farSide = computeDoorFarSide(pendingDoorId, pendingDoorTile, playerPos);
        walkthroughTarget = farSide;
        pendingPhase = 4; // WALKTHROUGH
        pendingDoorTicks = 0;
        walkthroughMinDoorDist = Integer.MAX_VALUE; // reset doorway proximity tracking
        walkthroughLastPos = null; // watchdog baseline set on first WALKTHROUGH tick
        walkthroughStuckTicks = 0;
        // Build 156: new door = reset attempts; same door = increment.
        if (pendingDoorId != walkthroughDoorId) {
            walkthroughDoorId = pendingDoorId;
            walkthroughAttempts = 1;
        } else {
            walkthroughAttempts++;
        }
        diag("Build 156 DOOR (" + routeName + "): " + reason
                + ". WALKTHROUGH to " + farSide
                + " (attempt " + walkthroughAttempts + "/3)");
    }

    // Build 155: park a door whose walkthrough failed. It is never re-selected
    // in this route (stops the Open->VERIFY->timeout->reselect infinite loop);
    // the route reports BLOCKED once every candidate is parked.
    private void parkBlockedDoor(String routeName) {
        diag("Build 155 DOOR (" + routeName + "): parking door " + pendingDoorId
                + " after failed walkthrough (tried=" + triedDoorIds
                + ", blocked=" + blockedDoorIds + ")");
        if (pendingDoorId != -1) {
            triedDoorIds.add(pendingDoorId);
            blockedDoorIds.add(pendingDoorId);
        }
        pendingDoorId = -1;
        pendingDoorTile = null;
        pendingTileBefore = null;
        pendingClickTile = null;
        walkthroughTarget = null;
        walkthroughLastPos = null;
        walkthroughStuckTicks = 0;
        pendingDoorTicks = 0;
        pendingPhase = 0;
        verifyRetryIssued = false;
        // Build 156: reset attempt counter when parking (door gets fresh
        // attempts if unparked later by new situation).
        walkthroughDoorId = -1;
        walkthroughAttempts = 0;
    }

    // Build 143 (Alex): WALKTHROUGH far-side verification.
    // verifyDoorCrossing() is for 1-4 tile click verifications with strict sign flips.
    // WALKTHROUGH walks 5+ tiles from click position to far side, so strict flips fail
    // on legit routes (simulated: (3133,3124)->(3130,3122) via door (3130,3124) = false).
    // This checks: started at/north of door Y, ended south of door Y, X hugs door.
    // Does NOT declare route progress; south checkpoint y<=3115 is separate.
    private boolean verifyWalkthroughFarSide(WorldPoint tileBefore, WorldPoint tileAfter,
                                             WorldPoint doorTile) {
        return verifyWalkthroughFarSide(tileBefore, tileAfter, doorTile, null);
    }

    // Build 152 (Alex): orientation-aware far-side. EW: X progress east/west.
    // NS: Y progress south. Null = south-only (legacy).
    private boolean verifyWalkthroughFarSide(WorldPoint tileBefore, WorldPoint tileAfter,
                                             WorldPoint doorTile, String orientation) {
        if (tileBefore == null || tileAfter == null || doorTile == null) return false;
        try {
            int dx = doorTile.getX();
            int dy = doorTile.getY();
            if ("EW".equals(orientation)) {
                // East-west door: must have moved east (X increasing past door)
                // for the bank exit. Y must hug the door.
                if (Math.abs(tileAfter.getY() - dy) > 1) return false;
                if (tileAfter.getX() <= dx) return false; // must be east of door
                if (tileAfter.getX() <= tileBefore.getX()) return false; // must progress east
                return true;
            }
            // NS or unknown: south-only as before.
            // Must have started at or north of the door's Y (approach side).
            if (tileBefore.getY() < dy) return false;
            // Must have ended south of the door's Y (far side).
            if (tileAfter.getY() >= dy) return false;
            // X must hug the door (not walked around). Allow 2 for path wiggle.
            if (Math.abs(tileAfter.getX() - dx) > 2) return false;
            // Must have actually moved south (not a zero-move).
            if (tileAfter.getY() >= tileBefore.getY()) return false;
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    // Fire tracking: findObject("Fire") times out, so we track manually.
    // Fires last ~60s in OSRS. Once we light one, assume it exists.
    private volatile long fireLitAt = 0;
    private boolean isFireLit() {
        // Check via object find first (if it works)
        Rs2TileObjectModel fire = findObjectTimeout("Fire", 12);
        if (fire != null) return true;
        // Fall back to timestamp (fire lasts 60s)
        return System.currentTimeMillis() - fireLitAt < 60000;
    }

    // Run an action with a timeout — if it hangs, log and return so the
    // next tick can retry. Actions are fire-and-forget; state is re-checked
    // every tick.
    private void runAction(String name, Runnable action) {
        try {
            CompletableFuture.runAsync(() -> {
                try {
                    action.run();
                } catch (Exception e) {
                    diag("Action " + name + " threw: " + e.toString());
                }
            }).get(5, TimeUnit.SECONDS);
            diag("Action " + name + " completed");
        } catch (TimeoutException e) {
            diag("Action " + name + " timed out, will retry next tick");
        } catch (Exception e) {
            diag("Action " + name + " failed: " + e.toString());
        }
    }

    private void doSurvivalInner() {
        diag("SURVIVAL TICK");
        Microbot.status = "Tutorial Island: Survival Expert";
        // Master Chef check removed — was hanging the tick. We'll detect
        // completion by having cooked shrimp instead.

        // State-driven: act on what the inventory/world actually show.
        // No initial chat needed — the tutorial state is visible.
        // (If the player somehow lacks the net, the fishing action will fail
        // and the expert can be consulted, but normally we already have it.)

        boolean hasRaw = invContains("Raw shrimps");
        boolean hasCooked = invContains("Shrimps");
        boolean hasLogs = invContains("Logs");
        diag("inv: raw=" + hasRaw + " cooked=" + hasCooked + " logs=" + hasLogs);
        boolean hasFire = isFireLit();
        diag("fire: " + hasFire);

        // "How many do you want to cook?" — pick the first option.
        // This is the ONLY dialog we must answer; informational dialogs
        // don't block world clicks, so we just ignore them and act.
        if (safeHasSelectAnOption()) {
            diag("Choosing cook amount option");
            try { Rs2Dialogue.keyPressForDialogueOption(1); } catch (Exception ignored) {}
            return;
        }

        // State-driven: do the next thing the tutorial actually still needs.
        // Check completion FIRST — if we have cooked shrimp, we're done.
        if (hasCooked) {
            diag("Have cooked shrimp, survivalDone=true");
            survivalDone = true;
            return;
        }
        if (!hasRaw) {
            Microbot.status = "Tutorial Island: catching shrimp";
            runAction("fish", () -> interactNpc("Fishing spot", "Net"));
        } else if (!hasFire) {
            if (!hasLogs) {
                Microbot.status = "Tutorial Island: chopping tree";
                runAction("chop", () -> interactObject("Tree", "Chop down"));
            } else {
                Microbot.status = "Tutorial Island: lighting fire";
                runAction("light", () -> {
                    Rs2Inventory.combine("Tinderbox", "Logs");
                    fireLitAt = System.currentTimeMillis();
                    diag("Fire lit, timestamp set");
                });
            }
        } else {
            Microbot.status = "Tutorial Island: cooking shrimp";
            runAction("cook", () -> useItemOnObject("Raw shrimps", "Fire"));
        }
    }

    // Doors we've already opened — never click twice. Verified by position crossing.
    private final java.util.Set<String> doorsHandled = java.util.Collections.synchronizedSet(new java.util.HashSet<>());

    // Rotate camera to face a world position (helps door clicking and pathfinding)
    private void rotateCameraTo(WorldPoint target) {
        try {
            WorldPoint p = Rs2Player.getWorldLocation();
            int dx = target.getX() - p.getX();
            int dy = target.getY() - p.getY();
            // Calculate yaw angle (0-2047) — RuneLite uses 0=north, clockwise
            double angle = Math.atan2(dx, dy); // atan2(east, north)
            int yawVal = (int) ((angle * 1024 / Math.PI + 1024) % 2048);
            if (yawVal < 0) yawVal += 2048;
            final int yaw = yawVal;
            Microbot.getClientThread().invoke(() -> {
                try {
                    Microbot.getClient().setCameraYawTarget(yaw);
                } catch (Exception e) { /* ignore */ }
            });
            sleep(300, 500); // Let camera settle
        } catch (Exception e) {
            diag("Camera rotate failed: " + e);
        }
    }

    // Open a specific door ONCE by ID and position. Returns true if handled.
    // Tracks in doorsHandled so we never click the same door twice.
    private boolean openDoorOnce(int doorId, WorldPoint doorPos, String action) {
        String key = doorId + "@" + doorPos.getX() + "," + doorPos.getY();
        if (doorsHandled.contains(key)) {
            return true; // Already handled, don't re-click
        }
        WorldPoint p = Rs2Player.getWorldLocation();
        if (p == null) return false;
        if (p.distanceTo(doorPos) > 12) {
            diag("Door " + doorId + " too far (" + p.distanceTo(doorPos) + " tiles), skipping");
            return false;
        }
        // Build 134 (Alex 2026-09-27): Verify crossing via tile change, not click success.
        // Record tile before the action. The door is only marked "handled" if the
        // player tile actually changes (indicating movement through the door).
        // A click return is NOT a crossing.
        WorldPoint tileBefore = p;
        // Face the door
        rotateCameraTo(doorPos);
        // Walk to adjacent tile if not close
        if (p.distanceTo(doorPos) > 3) {
            Rs2Walker.walkTo(doorPos);
            // Wait until close or timeout (no fixed sleep)
            boolean arrived = Global.sleepUntil(() -> {
                WorldPoint cur = Rs2Player.getWorldLocation();
                return cur != null && cur.distanceTo(doorPos) <= 3;
            }, 8000);
            if (!arrived) {
                diag("Door " + doorId + ": failed to reach adjacent tile, not clicking");
                return false;
            }
        }
        // Click via scene scan
        boolean clicked = false;
        try {
            clicked = clickDoorDirect(action);
        } catch (Exception e) {
            diag("Door click failed: " + e);
        }
        if (!clicked) {
            return false;
        }
        // Click succeeded. Now VERIFY the crossing: wait for tile change.
        // Use a bounded sleepUntil that checks for actual movement.
        diag("Door " + doorId + ": click issued, verifying crossing (tile before=" + tileBefore + ")");
        boolean crossed = Global.sleepUntil(() -> {
            WorldPoint cur = Rs2Player.getWorldLocation();
            if (cur == null || tileBefore == null) return false;
            // Crossing verified if player moved at least 1 tile from before.
            // (Door tiles are walls; moving through means position changed.)
            int dx = Math.abs(cur.getX() - tileBefore.getX());
            int dy = Math.abs(cur.getY() - tileBefore.getY());
            return (dx + dy) >= 1;
        }, 5000);
        if (crossed) {
            WorldPoint tileAfter = Rs2Player.getWorldLocation();
            doorsHandled.add(key);
            diag("Door " + doorId + " CROSSED: " + tileBefore + " -> " + tileAfter + ", marked handled");
            return true;
        } else {
            diag("Door " + doorId + ": click succeeded but no crossing verified (tile unchanged). NOT marking handled.");
            return false;
        }
    }

    private void doChef() {
        Microbot.status = "Tutorial Island: Master Chef";
        if (npcReachable("Quest Guide", 40)) {
            chefDone = true;
            return;
        }

        WorldPoint p = Rs2Player.getWorldLocation();

        // === PHASE 1: Get to the chef (Survival -> Gate -> Kitchen) ===
        // If we don't have bread yet and chef isn't nearby, navigate to kitchen
        if (!breadBaked && !Rs2Inventory.hasItem("Bread")) {
            // If the chef isn't in NPC cache, walk toward the gate first
            if (findNpcTimeout("Master Chef") == null) {
                Microbot.status = "Tutorial Island: walking to chef area...";
                WorldPoint gate = new WorldPoint(3090, 3092, 0);
                if (p.distanceTo(gate) > 3) {
                    Rs2Walker.walkTo(gate);
                    Global.sleepUntil(() -> Rs2Player.getWorldLocation().distanceTo(gate) <= 3, 15000);
                } else {
                    // At gate: open 9708 ONCE, walk through
                    openDoorOnce(9708, gate, "Open");
                    WorldPoint beyondGate = new WorldPoint(3080, 3085, 0);
                    Rs2Walker.walkTo(beyondGate);
                    Global.sleepUntil(() -> Rs2Player.getWorldLocation().distanceTo(beyondGate) <= 3, 15000);
                }
                return;
            }

            // Chef is nearby: get inside via south entrance (9709 at 3079,3084)
            WorldPoint southDoor = new WorldPoint(3079, 3084, 0);
            // COOK_BUILDING area: x 3073-3078, y 3083-3086 (inside)
            boolean insideKitchen = p.getX() >= 3073 && p.getX() <= 3078 && p.getY() >= 3083 && p.getY() <= 3086;
            if (!insideKitchen) {
                openDoorOnce(9709, southDoor, "Open");
                // Walk inside
                WorldPoint inside = new WorldPoint(3075, 3085, 0);
                Rs2Walker.walkTo(inside);
                Global.sleepUntil(() -> {
                    WorldPoint pp = Rs2Player.getWorldLocation();
                    return pp.getX() >= 3073 && pp.getX() <= 3078 && pp.getY() >= 3083 && pp.getY() <= 3086;
                }, 15000);
                return;
            }

            // Inside: talk to chef, make dough, bake bread
            if (!talkTo("Master Chef")) return;
            if (!spamDialogue()) return;

            if (!Rs2Inventory.hasItem("Pot of flour") || !Rs2Inventory.hasItem("Bucket of water")) {
                diag("Missing flour/water, talking to chef again");
                return;
            }
            Rs2Inventory.combine("Pot of flour", "Bucket of water");
            if (!waitForItem("Bread dough", 12000)) return;

            if (!useItemOnObject("Bread dough", "Range")) return;
            if (!waitForItem("Bread", 20000)) return;
            breadBaked = true;

            if (!talkTo("Master Chef")) return;
            if (!spamDialogue()) return;
            diag("Bread baked, heading to exit door");
            return;
        }

        // === PHASE 2: Bread done — exit via northwest door (9710), go to Quest Guide ===
        diag("Have bread, exiting kitchen via northwest door");
        // Dismiss any open dialogue first
        if (safeIsInDialogue()) {
            if (safeHasSelectAnOption()) {
                try { Rs2Dialogue.keyPressForDialogueOption(3); } catch (Exception ignored) {}
                Global.sleepUntil(() -> !safeHasSelectAnOption(), 3000);
            }
            spamDialogue(5000);
        }

        // Step 1: Go to northwest exit door (9710 at 3071, 3090) and open ONCE
        WorldPoint exitDoor = new WorldPoint(3071, 3090, 0);
        // Check if we're already past the exit door (north of it)
        boolean pastExit = p.getY() > 3090 && p.getX() <= 3075;
        if (!pastExit) {
            // Need to get to and through the exit door
            if (p.distanceTo(exitDoor) > 4) {
                // Walk to the exit door (inside the kitchen)
                Rs2Walker.walkTo(exitDoor);
                Global.sleepUntil(() -> Rs2Player.getWorldLocation().distanceTo(exitDoor) <= 4, 15000);
                return;
            } else {
                // At the door: open ONCE, walk through to far side
                openDoorOnce(9710, exitDoor, "Open");
                // Walk to far side waypoint (beyond the door)
                WorldPoint beyondExit = new WorldPoint(3071, 3094, 0);
                Rs2Walker.walkTo(beyondExit);
                Global.sleepUntil(() -> Rs2Player.getWorldLocation().getY() > 3090, 10000);
                return;
            }
        }

        // Step 2: Follow PATH_TO_QUEST_BUILDING waypoints (from OSBot, verified)
        WorldPoint[] questPath = {
            new WorldPoint(3071, 3094, 0),
            new WorldPoint(3071, 3099, 0),
            new WorldPoint(3072, 3103, 0),
            new WorldPoint(3074, 3108, 0),
            new WorldPoint(3076, 3111, 0),
            new WorldPoint(3077, 3115, 0),
            new WorldPoint(3076, 3118, 0),
            new WorldPoint(3076, 3122, 0),
            new WorldPoint(3079, 3125, 0),
            new WorldPoint(3083, 3127, 0),
            new WorldPoint(3086, 3126, 0),
        };
        for (WorldPoint wp : questPath) {
            p = Rs2Player.getWorldLocation();
            if (p.distanceTo(wp) > 4) {
                // Face the waypoint (helps pathfinding)
                rotateCameraTo(wp);
                Rs2Walker.walkTo(wp);
                Global.sleepUntil(() -> Rs2Player.getWorldLocation().distanceTo(wp) <= 4, 12000);
                // If we're stuck (didn't move), break to avoid infinite loop
                WorldPoint after = Rs2Player.getWorldLocation();
                if (after.distanceTo(wp) > 8 && after.distanceTo(p) < 2) {
                    diag("Stuck on path to Quest Guide at " + after);
                    break;
                }
            }
            // NOTE: Do NOT set chefDone here just because the NPC is near —
            // the Quest Guide is visible through the wall. We must be INSIDE
            // the building (door opened) before transitioning.
        }

        // Step 3: At Quest Guide building — open door 9716 ONCE, go inside.
        // The door MUST be opened before chefDone is set, otherwise the next
        // stage tries to talk through a closed door.
        p = Rs2Player.getWorldLocation();
        // QUEST_BUILDING area: x 3083-3089, y 3119-3125 (inside)
        boolean insideQuest = p.getX() >= 3083 && p.getX() <= 3089 && p.getY() >= 3119 && p.getY() <= 3125;
        if (!insideQuest) {
            WorldPoint questDoor = new WorldPoint(3085, 3127, 0);
            diag("Opening Quest Guide door at " + questDoor);
            openDoorOnce(9716, questDoor, "Open");
            // Walk inside through the opened door
            WorldPoint insideQ = new WorldPoint(3086, 3122, 0);
            Rs2Walker.walkTo(insideQ);
            boolean gotInside = Global.sleepUntil(() -> {
                WorldPoint pp = Rs2Player.getWorldLocation();
                return pp.getX() >= 3083 && pp.getX() <= 3089 && pp.getY() >= 3119 && pp.getY() <= 3125;
            }, 15000);
            if (!gotInside) {
                diag("Failed to get inside Quest building, retrying door");
                doorsHandled.remove(9716 + "@3085,3127"); // Allow retry
                return;
            }
        }

        // Only mark chef done when we're INSIDE with the Quest Guide reachable
        p = Rs2Player.getWorldLocation();
        insideQuest = p.getX() >= 3083 && p.getX() <= 3089 && p.getY() >= 3119 && p.getY() <= 3125;
        if (insideQuest && npcReachable("Quest Guide", 15)) {
            chefDone = true;
            diag("Inside Quest building, chef stage complete");
        }
    }

    private void doQuestGuide() {
        Microbot.status = "Tutorial Island: Quest Guide";
        if (npcReachable("Mining Instructor", 40)) {
            questGuideDone = true;
            return;
        }

        // If we're outside the Quest building, open the door first.
        // (Safety net in case the chef stage transitioned early.)
        WorldPoint p = Rs2Player.getWorldLocation();
        boolean insideQuest = p.getX() >= 3083 && p.getX() <= 3089 && p.getY() >= 3119 && p.getY() <= 3125;
        if (!insideQuest && findNpcTimeout("Quest Guide") != null) {
            diag("Outside Quest building, opening door 9716");
            WorldPoint questDoor = new WorldPoint(3085, 3127, 0);
            openDoorOnce(9716, questDoor, "Open");
            WorldPoint insideQ = new WorldPoint(3086, 3122, 0);
            Rs2Walker.walkTo(insideQ);
            Global.sleepUntil(() -> {
                WorldPoint pp = Rs2Player.getWorldLocation();
                return pp.getX() >= 3083 && pp.getX() <= 3089 && pp.getY() >= 3119 && pp.getY() <= 3125;
            }, 15000);
            return;
        }

        // The Quest Guide has a multi-part dialogue (welcome → quest list →
        // more instructions). The ladder stays locked ("not ready") until ALL
        // of it is done. Click the tab ONCE, then just handle dialogue.
        if (!questTabClicked) {
            if (!talkTo("Quest Guide")) return;
            if (!spamDialogue()) return;

            // Open the quest journal tab as instructed — PHYSICAL MOUSE CLICK,
            // not hotkey. The tutorial only registers a real click.
            diag("Attempting physical click on QUESTS tab");
            boolean questClicked = clickTabIcon(InterfaceTab.QUESTS, true);
            if (!questClicked) {
                diag("QUESTS click failed, trying PRAYER (per user report)");
                clickTabIcon(InterfaceTab.PRAYER, true);
            }
            questTabClicked = true;
            diag("Tab clicked, will not click again. Handling dialogue...");
            Global.sleep(2000, 3000);
        }

        // Tab already clicked (or just clicked above) — just handle the dialogue.
        // This will pick "Nope, I'm ready to move on!" when asked.
        if (safeIsInDialogue()) {
            spamDialogue(10000);
        }
        // If still in dialogue, wait for next tick. Don't try ladder yet.
        if (safeIsInDialogue()) {
            diag("Still in Quest Guide dialogue, waiting...");
            return;
        }

        // Dialogue done — try the ladder. Don't loop back to talking.
        // Dialog cleared — reset stuck counter
        questGuideTalkStuckCount = 0;

        // Dialogue fully done — climb down.
        // Dialogue fully done — climb down the ladder at (3088, 3119).
        // Walk to it first, then click via scene scan.
        WorldPoint ladderPos = new WorldPoint(3088, 3119, 0);
        WorldPoint playerPos = Rs2Player.getWorldLocation();
        if (playerPos.distanceTo(ladderPos) > 3) {
            diag("Walking to ladder at " + ladderPos);
            Rs2Walker.walkTo(ladderPos);
            Global.sleep(1000, 1500);
        }
        boolean ladderFound = false;
        try {
            ladderFound = clickDoorDirect("Climb-down");
        } catch (Exception e) {
            diag("Ladder scan failed: " + e);
        }
        if (!ladderFound) {
            diag("Ladder click via scan failed, trying direct tile click");
            // Fallback: click the ladder tile directly via mouse
            try {
                net.runelite.api.coords.LocalPoint lp = net.runelite.api.coords.LocalPoint.fromWorld(
                    Microbot.getClient(), ladderPos);
                if (lp != null) {
                    net.runelite.api.Perspective.getCanvasTilePoly(Microbot.getClient(), lp);
                    // Use Rs2TileObjectModel via scene scan result instead
                    interactObject("Ladder", "Climb-down");
                }
            } catch (Exception e) {
                diag("Ladder fallback failed: " + e);
            }
        }
        if (Global.sleepUntil(() -> npcReachable("Mining Instructor", 40), 30000)) {
            questGuideDone = true;
        } else {
            diag("Ladder attempt didn't reach caves — will retry");
        }
    }

    private void doMining() {
        Microbot.status = "Tutorial Island: Mining Instructor";
        if (npcReachable("Combat Instructor", 40)) {
            miningDone = true;
            return;
        }

        // Talk to Dezzick once to get the pickaxe — BUT skip if we already
        // have the bronze bar and hammer (mining already done, no need to talk).
        // The explanation dialog has no continue button — close it with ESC.
        boolean hasBarAlready = Rs2Inventory.contains("Bronze bar");
        boolean hasHammerAlready = Rs2Inventory.contains("Hammer");
        boolean hasDaggerAlready = Rs2Inventory.contains("Bronze dagger");
        if (!miningTalked && !hasDaggerAlready && !(hasBarAlready && hasHammerAlready)) {
            if (!talkTo("Mining Instructor")) return;
            // Dismiss the info dialog (no continue button)
            if (safeIsInDialogue()) {
                try { Rs2Keyboard.keyPress(KeyEvent.VK_ESCAPE); } catch (Exception ignored) {}
                Global.sleep(800, 1200);
            }
            // If dialogue still open, try clicking the X via ESC again, then move on
            if (safeIsInDialogue()) {
                diag("Mining dialog still open after ESC, proceeding anyway");
            }
            miningTalked = true;
        } else if (!miningTalked) {
            diag("Skipping instructor talk — already have bar+hammer/dagger");
            miningTalked = true;
        }
        // Glitch dialogue check runs INDEPENDENT of isInDialogue() — the
        // "Mismatch..." warning isn't a real dialogue so the API misses it.
        // If the glitch text is on screen, SPACE it away.
        if (isGlitchDialog()) {
            diag("Dismissing glitch dialog with SPACE");
            try { Rs2Keyboard.keyPress(KeyEvent.VK_SPACE); } catch (Exception ignored) {}
            Global.sleep(600, 900);
            // Check again — if still there, click "Click here to continue" directly
            if (isGlitchDialog()) {
                try {
                    Widget cont = Rs2Widget.findWidget("Click here to continue");
                    if (cont != null) Rs2Widget.clickWidget(cont);
                } catch (Exception ignored) {}
                Global.sleep(600, 900);
            }
        } else if (safeIsInDialogue()) {
            // Real dialog open on later tick — close it, don't loop
            try { Rs2Keyboard.keyPress(KeyEvent.VK_ESCAPE); } catch (Exception ignored) {}
            Global.sleep(600, 900);
        }

        // Mine one tin ore and one copper ore — BUT skip entirely if we
        // already have the bronze bar or dagger (ores were already used).
        // Rocks are named "Tin rocks" and "Copper rocks" (not generic "Rocks").
        boolean hasBar = Rs2Inventory.contains("Bronze bar");
        boolean hasDagger = Rs2Inventory.contains("Bronze dagger");
        if (!hasBar && !hasDagger) {
            if (!mineOre("Tin ore", "Tin rocks")) return;
            if (!mineOre("Copper ore", "Copper rocks")) return;
        } else {
            diag("Skipping mining — already have bar/dagger");
        }

        // Smelt a bronze bar at the furnace — only if we don't have one yet.
        if (!hasBar && !hasDagger) {
            diag("Smelting bronze bar");
            if (!Rs2Inventory.use("Tin ore")) return;
            Rs2TileObjectModel furnace = findObjectFast("Furnace", 30);
            if (furnace == null) {
                diag("Smelt: furnace not found");
                return;
            }
            // Walk to the furnace first so it's on-screen, then left-click
            // (we're in "Use Tin ore ->" mode, so a plain click uses the ore on it).
            diag("Walking to furnace at " + furnace.getWorldLocation());
            try {
                int dist = Microbot.getClient().getLocalPlayer().getWorldLocation()
                        .distanceTo(furnace.getWorldLocation());
                if (dist > 4) {
                    Rs2Walker.walkTo(furnace.getWorldLocation());
                    Global.sleep(700, 900);
                }
            } catch (Exception ignored) {
                Rs2Walker.walkTo(furnace.getWorldLocation());
                Global.sleep(700, 900);
            }
            furnace.click();
            Global.sleep(800, 1200);
            // Smelting interface: pick bronze.
            Widget bronze = Rs2Widget.findWidget("Bronze bar");
            if (bronze == null) bronze = Rs2Widget.findWidget("Bronze");
            if (bronze != null) Rs2Widget.clickWidget(bronze);
            if (!waitForItem("Bronze bar", 20000)) return;
        } else {
            diag("Skipping smelt — already have bar/dagger");
        }

        // Get the hammer from the instructor (needed to smith) — BUT only if
        // we're actually going to smith (no dagger yet). If we have the dagger,
        // the hammer is useless, skip the talk entirely.
        if (!Rs2Inventory.contains("Bronze dagger") && !Rs2Inventory.contains("Hammer")) {
            diag("Getting hammer from Mining Instructor");
            talkTo("Mining Instructor");
            spamDialogue();
            if (!waitForItem("Hammer", 15000)) {
                diag("Hammer not received, continuing anyway");
            }
        }

        // Smith a dagger on the anvil — SKIP entirely if we already have one.
        // (The bar is used up when the dagger is made, so don't try to use it.)
        if (!Rs2Inventory.contains("Bronze dagger")) {
            if (!Rs2Inventory.use("Bronze bar")) return;
            Rs2TileObjectModel anvil = findObjectFast("Anvil", 30);
            if (anvil == null) {
                diag("Smith: anvil not found");
                return;
            }
            diag("Walking to anvil at " + anvil.getWorldLocation());
            // Only walk if we're not already close
            try {
                int dist = Microbot.getClient().getLocalPlayer().getWorldLocation()
                        .distanceTo(anvil.getWorldLocation());
                if (dist > 4) {
                    Rs2Walker.walkTo(anvil.getWorldLocation());
                    Global.sleep(700, 900);
                }
            } catch (Exception ignored) {
                Rs2Walker.walkTo(anvil.getWorldLocation());
                Global.sleep(700, 900);
            }
        anvil.click();
        Global.sleep(800, 1200);
        // Select the dagger in the smithing interface. Find the visible
        // "dagger" widget (case-insensitive) and click its center directly.
        // The plain findWidget("Dagger") was hitting the wrong widget.
        if (!clickSmithingDagger()) {
            diag("Dagger widget not found, retrying anvil click");
            anvil.click();
            Global.sleep(800, 1200);
            clickSmithingDagger();
        }
        if (!waitForItem("Bronze dagger", 25000)) return;
        } else {
            diag("Skipping smith — already have bronze dagger");
        }

        // After the dagger: NO instructor talk. It loops "tell me about mining
        // again" forever. Just go straight to the gate.
        // To the combat area.
        interactObject("Gate", "Open");
        if (Global.sleepUntil(() -> npcReachable("Combat Instructor", 40), 45000)) {
            miningDone = true;
        }
    }

    /** Click the dagger option in the smithing interface.
     *  Searches for "Bronze dagger" (more specific than "Dagger") and clicks it. */
    private boolean clickSmithingDagger() {
        try {
            Widget found = Rs2Widget.findWidget("Bronze dagger");
            if (found == null) found = Rs2Widget.findWidget("Dagger");
            final Widget dagger = found;
            if (dagger != null) {
                // REBUILD: was blocking invoke() for bounds. Call directly;
                // fall back to Rs2Widget.clickWidget on failure.
                int[] coords = null;
                try {
                    java.awt.Rectangle b = dagger.getBounds();
                    if (b != null) {
                        coords = new int[]{b.x + b.width / 2, b.y + b.height / 2};
                    }
                } catch (Exception e) {
                    // fall through to null
                }
                if (coords != null) {
                    diag("Clicking dagger widget at " + coords[0] + "," + coords[1]);
                    Microbot.getMouse().click(coords[0], coords[1]);
                    Global.sleep(800, 1200);
                    return true;
                } else {
                    // Fallback to Rs2Widget click
                    Rs2Widget.clickWidget(dagger);
                    Global.sleep(800, 1200);
                    return true;
                }
            } else {
                diag("clickSmithingDagger: no dagger widget found");
            }
        } catch (Exception e) {
            diag("clickSmithingDagger failed: " + e);
        }
        return false;
    }

    /** Mine the nearest "Rocks" until the given ore is in inventory. */
    /** Build 104: is the object's actual canvas click point on screen?
     *  Rs2Camera.isTileOnScreen() checks the TILE's projection, which can
     *  disagree with the object's click-point projection (large/wall-hugging
     *  objects near the screen edge): seen live 17:02:38/17:02:57, the poll
     *  booth's tile read "on screen" while its click point was (-46,315),
     *  so leftClickObject() refused it every tick and the camera never
     *  turned -- a deterministic miss loop. Check the real point. */
    private boolean isClickPointOnScreen(Rs2TileObjectModel obj) {
        try {
            net.runelite.api.Point c = obj.getCanvasLocation();
            return c != null && c.getX() >= 0 && c.getY() >= 0
                    && c.getX() <= 2000 && c.getY() <= 2000;
        } catch (Exception e) {
            return false;
        }
    }

    /** Left-click a tile object directly (like a player would).
     *  Bypasses menu-action matching which can open the right-click menu
     *  without selecting. Returns false if the object is not on-screen
     *  (so the caller can fall back to rock.click()). */
    private boolean leftClickObject(Rs2TileObjectModel obj) {
        try {
            // REBUILD: was blocking invoke(). getCanvasLocation() is a pure
            // perspective projection (math on volatile camera fields) — safe
            // to call directly without the client thread.
            java.awt.Point p = null;
            try {
                net.runelite.api.Point canvas = obj.getCanvasLocation();
                if (canvas != null) {
                    p = new java.awt.Point(canvas.getX(), canvas.getY());
                }
            } catch (Exception e) {
                // fall through to null
            }
            if (p != null) {
                // Validate on-screen: RuneLite canvas is ~765x503 for fixed mode.
                // Negative or huge coordinates mean the object isn't visible.
                if (p.x < 0 || p.y < 0 || p.x > 2000 || p.y > 2000) {
                    diag("leftClickObject: point " + p.x + "," + p.y + " off-screen, using fallback");
                    return false;
                }
                diag("Left-clicking object at " + p.x + "," + p.y);
                Microbot.getMouse().click(p.x, p.y);
                return true;
            } else {
                diag("leftClickObject: canvas location is null (object not on screen?)");
            }
        } catch (Exception e) {
            diag("leftClickObject failed: " + e);
        }
        return false;
    }

    /** Prospect a rock (right-click menu action). */
    private boolean prospectRock(String rockName) {
        long deadline = System.currentTimeMillis() + 60000;
        while (System.currentTimeMillis() < deadline) {
            Rs2TileObjectModel rock;
            try {
                rock = Microbot.getRs2TileObjectCache().query()
                        .within(25)
                        .withName(rockName)
                        .toList().stream().findFirst().orElse(null);
            } catch (Exception e) {
                rock = null;
            }
            if (rock == null) {
                diag("prospectRock: no '" + rockName + "' found");
                Global.sleep(1500, 2500);
                continue;
            }
            diag("Prospecting " + rockName + " at " + rock.getWorldLocation());
            rock.click("Prospect");
            // Prospecting shows a dialog — dismiss it
            Global.sleepUntil(() -> safeIsInDialogue(), 8000);
            spamDialogue(8000);
            return true;
        }
        return false;
    }

    private boolean mineOre(String oreName, String rockName) {
        diag("mineOre called for " + oreName + " (" + rockName + "), has=" + Rs2Inventory.contains(oreName));
        if (Rs2Inventory.contains(oreName)) return true;
        long deadline = System.currentTimeMillis() + 120000;
        WorldPoint lastRockPos = null;
        int failCount = 0;
        while (System.currentTimeMillis() < deadline && !Rs2Inventory.contains(oreName)) {
            final WorldPoint skip = lastRockPos;
            Rs2TileObjectModel rock = null;
            try {
                // REBUILD: was a blocking invoke() scene scan. Now uses the
                // event-driven cache directly (non-blocking). The cache query
                // was already the fallback; it's now the primary.
                rock = Microbot.getRs2TileObjectCache().query()
                        .within(40)
                        .withName(rockName)
                        .toList().stream()
                        .filter(r -> skip == null || !r.getWorldLocation().equals(skip))
                        .findFirst().orElse(null);
            } catch (Exception e) {
                rock = null;
            }
            if (rock == null) {
                failCount++;
                // Every 3 failures, rotate camera to bring rocks into view/cache
                if (failCount % 3 == 0) {
                    diag("mineOre: rotating camera to find " + rockName);
                    try {
                        // Press right arrow key to rotate camera
                        Rs2Keyboard.keyPress(KeyEvent.VK_RIGHT);
                        Global.sleep(500, 700);
                        Rs2Keyboard.keyRelease(KeyEvent.VK_RIGHT);
                    } catch (Exception ignored) {}
                }
                Global.sleep(300, 500); // fast retry
                continue;
            }
            failCount = 0; // reset on success
            lastRockPos = rock.getWorldLocation();
            diag("mineOre: found " + rockName + " at " + rock.getWorldLocation());
            // Walk close first so the rock is on-screen (click needs a valid canvas point).
            // The scene scan finds it off-screen, but we can't click what we can't see.
            WorldPoint rockPos = rock.getWorldLocation();
            if (Rs2Player.getWorldLocation().distanceTo(rockPos) > 4) {
                WorldPoint standTile = adjacentWalkable(rockPos);
                if (standTile != null) {
                    Rs2Walker.walkTo(standTile);
                    Global.sleep(400, 600);
                    // Re-query the cache now that we're close (fresh model).
                    // REBUILD: was blocking invoke() scene scan.
                    try {
                        Rs2TileObjectModel fresh = Microbot.getRs2TileObjectCache().query()
                                .within(40)
                                .withName(rockName)
                                .nearest();
                        if (fresh != null) rock = fresh;
                    } catch (Exception ignored) {}
                }
            }
            // Use default click (left-click Mine). The custom leftClickObject
            // blocks on client thread when dialog is open.
            rock.click();
            // Wait for an ore (any) to arrive, then loop and check for the wanted one.
            int before = Rs2Inventory.count();
            Global.sleepUntil(() -> Rs2Inventory.count() != before
                    || Rs2Inventory.contains(oreName), 20000);
            waitForStill();
        }
        return Rs2Inventory.contains(oreName);
    }

    // ------------------------------------------------------------------
    // Tick-based (non-blocking) helpers — Build 63.
    // Each method performs ONE action and returns immediately. The ~600ms
    // script tick re-invokes the stage, which re-derives state from the
    // game and takes the next step. Nothing here sleeps or blocks.
    // ------------------------------------------------------------------

    /** Click "Talk-to" on an NPC once. No waiting — the next tick checks dialogue. */
    /**
     * Build 166 (Alex): race-free talk. The old supplyAsync(npc.click()).get(5s)
     * DISCARDED the future on timeout -- the zombie thread kept running
     * npc.click -> CantReachTargetRecovery.walkTo (BLOCKING) while the tick
     * moved on to door/walkStep work (two movement owners, source-confirmed
     * race; timeout is not cancellation).
     * Now: (1) NPC from GameTick snapshot (id/index/name/tile/actions, zero
     * blocking); (2) explicit walkStep travel to the fresh NPC position --
     * the tick is the single movement owner; (3) when adjacent, a direct
     * menu invoke that cannot initiate another walk (bypasses click()'s
     * recovery path entirely).
     */
    private boolean talkToOnce(String npcName) {
        WorldModel.NpcSnapshot snap = findNpcSnapshot(npcName);
        if (snap == null || snap.tile == null) {
            diag("Build 166 talk: '" + npcName + "' not in NPC snapshot (not nearby)");
            return false;
        }
        WorldPoint pp = worldModel.playerPos;
        if (pp == null) return false;
        int dist = Math.abs(pp.getX() - snap.tile.getX())
                 + Math.abs(pp.getY() - snap.tile.getY());
        diag("Build 166 talk: '" + snap.name + "' id=" + snap.id + " idx=" + snap.index
            + " at " + snap.tile + " dist=" + dist);
        if (dist > 2) {
            // Explicit stepwise travel to the fresh NPC position. Single
            // movement owner: this tick's walkStep. Y alone is not arrival.
            WorldPoint adj = closestAdjacentTile(snap.tile, pp);
            if (adj != null) {
                try {
                    Rs2Walker.walkStep(adj, 0);
                } catch (Exception e) {
                    diag("Build 166 talk: walkStep failed: " + e.getClass().getSimpleName());
                }
            }
            return false; // not arrived yet; next tick re-derives
        }
        // Adjacent: direct interaction that cannot initiate another walk.
        return clickNpcDirect(snap, "Talk-to");
    }

    /** Nearest NPC snapshot by exact name (equalsIgnoreCase -- Alex audit:
     *  withName("Brother Brace") was already exact, no wrong-name bug). */
    private WorldModel.NpcSnapshot findNpcSnapshot(String name) {
        try {
            java.util.List<WorldModel.NpcSnapshot> snaps = worldModel.npcSnapshots.get();
            if (snaps == null || name == null) return null;
            WorldPoint pp = worldModel.playerPos;
            WorldModel.NpcSnapshot best = null;
            int bestDist = Integer.MAX_VALUE;
            for (WorldModel.NpcSnapshot s : snaps) {
                if (s.name != null && s.name.equalsIgnoreCase(name)) {
                    int d = (pp != null && s.tile != null)
                        ? Math.abs(pp.getX() - s.tile.getX())
                          + Math.abs(pp.getY() - s.tile.getY())
                        : 0;
                    if (d < bestDist) { bestDist = d; best = s; }
                }
            }
            return best;
        } catch (Exception e) {
            return null;
        }
    }

    /** NPC model by ID AND index from cache -- getId()/getIndex() are direct
     *  reads, no blocking. Build 167 (Alex): match BOTH to avoid selecting
     *  another same-ID NPC. */
    private Rs2NpcModel findNpcModelByIdIndex(int id, int index) {
        try {
            var list = Microbot.getRs2NpcCache().query().within(12).toList();
            if (list == null) return null;
            for (Rs2NpcModel m : list) {
                try {
                    if (m.getId() == id && m.getIndex() == index) return m;
                } catch (Exception ignored) {}
            }
        } catch (Exception ignored) {}
        return null;
    }

    /** Closest N/S/E/W tile to the NPC, by pure math (no blocking reachability). */
    private WorldPoint closestAdjacentTile(WorldPoint tile, WorldPoint pp) {
        if (tile == null || pp == null) return null;
        int[][] offs = {{0, 1}, {0, -1}, {1, 0}, {-1, 0}};
        WorldPoint best = null;
        int bestD = Integer.MAX_VALUE;
        for (int[] o : offs) {
            WorldPoint c = new WorldPoint(tile.getX() + o[0], tile.getY() + o[1], tile.getPlane());
            int d = Math.abs(pp.getX() - c.getX()) + Math.abs(pp.getY() - c.getY());
            if (d < bestD) { bestD = d; best = c; }
        }
        return best;
    }

    /**
     * Build 166 (Alex): direct NPC menu invoke that cannot walk. Replicates
     * the direct tail of Rs2NpcModel.click() (NewMenuEntry doInvoke) but
     * SKIPS the CantReachTargetRecovery.walkTo path -- the caller guarantees
     * adjacency via snapshot math, so no walk is ever needed.
     */
    private boolean clickNpcDirect(WorldModel.NpcSnapshot snap, String action) {
        try {
            int actionIdx = -1;
            if (snap.actions != null) {
                for (int i = 0; i < snap.actions.length; i++) {
                    if (action.equalsIgnoreCase(snap.actions[i])) { actionIdx = i; break; }
                }
            }
            if (actionIdx < 0 || actionIdx > 4) {
                diag("Build 166 talk: action '" + action + "' not in "
                    + java.util.Arrays.toString(snap.actions));
                return false;
            }
            MenuAction ma;
            switch (actionIdx) {
                case 0: ma = MenuAction.NPC_FIRST_OPTION; break;
                case 1: ma = MenuAction.NPC_SECOND_OPTION; break;
                case 2: ma = MenuAction.NPC_THIRD_OPTION; break;
                case 3: ma = MenuAction.NPC_FOURTH_OPTION; break;
                default: ma = MenuAction.NPC_FIFTH_OPTION; break;
            }
            Rs2NpcModel model = findNpcModelByIdIndex(snap.id, snap.index);
            if (model == null) {
                diag("Build 167 talk: model id=" + snap.id + " idx=" + snap.index
                    + " not in cache (id+index match)");
                return false;
            }
            // Build 167 (Alex): use the RAW NPC, not the API wrapper.
            // Match its index to the snapshot, pass raw NPC to actor() and
            // getActorClickbox().
            net.runelite.api.NPC rawNpc = null;
            try { rawNpc = model.getNpc(); } catch (Exception ignored) {}
            if (rawNpc == null) {
                diag("Build 167 talk: raw NPC null for id=" + snap.id);
                return false;
            }
            // Camera turn only -- never a walk.
            try { Rs2Camera.turnTo(rawNpc); } catch (Exception ignored) {}
            java.awt.Rectangle clickbox = null;
            try { clickbox = Rs2UiHelper.getActorClickbox(rawNpc); } catch (Exception ignored) {}
            if (clickbox == null) {
                diag("Build 167 talk: no clickbox for id=" + snap.id);
                return false;
            }
            Microbot.doInvoke(new NewMenuEntry()
                    .param0(0)
                    .param1(0)
                    .opcode(ma.getId())
                    .identifier(snap.index)
                    .itemId(-1)
                    .target(snap.name)
                    .actor(rawNpc)
                    .option(action),
                clickbox);
            diag("Build 166 talk: direct invoke '" + action + "' on '" + snap.name
                + "' id=" + snap.id + " idx=" + snap.index);
            return true;
        } catch (Exception e) {
            diag("Build 166 talk: direct invoke failed: " + e);
            return false;
        }
    }

    /** One continue click: widget click + space + direct "Click here to
     *  continue" widget click. Fire-and-forget; the next tick verifies. */
    private void clickContinueOnce() {
        try { Rs2Dialogue.clickContinue(); } catch (Exception ignored) {}
        try { Rs2Keyboard.keyPress(KeyEvent.VK_SPACE); } catch (Exception ignored) {}
        // REBUILD: removed the full widget-tree walk (blocking invoke).
        // Rs2Dialogue.clickContinue() + Space is sufficient; the next tick verifies.
    }

    /** Click a dialogue option by index (1-based) with the mouse. No sleep. */
    private boolean clickDialogueOptionNoSleep(int index) {
        try {
            // REBUILD: was blocking invoke(). Rs2Dialogue.getDialogueOptions()
            // uses non-blocking Rs2Widget.getWidget() internally.
            java.util.List<Widget> options = null;
            try {
                options = Rs2Dialogue.getDialogueOptions();
            } catch (Exception e) {
                // fall through to null
            }
            if (options != null && options.size() >= index) {
                Widget w = options.get(index - 1);
                java.awt.Rectangle b = w.getBounds();
                if (b != null && b.width > 0) {
                    int x = (int) b.getCenterX();
                    int y = (int) b.getCenterY();
                    diag("Clicking dialogue option " + index + " at " + x + "," + y);
                    Microbot.getMouse().click(x, y);
                    return true;
                }
            }
            diag("Option widget not found, using keypress for option " + index);
            Rs2Dialogue.keyPressForDialogueOption(index);
            return true;
        } catch (Exception e) {
            diag("clickDialogueOptionNoSleep failed: " + e);
            return false;
        }
    }

    /**
     * ONE tick of dialogue handling: performs a single dialogue action and
     * returns. Returns true when no dialogue remains (caller may proceed).
     * Never blocks, never sleeps.
     */
    private boolean dialogueTick() {
        if (checkIronmanPause()) return false;
        if (isGlitchDialog()) {
            diag("Ignoring client glitch dialog (cache warnings, not a real dialog)");
            return true;
        }
        // Build 170 (Alex): PRIORITIZE the actual Continue control FIRST.
        // Old order called followTutorialInstruction() before safeHasContinue().
        // When Brace says "I'm here to tell you all about Prayer" with
        // "Click here to continue" displayed, the keyword matcher saw 'prayer'
        // and tried clickTabIcon(PRAYER) -- but 548:69 is hidden=true while
        // dialogue is open, looping NO VERIFIED TARGET *inside* dialogueTick.
        // Stream visually confirmed the Continue text present. Actual Continue
        // -> click it and return, before broad keyword handling.
        if (safeHasContinue()) {
            diag("dialogueTick: clicking continue (priority over keyword handling)");
            clickContinueOnce();
            return false;
        }
        if (safeHasSelectAnOption()) {
            int opt = chooseDialogueOption();
            boolean inQuestGuide = false;
            try {
                inQuestGuide = getCurrentState() == Stage.QUEST_GUIDE;
            } catch (Exception ignored) {}
            if (inQuestGuide) {
                opt = 2;
                diag("Quest Guide option: picking 2 (move on)");
            }
            diag("dialogueTick: selecting option " + opt);
            clickDialogueOptionNoSleep(opt);
            return false;
        }
        if (safeIsInDialogue() && followTutorialInstruction()) {
            return false;
        }
        // Build 170 (Alex): safeHasContinue() is now checked FIRST at the top
        // of dialogueTick (priority over keyword handling). This old block is
        // removed to avoid double-handling; the Build 72 fallback below still
        // covers unknown dialogs.
        // Build 72 fallback: a dialog is up but no known continue/option
        // widget matched (e.g. client error popups on unexpected widget
        // groups). Still try Space plus a physical "Click here to continue"
        // click rather than stalling.
        if (safeIsInDialogue()) {
            diag("dialogueTick: unknown dialog, trying Space + continue click");
            clickContinueOnce();
            return false;
        }
        return !safeIsInDialogue();
    }

    /** Tick-based sub-states for the combat stage. One action per tick —
     *  each tick re-derives progress from observed game state (location,
     *  inventory, equipment, dialogue) so the bot can resume mid-sequence
     *  without repeating completed work. */
    private enum CombatSub {
        TALK_VANNAKA,       // talk to Combat Instructor, spam dialogue
        OPEN_EQUIPMENT_TAB, // physically open Worn Equipment tab
        CLICK_STATS,        // click Equipment Stats widget 387:2
        EQUIP_DAGGER,       // inventory tab (physical), wield dagger, verify via Rs2Equipment
        TALK_AFTER_DAGGER,  // continue/talk until Vannaka acknowledges
        EQUIP_SWORD_SHIELD, // wield sword + shield, verify via Rs2Equipment
        COMBAT_TAB_LESSON,  // open combat tab physically, select an attack style
        ENTER_PEN,          // open gate, enter rat pen
        WAIT_GATE_OPEN,     // Build 65: verify the gate actually opened before walking through
        KILL_RAT_MELEE,     // attack rat, wait for combat end (tick by tick)
        EXIT_PEN_TALK,      // exit pen, talk to Vannaka
        EQUIP_BOW_ARROWS,   // wield shortbow + bronze arrows, verify via Rs2Equipment
        KILL_RAT_RANGED,    // kill rat with ranged from OUTSIDE the pen
        FINAL_LADDER        // finish dialogue, climb ladder toward bank
    }
    private CombatSub combatSub = CombatSub.TALK_VANNAKA;
    // Micro-step flags (reset when the combat stage completes or restarts)
    private boolean combatInvTabClicked = false;
    // Build 69: dedicated inventory-tab flag for the bow/arrow equip — the
    // combat tab is still open from COMBAT_TAB_LESSON at that point, and the
    // shared combatInvTabClicked may already be true from the dagger step.
    private boolean combatBowInvTabClicked = false;
    private boolean combatTabClicked = false;
    private boolean combatStyleClicked = false;
    private boolean combatGateClicked = false;
    private int combatGateRetryTicks = 0;
    private boolean combatWasInCombat = false;
    private int combatNoRatTicks = 0;
    private int combatTalkTicks = 0;
    private int combatFinalTicks = 0;
    private boolean combatLadderTried = false;
    // Build 64: snapshotted walk target for walkStep (rats wander; re-targeting
    // every tick would reset pathfinding forever). Cleared on arrival,
    // unreachable, and every combat substate reset.
    private WorldPoint combatStepTarget = null;
    // Build 65: gate open verification — snapshot of the pen gate when clicked.
    // WAIT_GATE_OPEN polls until the gate object at this tile changes id or
    // vanishes (open gates are a different object), and only then walks through.
    private WorldPoint combatGateTile = null;
    private int combatGateId = -1;
    private int combatGateWaitTicks = 0;
    private int combatGateWaitCycles = 0;
    private boolean combatGateVerifiedOpen = false;
    // Build 68: inside-pen tracking + attack-miss recovery. The rat pen
    // fence lies to Euclidean distance: a rat can be 6-8 tiles away THROUGH
    // the fence, so "rat nearby" shortcuts jumped to KILL_RAT_MELEE and the
    // bot Attack-clicked forever ("I can't reach that!"). combatInsidePen is
    // only set once the bot actually crosses the gate; combatMeleeMisses
    // counts Attack clicks that never started combat — after 4 misses the
    // bot re-enters the pen properly instead of clicking forever.
    private boolean combatInsidePen = false;
    private boolean combatAttackPending = false;
    private int combatMeleeMisses = 0;
    // Build 71: dialog-completion tracking for TALK_VANNAKA. When the dialog
    // closes between ticks, advance instead of re-talking (the re-talk loop:
    // each talk re-opens the "Rat ranging" info dialog; dismissing it changes
    // nothing, so the state never advanced). Bow-acquisition attempts and
    // arrows-drop flag for the missing-shortbow recovery.
    private boolean combatTalkWasInDialog = false;
    private int combatBowAttempts = 0;
    private boolean combatArrowsDropped = false;

    private void resetCombatSubs() {
        combatSub = CombatSub.TALK_VANNAKA;
        combatInvTabClicked = false;
        combatBowInvTabClicked = false;
        combatTabClicked = false;
        combatStyleClicked = false;
        combatGateClicked = false;
        combatGateRetryTicks = 0;
        combatWasInCombat = false;
        combatNoRatTicks = 0;
        combatTalkTicks = 0;
        combatFinalTicks = 0;
        combatLadderTried = false;
        combatStepTarget = null;
        combatGateTile = null;
        combatGateId = -1;
        combatGateWaitTicks = 0;
        combatGateWaitCycles = 0;
        combatGateVerifiedOpen = false;
        combatInsidePen = false;
        combatAttackPending = false;
        combatMeleeMisses = 0;
        combatTalkWasInDialog = false;
        combatBowAttempts = 0;
        combatArrowsDropped = false;
        Rs2Walker.setTarget(null, "combat:reset");
    }

    /** Build 64: one non-blocking walk step per tick toward a snapshotted
     *  target. Returns the WalkerState. On UNREACHABLE (target walled behind
     *  a gate/door), clears the walker and runs {@code onWalled} — the caller
     *  should interact with the gate/door there, not keep walking. */
    private WalkerState combatWalkStep(WorldPoint target, int distance, Runnable onWalled) {
        if (target == null) return WalkerState.EXIT;
        boolean fresh = combatStepTarget == null;
        if (fresh) {
            combatStepTarget = target;
            diag("Stepping toward " + target.getX() + "," + target.getY());
        }
        WalkerState st = Rs2Walker.walkStep(combatStepTarget, distance);
        if (st == WalkerState.UNREACHABLE) {
            diag("Walk path walled (" + st + ") -> interacting with gate/door instead");
            combatStepTarget = null;
            Rs2Walker.setTarget(null, "combat:unreachable");
            if (onWalled != null) onWalled.run();
        } else if (st == WalkerState.ARRIVED) {
            combatStepTarget = null;
            Rs2Walker.setTarget(null, "combat:arrived");
        }
        return st;
    }

    private void doCombat() {
        Microbot.status = "Tutorial Island: Combat Instructor";
        if (npcReachable("Banker", 40)) {
            if (!combatDone) diag("Combat complete: banker nearby");
            combatDone = true;
            resetCombatSubs();
            return;
        }
        // Build 76: same mis-detection guard as detectStartStage. If a
        // restart (or cold NPC cache) lands us in COMBAT while standing at
        // the bank ladder, do NOT redo combat: the bank section implies
        // combat is done. Without this the bot re-kills a rat, climbs up,
        // and doBank's Brother Brace proximity check can complete the bank
        // stage before the booth is ever opened.
        if (nearBankLadder()) {
            if (!combatDone) diag("Combat complete: at the bank ladder");
            combatDone = true;
            resetCombatSubs();
            return;
        }
        // Resume fast-forward: if we already hold the ranged gear, the melee
        // kill is done — skip straight to equipping it. Build 70: use the
        // direct container read — the cached invContains("Shortbow") stayed
        // false for minutes on fresh sessions while the bow was in inventory.
        if (combatSub.ordinal() < CombatSub.EQUIP_BOW_ARROWS.ordinal()
                && invHasDirect("Shortbow")) {
            diag("Combat fast-forward: already have shortbow -> EQUIP_BOW_ARROWS");
            combatSub = CombatSub.EQUIP_BOW_ARROWS;
        }
        // Build 71: the ranging step is proven by the bronze arrows even when
        // the shortbow itself is missing (lost after the grant). Without this
        // the bot re-talks Vannaka forever instead of going to EQUIP_BOW_ARROWS,
        // which owns the missing-bow recovery.
        if (combatSub.ordinal() < CombatSub.EQUIP_BOW_ARROWS.ordinal()
                && invHasDirect("Bronze arrow")) {
            diag("Combat fast-forward: have bronze arrows (ranging step) -> EQUIP_BOW_ARROWS");
            combatSub = CombatSub.EQUIP_BOW_ARROWS;
        }
        // Resume fast-forward: if sword+shield are already worn, Vannaka's
        // equipment sequence is done and the tutorial is waiting on the
        // combat tab lesson ("You should check out the combat interface.").
        // Talking to Vannaka again just repeats that dialog forever —
        // TALK_VANNAKA can only click continue, never open the combat tab —
        // so skip straight to the combat tab lesson.
        // Build 71: direct equipment-container read (Rs2Equipment cache can be
        // stale on fresh sessions the same way the inventory cache was).
        if (combatSub.ordinal() < CombatSub.COMBAT_TAB_LESSON.ordinal()
                && equipmentHasDirect("Bronze sword")
                && equipmentHasDirect("Wooden shield")) {
            diag("Combat fast-forward: sword+shield worn -> COMBAT_TAB_LESSON");
            combatSub = CombatSub.COMBAT_TAB_LESSON;
        }
        diag("COMBAT TICK: " + combatSub);
        switch (combatSub) {
            case TALK_VANNAKA -> combatTalkVannaka();
            case OPEN_EQUIPMENT_TAB -> combatOpenEquipmentTab();
            case CLICK_STATS -> combatClickStats();
            case EQUIP_DAGGER -> combatEquipDagger();
            case TALK_AFTER_DAGGER -> combatTalkAfterDagger();
            case EQUIP_SWORD_SHIELD -> combatEquipSwordShield();
            case COMBAT_TAB_LESSON -> combatTabLesson();
            case ENTER_PEN -> combatEnterPen();
            case WAIT_GATE_OPEN -> combatWaitGateOpen();
            case KILL_RAT_MELEE -> combatKillRatMelee();
            case EXIT_PEN_TALK -> combatExitPenTalk();
            case EQUIP_BOW_ARROWS -> combatEquipBowArrows();
            case KILL_RAT_RANGED -> combatKillRatRanged();
            case FINAL_LADDER -> combatFinalLadder();
        }
    }

    /** TALK_VANNAKA: talk once per tick; spam dialogue one step per tick.
     *  Build 71: when the dialog closes between ticks (was open, now not),
     *  the dialog COMPLETED — advance instead of re-talking. Re-talking just
     *  re-opens the same info dialog forever (the TALK_VANNAKA loop). Route by
     *  observed state: bronze arrows prove the ranging step, otherwise this
     *  was the melee intro. */
    private void combatTalkVannaka() {
        boolean inDialog = safeIsInDialogue();
        if (inDialog) {
            combatTalkWasInDialog = true;
            dialogueTick();
            return;
        }
        if (combatTalkWasInDialog) {
            combatTalkWasInDialog = false;
            if (invHasDirect("Bronze arrow")) {
                diag("Vannaka dialogue completed (have bronze arrows = ranging step) -> EQUIP_BOW_ARROWS");
                combatSub = CombatSub.EQUIP_BOW_ARROWS;
            } else {
                diag("Vannaka dialogue completed -> OPEN_EQUIPMENT_TAB");
                combatSub = CombatSub.OPEN_EQUIPMENT_TAB;
            }
            return;
        }
        talkToOnce("Combat Instructor");
    }

    /** OPEN_EQUIPMENT_TAB: physical click on the Worn Equipment tab icon. */
    private void combatOpenEquipmentTab() {
        if (clickTabIcon(InterfaceTab.EQUIPMENT, true)) {
            combatSub = CombatSub.CLICK_STATS;
        }
        // else retry next tick
    }

    /** CLICK_STATS: click the Equipment Stats widget (exact 387:2). */
    private void combatClickStats() {
        if (clickEquipmentStatsIcon()) {
            // We handle the dagger ourselves below; don't let the generic
            // instruction follower double-handle it.
            statsButtonClicked = false;
            diag("Stats button clicked -> EQUIP_DAGGER");
            combatSub = CombatSub.EQUIP_DAGGER;
        }
        // else retry next tick
    }

    /** EQUIP_DAGGER: physical inventory-tab click, then wield; verified via Rs2Equipment. */
    private void combatEquipDagger() {
        if (Rs2Equipment.isWearing("Bronze dagger", false)) {
            diag("Bronze dagger verified equipped -> TALK_AFTER_DAGGER");
            combatInvTabClicked = false;
            combatSub = CombatSub.TALK_AFTER_DAGGER;
            return;
        }
        if (!combatInvTabClicked) {
            if (clickTabIcon(InterfaceTab.INVENTORY)) combatInvTabClicked = true;
            return;
        }
        if (!invContains("Bronze dagger")) {
            diag("No bronze dagger in inventory and not worn — waiting (did mining finish?)");
            return;
        }
        diag("Wielding bronze dagger");
        Rs2Inventory.wield("Bronze dagger");
        // next tick verifies via Rs2Equipment
    }

    /** TALK_AFTER_DAGGER: continue/talk until Vannaka acknowledges the dagger. */
    private void combatTalkAfterDagger() {
        if (safeIsInDialogue()) {
            if (dialogueTick()) {
                diag("Vannaka acknowledged dagger -> EQUIP_SWORD_SHIELD");
                combatSub = CombatSub.EQUIP_SWORD_SHIELD;
            }
            return;
        }
        // Vannaka should hand over sword+shield in this dialogue; if we
        // already hold them, skip ahead.
        if (invContains("Bronze sword") || Rs2Equipment.isWearing("Bronze sword", false)) {
            diag("Already have bronze sword -> EQUIP_SWORD_SHIELD");
            combatSub = CombatSub.EQUIP_SWORD_SHIELD;
            return;
        }
        talkToOnce("Combat Instructor");
    }

    /** EQUIP_SWORD_SHIELD: wield each, verified via Rs2Equipment (not inventory absence). */
    private void combatEquipSwordShield() {
        if (!invContains("Bronze sword") && !Rs2Equipment.isWearing("Bronze sword", false)) {
            diag("No bronze sword yet — back to talking");
            combatSub = CombatSub.TALK_AFTER_DAGGER;
            return;
        }
        // NOTE: Rs2Inventory.wield(varargs) only wields the FIRST match,
        // so wield each item on its own tick and verify separately.
        if (!Rs2Equipment.isWearing("Bronze sword", false)) {
            diag("Wielding bronze sword");
            Rs2Inventory.wield("Bronze sword");
            return;
        }
        if (!Rs2Equipment.isWearing("Wooden shield", false)) {
            if (!invContains("Wooden shield")) {
                diag("No wooden shield in inventory yet — waiting");
                return;
            }
            diag("Wielding wooden shield");
            Rs2Inventory.wield("Wooden shield");
            return;
        }
        diag("Sword+shield verified equipped -> COMBAT_TAB_LESSON");
        combatSub = CombatSub.COMBAT_TAB_LESSON;
    }

    /** COMBAT_TAB_LESSON: physically open the combat tab, select an attack style. */
    private void combatTabLesson() {
        if (!combatTabClicked) {
            if (clickTabIcon(InterfaceTab.COMBAT, true)) combatTabClicked = true;
            return;
        }
        if (!combatStyleClicked) {
            if (clickAttackStyle()) {
                combatStyleClicked = true;
                diag("Attack style clicked");
            } else {
                diag("Attack style widget not found yet, retrying");
            }
            return;
        }
        // Style selected — finish the lesson dialogue.
        if (safeIsInDialogue()) {
            dialogueTick();
            return;
        }
        diag("Combat tab lesson done -> ENTER_PEN");
        combatTabClicked = false;
        combatStyleClicked = false;
        combatSub = CombatSub.ENTER_PEN;
    }

    /** Click an attack-style widget (Chop/Slash/etc.) in the combat tab. */
    private boolean clickAttackStyle() {
        String[] styles = {"Chop", "Slash", "Lunge", "Block", "Accurate", "Aggressive",
                "Controlled", "Defensive", "Rapid", "Longrange"};
        for (String s : styles) {
            try {
                Widget w = Rs2Widget.findWidget(s);
                if (w == null) continue;
                // REBUILD: was blocking invoke() for bounds. Call directly.
                int[] coords = null;
                try {
                    if (!w.isHidden()) {
                        java.awt.Rectangle b = w.getBounds();
                        if (b != null && b.width > 0) {
                            coords = new int[]{(int) b.getCenterX(), (int) b.getCenterY()};
                        }
                    }
                } catch (Exception e) {
                    // fall through to null
                }
                if (coords != null) {
                    diag("Clicking attack style '" + s + "' at " + coords[0] + "," + coords[1]);
                    Microbot.getMouse().click(coords[0], coords[1]);
                    return true;
                }
            } catch (Exception ignored) {}
        }
        return false;
    }

    /** Build 65: find the pen gate and snapshot its tile + object id, so
     *  WAIT_GATE_OPEN can tell when the gate actually opens (open gates are a
     *  different object id, or the closed object vanishes). Hops to the client
     *  thread for the scene scan. Returns true if a gate was found. */
    private boolean snapshotPenGate() {
        // REBUILD: was blocking invoke(). findGateObjectInner now uses the
        // non-blocking cache, so call it directly.
        try {
            Rs2TileObjectModel found = findGateObjectInner(true);
            if (found == null) {
                diag("Gate snapshot: no gate found near player");
                return false;
            }
            combatGateTile = found.getWorldLocation();
            combatGateId = found.getId();
            diag("Gate snapshot: id=" + combatGateId + " at "
                + combatGateTile.getX() + "," + combatGateTile.getY());
            return true;
        } catch (Exception e) {
            diag("Gate snapshot failed: " + e);
            return false;
        }
    }

    /** Build 65: object id of any wall/game object on/around {@code tile}
     *  (3x3, to tolerate the gate sitting on a tile edge), or -1 if none.
     *  MUST run on the client thread. */
    private int wallOrGameObjectIdNear(WorldPoint tile) {
        try {
            net.runelite.api.Client client = Microbot.getClient();
            net.runelite.api.Scene scene = client.getScene();
            net.runelite.api.Tile[][][] tiles = scene.getTiles();
            int z = client.getPlane();
            net.runelite.api.coords.LocalPoint lp =
                net.runelite.api.coords.LocalPoint.fromWorld(client.getTopLevelWorldView(), tile);
            if (lp == null) return -1;
            int cx = lp.getSceneX();
            int cy = lp.getSceneY();
            for (int x = Math.max(0, cx - 1); x < Math.min(tiles[z].length, cx + 2); x++) {
                for (int y = Math.max(0, cy - 1); y < Math.min(tiles[z][x].length, cy + 2); y++) {
                    net.runelite.api.Tile t = tiles[z][x][y];
                    if (t == null) continue;
                    net.runelite.api.WallObject w = t.getWallObject();
                    if (w != null) return w.getId();
                    for (net.runelite.api.GameObject o : t.getGameObjects()) {
                        if (o != null) return o.getId();
                    }
                }
            }
        } catch (Exception e) {
            diag("Gate tile scan failed: " + e);
        }
        return -1;
    }

    /** Build 65: true while the snapshotted closed-gate object is still sitting
     *  on its tile. False once the gate opens (id changes or object gone) —
     *  or when we never got a snapshot (caller treats that as "not verified"). */
    private boolean isGateStillClosed() {
        if (combatGateTile == null || combatGateId < 0) return false;
        // REBUILD: was blocking invoke() scene scan. Now queries the
        // event-driven cache for an object at the snapshot tile.
        int idAt = -2;
        try {
            Rs2TileObjectModel atTile = Microbot.getRs2TileObjectCache().query()
                    .within(combatGateTile, 2)
                    .nearest(combatGateTile, 2);
            idAt = (atTile != null) ? atTile.getId() : -1;
        } catch (Exception e) {
            diag("Gate state check failed: " + e);
            return true; // unknown -> keep waiting, don't walk into a closed gate
        }
        if (idAt == -2) return true; // query failed -> keep waiting
        boolean closed = idAt == combatGateId;
        if (!closed) {
            diag("Gate state changed: snapshot id=" + combatGateId + " now id=" + idAt + " -> open");
        }
        return closed;
    }

    /** ENTER_PEN: open the pen gate, then walk in toward a rat.
     *  Build 65: after clicking "Open" we go to WAIT_GATE_OPEN and only walk
     *  through once the gate object actually changes (open gates are a
     *  different object). Build 64 walked immediately and WebWalk's own door
     *  transport claimed the still-closed gate, yielding forever
     *  (door-traversal-pending-yield -> route-stagnation-exhausted). */
    private void combatEnterPen() {
        Rs2NpcModel rat = findNpcTimeout("Giant rat");
        // Build 68: distance through the pen fence LIES — a rat 8 tiles away
        // on the other side of the fence is not "within reach". Only skip the
        // gate procedure when the bot has actually crossed inside this run.
        if (rat != null && combatInsidePen
                && Rs2Player.getWorldLocation().distanceTo(rat.getWorldLocation()) <= 8) {
            diag("Rat within reach -> KILL_RAT_MELEE");
            combatStepTarget = null;
            Rs2Walker.setTarget(null, "combat:enter-pen:rat-in-reach");
            combatGateClicked = false;
            combatGateRetryTicks = 0;
            combatGateVerifiedOpen = false;
            combatGateWaitTicks = 0;
            combatGateWaitCycles = 0;
            combatSub = CombatSub.KILL_RAT_MELEE;
            return;
        }
        if (combatGateVerifiedOpen) {
            // Gate confirmed open — cross the edge with a DIRECT canvas click
            // on a tile just inside the pen. Never route to the rat through
            // the door segment: the walker sees both sides as reachable tiles
            // and either routes around the fence or parks in door-traversal
            // yield (movement.md s10). One direct step, then hunt the rat.
            WorldPoint player = Rs2Player.getWorldLocation();
            if (player != null && combatGateTile != null
                    && player.distanceTo(combatGateTile) > 10) {
                // Not near the gate yet — walk to it (path doesn't cross it).
                combatWalkStep(combatGateTile, 3, () -> {
                    diag("Gate tile unreachable -> re-verifying gate");
                    combatGateVerifiedOpen = false;
                    combatGateClicked = false;
                    combatGateRetryTicks = 0;
                    combatGateTile = null;
                    combatGateId = -1;
                });
                return;
            }
            WorldPoint inside = penInsideTile(rat);
            if (inside != null && player != null && player.distanceTo(inside) > 2) {
                combatGateWaitTicks++;
                if (combatGateWaitTicks > 20) {
                    // Crossing stalled — gate may have swung shut again.
                    diag("Gate crossing stalled — re-verifying gate state");
                    combatGateWaitTicks = 0;
                    combatGateVerifiedOpen = false;
                    combatGateClicked = false;
                    return;
                }
                if (!Rs2Player.isMoving()) {
                    diag("Gate open — canvas step inside to "
                        + inside.getX() + "," + inside.getY());
                    Rs2Walker.walkFastCanvas(inside);
                }
                return; // wait for the step to land
            }
            // Crossed the gate (or already inside) — hunt the rat.
            diag("Inside the pen -> KILL_RAT_MELEE");
            combatInsidePen = true; // Build 68: only true once actually crossed
            combatGateVerifiedOpen = false;
            combatGateWaitTicks = 0;
            combatSub = CombatSub.KILL_RAT_MELEE;
            return;
        }
        // Gate not yet verified open: click it once, snapshot, then wait for
        // the open state in WAIT_GATE_OPEN.
        if (!combatGateClicked || combatGateRetryTicks > 10) {
            if (clickDoorDirect("Open")) {
                combatGateClicked = true;
                combatGateRetryTicks = 0;
                combatGateWaitTicks = 0;
                if (snapshotPenGate()) {
                    diag("Pen gate clicked -> WAIT_GATE_OPEN");
                    combatSub = CombatSub.WAIT_GATE_OPEN;
                } else {
                    diag("Pen gate clicked but snapshot failed — retrying click next tick");
                }
            } else {
                combatGateRetryTicks++;
            }
            return;
        }
        combatGateRetryTicks++;
    }

    /** Build 65: tile one step past the pen gate toward the rat (the pen
     *  interior side). Used for the direct canvas crossing — never routed
     *  through the door segment (movement.md s10). */
    private WorldPoint penInsideTile(Rs2NpcModel rat) {
        if (combatGateTile == null || rat == null || rat.getWorldLocation() == null) return null;
        WorldPoint rp = rat.getWorldLocation();
        int dx = Integer.signum(rp.getX() - combatGateTile.getX());
        int dy = Integer.signum(rp.getY() - combatGateTile.getY());
        if (dx == 0 && dy == 0) return null;
        return new WorldPoint(combatGateTile.getX() + dx,
            combatGateTile.getY() + dy, combatGateTile.getPlane());
    }

    /** WAIT_GATE_OPEN (Build 65): poll the gate tile until the closed-gate
     *  object changes/vanishes = gate open. Only then walk through, so the
     *  walker never routes through a closed door. */
    private void combatWaitGateOpen() {
        Rs2NpcModel rat = findNpcTimeout("Giant rat");
        // Build 68: also require combatInsidePen — a rat within 8 tiles on
        // the other side of the fence is not reachable.
        if (rat != null && combatInsidePen
                && Rs2Player.getWorldLocation().distanceTo(rat.getWorldLocation()) <= 8) {
            // Somehow inside already (gate was open all along).
            diag("Rat within reach while waiting -> KILL_RAT_MELEE");
            combatGateVerifiedOpen = true;
            combatSub = CombatSub.KILL_RAT_MELEE;
            return;
        }
        if (!isGateStillClosed()) {
            diag("Pen gate verified open -> walking through");
            combatGateVerifiedOpen = true;
            combatGateWaitTicks = 0;
            combatGateWaitCycles = 0;
            combatSub = CombatSub.ENTER_PEN;
            return;
        }
        combatGateWaitTicks++;
        if (combatGateWaitTicks > 12) {
            combatGateWaitTicks = 0;
            combatGateWaitCycles++;
            if (combatGateWaitCycles >= 4) {
                // Gate never visibly opened after several clicks — best effort:
                // try walking anyway; if still walled, ENTER_PEN re-verifies.
                diag("Gate never opened after " + combatGateWaitCycles + " clicks — trying walk anyway");
                combatGateVerifiedOpen = true;
                combatGateWaitCycles = 0;
                combatSub = CombatSub.ENTER_PEN;
                return;
            }
            diag("Gate still closed after wait (cycle " + combatGateWaitCycles + ") — re-clicking Open");
            if (clickDoorDirect("Open")) {
                snapshotPenGate();
            }
        }
        // else: keep waiting, one tick at a time
    }

    /** KILL_RAT_MELEE: attack one rat; detect the kill via combat-state
     *  transitions — one tick at a time, no blocking loop. */
    private void combatKillRatMelee() {
        // Resume safety: bow already received means melee is done.
        // Build 70: direct read (cached check went stale on fresh sessions).
        if (invHasDirect("Shortbow")) {
            diag("Have shortbow -> melee done -> EXIT_PEN_TALK");
            combatStepTarget = null;
            Rs2Walker.setTarget(null, "combat:melee-done");
            combatWasInCombat = false;
            combatNoRatTicks = 0;
            combatSub = CombatSub.EXIT_PEN_TALK;
            return;
        }
        if (Rs2Player.isInCombat()) {
            combatWasInCombat = true;
            combatNoRatTicks = 0;
            combatMeleeMisses = 0;   // Build 68: attack worked, reset misses
            combatAttackPending = false;
            return; // wait this tick
        }
        if (combatWasInCombat) {
            // Was fighting, now not — the rat died.
            combatWasInCombat = false;
            combatNoRatTicks = 0;
            combatMeleeMisses = 0;   // Build 68
            combatAttackPending = false;
            diag("Melee rat killed -> EXIT_PEN_TALK");
            combatStepTarget = null;
            Rs2Walker.setTarget(null, "combat:melee-killed");
            combatSub = CombatSub.EXIT_PEN_TALK;
            return;
        }
        // Build 68: the previous tick's Attack click produced no combat —
        // the rat is visible but unreachable (through the pen fence). Count
        // misses; after 4, stop clicking and re-enter the pen properly.
        if (combatAttackPending) {
            combatAttackPending = false;
            combatMeleeMisses++;
            diag("Attack click produced no combat (miss " + combatMeleeMisses + ")");
        }
        if (combatMeleeMisses >= 4) {
            diag("Attack x4 never started combat (rat unreachable through fence?) -> re-entering pen");
            combatMeleeMisses = 0;
            combatInsidePen = false;
            combatGateVerifiedOpen = false;
            combatGateClicked = false;
            combatGateRetryTicks = 0;
            combatStepTarget = null;
            Rs2Walker.setTarget(null, "combat:reenter-pen");
            combatSub = CombatSub.ENTER_PEN;
            return;
        }
        Rs2NpcModel rat = findNpcTimeout("Giant rat");
        if (rat == null) {
            combatNoRatTicks++;
            diag("No giant rat nearby (" + combatNoRatTicks + ")");
            if (combatNoRatTicks > 40) {
                // No rats and never fought — maybe the pen didn't open or the
                // rat is already dead from an earlier attempt. Go back and retry.
                diag("No rats for a while, re-trying pen entry");
                combatNoRatTicks = 0;
                combatSub = CombatSub.ENTER_PEN;
            }
            return;
        }
        combatNoRatTicks = 0;
        if (Rs2Player.getWorldLocation().distanceTo(rat.getWorldLocation()) > 6) {
            // Build 64: non-blocking walkStep. UNREACHABLE means the pen gate
            // closed behind us — go back and re-enter instead of walking
            // through the wall.
            combatWalkStep(rat.getWorldLocation(), 6, () -> {
                diag("Rat unreachable (gate closed?) -> re-entering pen");
                combatStepTarget = null;
                combatNoRatTicks = 0;
                combatSub = CombatSub.ENTER_PEN;
            });
            return;
        }
        diag("Attacking giant rat (melee)");
        try {
            rat.click("Attack");
            combatAttackPending = true; // Build 68: verify combat starts next tick
        } catch (Exception e) {
            diag("Attack click failed: " + e);
        }
    }

    /** EXIT_PEN_TALK: get out of the pen, talk to Vannaka until he hands over
     *  the bow and arrows. */
    private void combatExitPenTalk() {
        // Build 70: direct container read — the cached invContains stayed
        // false for minutes on fresh sessions while the bow was in inventory.
        if (invHasDirect("Shortbow") && invHasDirect("Bronze arrow")) {
            diag("Have bow+arrows -> EQUIP_BOW_ARROWS");
            combatTalkTicks = 0;
            combatSub = CombatSub.EQUIP_BOW_ARROWS;
            return;
        }
        if (safeIsInDialogue()) {
            combatTalkTicks = 0;
            if (dialogueTick()) {
                diag("Vannaka dialogue done");
                // loop back to check for the bow; if not received, talk again
            }
            return;
        }
        combatTalkTicks++;
        if (combatTalkTicks % 8 == 0) {
            // Dialogue won't start — maybe the pen gate closed behind us.
            diag("Talk not starting, nudging pen gate open");
            clickDoorDirect("Open");
        }
        talkToOnce("Combat Instructor");
    }

    /** EQUIP_BOW_ARROWS: wield each, verified via Rs2Equipment.
     *  Build 69: the combat tab is still open from COMBAT_TAB_LESSON here —
     *  without a physical inventory-tab click first, Rs2Inventory.wield
     *  can't see the items and fails silently every tick (the ~4min stall
     *  with the mouse parked over Vannaka).
     *  Build 71: missing-shortbow recovery. Observed live: the player can hold
     *  the 50 bronze arrows with NO shortbow anywhere (lost after Vannaka's
     *  grant — likely inventory-full at grant time, bow dropped/despawned).
     *  Re-talking Vannaka does not re-grant while the arrows are held, so:
     *  3 deliberate talks first (in case the grant just needs a clean dialog),
     *  then DROP the bronze arrows to trigger a fresh bow+arrows grant, then
     *  keep talking at a slow cadence with a clear STUCK log for Julien. */
    private void combatEquipBowArrows() {
        // Build 71: direct reads — treat the bow as available when in the
        // inventory OR already worn (a worn bow must not bounce us to Vannaka).
        boolean haveBowInv = invHasDirect("Shortbow");
        boolean haveBowWorn = equipmentHasDirect("Shortbow");
        boolean haveArrowsInv = invHasDirect("Bronze arrow");
        boolean haveArrowsWorn = equipmentHasDirect("Bronze arrow");

        if (!haveBowInv && !haveBowWorn) {
            combatBowAttempts++;
            if (combatBowAttempts <= 3) {
                diag("No shortbow anywhere (attempt " + combatBowAttempts + "/3) — talking to Vannaka for a bow. Inventory: " + inventoryNamesDirect());
                if (safeIsInDialogue()) {
                    dialogueTick();
                } else {
                    talkToOnce("Combat Instructor");
                }
                return;
            }
            if (!combatArrowsDropped && haveArrowsInv) {
                diag("Vannaka gave no bow in 3 talks — DROPPING bronze arrows to trigger a fresh bow+arrows grant");
                try {
                    Rs2Inventory.drop("Bronze arrow");
                } catch (Exception e) {
                    diag("Arrow drop failed: " + e);
                }
                combatArrowsDropped = true;
                return;
            }
            // Slow retry cadence so the log stays readable and Julien can
            // intervene manually (talk to Vannaka himself / check the account).
            if (combatBowAttempts % 20 == 1) {
                diag("STUCK_NO_BOW: " + combatBowAttempts + " Vannaka talks, still no shortbow. Inventory: " + inventoryNamesDirect());
            }
            if (safeIsInDialogue()) {
                dialogueTick();
            } else if (combatBowAttempts % 10 == 0) {
                talkToOnce("Combat Instructor");
            }
            return;
        }

        // Bow present — clear the recovery state.
        if (combatBowAttempts > 0) {
            diag("Shortbow acquired after " + combatBowAttempts + " Vannaka talks");
        }
        combatBowAttempts = 0;
        combatArrowsDropped = false;

        if (!haveArrowsInv && !haveArrowsWorn) {
            diag("Have shortbow but no arrows — back to Vannaka");
            combatBowInvTabClicked = false;
            combatSub = CombatSub.EXIT_PEN_TALK;
            return;
        }
        if (!combatBowInvTabClicked) {
            if (clickTabIcon(InterfaceTab.INVENTORY)) combatBowInvTabClicked = true;
            return;
        }
        // Build 71: verify worn state via the direct equipment read (the
        // Rs2Equipment cache can be stale on fresh sessions).
        if (!haveBowWorn) {
            diag("Wielding shortbow");
            Rs2Inventory.wield("Shortbow");
            return;
        }
        if (!haveArrowsWorn) {
            diag("Wielding bronze arrows");
            Rs2Inventory.wield("Bronze arrow");
            return;
        }
        diag("Bow+arrows verified equipped -> KILL_RAT_RANGED");
        combatBowInvTabClicked = false;
        combatSub = CombatSub.KILL_RAT_RANGED;
    }

    /** KILL_RAT_RANGED: kill one rat with ranged from OUTSIDE the pen.
     *  The pen cannot be re-entered, so never walk toward the rat here —
     *  only attack rats already in range; they wander near the fence. */
    private void combatKillRatRanged() {
        if (Rs2Player.isInCombat()) {
            combatWasInCombat = true;
            combatNoRatTicks = 0;
            return; // wait this tick
        }
        if (combatWasInCombat) {
            combatWasInCombat = false;
            combatNoRatTicks = 0;
            diag("Ranged rat killed -> FINAL_LADDER");
            combatStepTarget = null;
            Rs2Walker.setTarget(null, "combat:ranged-killed");
            combatSub = CombatSub.FINAL_LADDER;
            return;
        }
        Rs2NpcModel rat = findNpcTimeout("Giant rat");
        if (rat == null
                || Rs2Player.getWorldLocation().distanceTo(rat.getWorldLocation()) > 8) {
            combatNoRatTicks++;
            if (combatNoRatTicks % 10 == 0) {
                diag("Waiting for a rat near the fence (" + combatNoRatTicks + ")");
            }
            if (combatNoRatTicks > 120) {
                // Waited ~72s with no rat in range — try talking to Vannaka;
                // the kill may already be done from an earlier attempt.
                diag("No rat in range for a while, checking with Vannaka");
                combatNoRatTicks = 0;
                combatSub = CombatSub.FINAL_LADDER;
            }
            return;
        }
        combatNoRatTicks = 0;
        diag("Attacking giant rat (ranged)");
        try {
            rat.click("Attack");
        } catch (Exception e) {
            diag("Ranged attack click failed: " + e);
        }
    }

    /** FINAL_LADDER: finish Vannaka's dialogue, then head through the gate
     *  and up the ladder toward the bank. Banker nearby = combat done. */
    private void combatFinalLadder() {
        if (npcReachable("Banker", 45)) {
            diag("Banker nearby -> combatDone");
            combatDone = true;
            resetCombatSubs();
            return;
        }
        if (safeIsInDialogue()) {
            dialogueTick();
            return;
        }
        combatFinalTicks++;
        // Alternate: open gate, climb ladder, nudge toward the banker.
        // One action per tick; the banker check above is the ground truth.
        // Build 64: non-blocking walkStep; UNREACHABLE (ladder not climbed yet)
        // just falls through to the next alternation tick.
        if (combatFinalTicks % 3 == 1) {
            clickDoorDirect("Open");
        } else if (combatFinalTicks % 3 == 2) {
            if (clickDoorDirect("Climb-up")) combatLadderTried = true;
        } else {
            Rs2NpcModel banker = findNpcTimeout("Banker");
            if (banker != null) {
                combatWalkStep(banker.getWorldLocation(), 10, null);
            }
        }
    }

    // Tick-based flags for the bank stage (Build 63): one action per tick,
    // progress re-derived from observed state each tick.
    // Build 75: Julien confirmed the bank is UP the ladder (Build 74 had it
    // backwards — the tutorial prompt says "climb up the ladder to the
    // North" and the minimap destination marker is up by the ladder).
    // "Went up" is verified by actual movement after the Climb-up click,
    // not by flat NPC distance. Keeps Build 74's fixes: clickDoorDirect uses
    // sync invoke (its return value was always false), booth clicked with
    // "Use" (the tutorial booth doesn't respond to the generic opener).
    private boolean bankWentUp = false;
    private boolean bankOpened = false;
    private boolean bankClosed = false;
    private boolean bankPollBoothDone = false; // Build 87: poll booth step, VERIFIED by the game's instruction dialog
    private int pollRetryTicks = 0; // Build 87: ticks spent on the poll booth step
    private int boothClickCount = 0; // Build 121: circuit breaker -- booth clicks without the bank opening
    private boolean pollBurstFired = false; // Build 87: burst once per bank run
    private boolean pollClickedOnce = false; // Build 93: only scan widgets after first click
    private boolean pollDialogSeen = false; // Build 100: dialog observed open after booth click (title often unreadable)
    private WorldPoint cachedPollBoothPos = null; // Build 99: cache booth world pos; scene scans via invoke() block 90s+
    // Build 104: tile-object NAME CACHE. Rs2TileObjectModel.getName() does a
    // blocking ClientThread.invoke() (~450ms) on EVERY call. Build 103
    // narrowed queries to within(radius) first, but ~29 objects within 15
    // tiles in the bank x 450ms still = ~13s hang on EVERY booth find
    // (seen live 17:02:38/17:02:57: "booth find took 13221ms (HANG!)").
    // Object names are fixed per object id, so resolve each id ONCE per
    // session (persisted to disk, so restarts stay fast too) and reuse.
    private final java.util.Map<Integer, String> objNameCache =
            new java.util.concurrent.ConcurrentHashMap<>();
    private static final String OBJNAME_CACHE_PATH =
            System.getProperty("user.home") + "/.runelite/tutorial-island-objnames.properties";
    private volatile long objNameCacheLastSave = 0;
    // REBUILD: event-driven world model (non-blocking). Registered on the
    // RuneLite event bus in run(); unregistered in shutdown().
    private final WorldModel worldModel = new WorldModel();
    // Build 108: ACCOUNT GUIDE STEP (official tutorial order, proven live
    // 2026-09-27 18:08: Account Guide -> bank booth -> poll booth -> bank
    // exit — Build 108 had it after the poll booth, which looped the booth
    // click forever). The bank stage skipped him; the bank exit is game-gated
    // on his talk ("You need to talk to the Account Guide before you are
    // allowed to proceed through this door."), which looped the bot at the
    // exit (seen live 2026-09-27 17:44).
    // Tracked like the Build 100/106 dialog-transition steps. Phase:
    // 0 = first talk, 1 = open the account tab (physical click),
    // 2 = second talk.
    private boolean accountGuideDone = false;
    private boolean accountGuidePending = false; // gate recovery: service him, not the door
    private int accountGuidePhase = 0;
    private boolean accountGuideTalkInitiated = false;
    private boolean accountGuideDialogSeen = false;
    private int accountGuideTicks = 0;
    private int gateUnclearRepeats = 0; // unreadable-dialog repeats at a door
    private int bankUpStep = 0; // 0 = open bank door to exit, 1 = heading out to Brother Brace
    private WorldPoint bankClimbFrom = null; // player tile when Climb-up started
    private int bankUpTicks = 0; // ticks spent trying to get upstairs
    private int bankExitTicks = 0; // Build 86: ticks spent trying to exit the bank
    private int lastBankExitY = -1; // Build 96: player's Y last tick (detect movement through door)
    private int bankExitStuckTicks = 0; // Build 96: ticks without southward progress
    // Build 134 (Alex 2026-09-27): explicit door-1/door-2 substates for the 540 exit.
    // Each door is an independent checkpoint: observe tile/side before, issue ONE
    // action, then verify crossing via fresh tile observation. A click return or
    // walk call is NOT a crossing.
    private int bankExitDoor = 0; // 0 = no door active, 1 = door-1 in progress, 2 = door-2 in progress
    private WorldPoint bankDoorTileBefore = null; // player tile before door action
    private String bankDoorTargetDesc = null; // "name/id/action@tile" of current door target
    private int bankDoorStuckTicks = 0; // ticks with unchanged (varp,tile,dialogue,target/action)
    private int bankDoorLastVarp = -1;
    private WorldPoint bankDoorLastTile = null;
    private String bankDoorLastDialogue = null;
    private String bankDoorLastTarget = null;
    // Build 136 (Alex 2026-09-27): PENDING DOOR STATE.
    // Hold one pending target (ID+tile) and before-tile across the action.
    // Next fresh tick verifies against that SAME door; only clears on actual
    // side crossing. Prevents alternating between Door/9722 and Door/9721.
    private int pendingDoorId = -1; // -1 = no pending door
    private WorldPoint pendingDoorTile = null;
    private WorldPoint pendingTileBefore = null;
    private int pendingDoorTicks = 0; // ticks since pending door was set
    // Build 144 (Alex): walk stall detection. If Rs2Walker.walkTo() is issued
    // for the same target 5+ ticks without player movement, the walker's
    // pathfinding is blocked (isTileReachable true but no path). Fall back
    // to direct door click; game's own pathfinder handles it.
    private int walkStallTicks = 0;
    private WorldPoint lastWalkTarget = null;
    private WorldPoint lastPlayerPosForWalk = null;
    // Build 144 (Alex): track closest approach to door during WALKTHROUGH.
    // A walk-around-the-fence route could pass far-side check without ever
    // going through the doorway. Require minDist <= 1 to prove doorway transit.
    private int walkthroughMinDoorDist = Integer.MAX_VALUE;
    // Build 137 (Alex): PENDING PHASES. 0=none, 1=APPROACH (walking to adjacent),
    // 2=CLICKED (click issued, observing), 3=VERIFY (checking crossing/replanning).
    // Build 141: 4=WALKTHROUGH (door is open, walking to far side).
    private int pendingPhase = 0;
    // Build 141: Far-side target for walkthrough (south of the open door).
    private WorldPoint walkthroughTarget = null;
    // Build 138 (Alex): Click-time tile (not selection-time) for crossing verification.
    private WorldPoint pendingClickTile = null;
    // Build 138: VERIFY retry latch (one bounded retry, not every tick).
    private boolean verifyRetryIssued = false;
    // Build 155: doors that failed the WALKTHROUGH get parked here so the
    // handler reports BLOCKED instead of re-clicking them forever. Cleared
    // only on varp change / far movement (new situation, new chance).
    private java.util.Set<Integer> blockedDoorIds = new java.util.HashSet<>();
    // Build 155: latch set by findSouthBlockingDoor when every found candidate
    // is blocked; handleDoorRouteTick reports BLOCKED and holds.
    private boolean doorRouteBlocked = false;
    // Build 155: WALKTHROUGH fresh-tile movement watchdog (per-tick reads).
    private WorldPoint walkthroughLastPos = null;
    private int walkthroughStuckTicks = 0;
    // Build 156: bounded retry counter for WALKTHROUGH failures per door.
    // The 'door disappeared' gate is a FALSE POSITIVE when the player stands
    // on the door's tile (object query can't see it under the player), so the
    // door may still be closed. Retry Open+walk up to 3x before parking.
    private int walkthroughAttempts = 0;
    private int walkthroughDoorId = -1;
    // Build 139 (Alex): Bounded tried-set of failed door IDs.
    // Resets when all candidates are exhausted or on meaningful state change.
    private java.util.Set<Integer> triedDoorIds = new java.util.HashSet<>();
    // Build 161 (Alex): directed door completion -- doors successfully crossed
    // in the route direction. Prevents re-selecting 9722 after crossing east.
    private java.util.Set<Integer> completedDoorIds = new java.util.HashSet<>();
    // Build 165 (Alex): south-exit tracking. Once we've confirmed crossing a door
    // moving SOUTH (Y decreased), we're outside heading toward Brace. Don't select
    // doors north of current position -- prevents 1516 regression after 1511 exit.
    private boolean bankExitedSouth = false;
    private int triedSetVarp = -1;
    private WorldPoint triedSetTile = null;
    // Build 137: No-progress watchdog for the shared handler (PRAYER path).
    private int routeStuckTicks = 0;
    private int routeLastVarp = -1;
    private WorldPoint routeLastTile = null;
    private String routeLastDialogue = null;
    private String routeLastTarget = null;
    // Build 80: bank interface must be STABLY open (3 consecutive ticks)
    // before we mark it opened. A single isOpen()=true can flicker (interface
    // flashes then closes), which caused "up then straight back down".
    private int bankOpenStability = 0;
    // Build 82: burst recording runs on a BACKGROUND thread (not the game
    // tick), because the tick can block for minutes (e.g. inside
    // Rs2Bank.openBank()), which made bursts come out 4 minutes apart
    // instead of rapid-fire. Now: N screenshots ~600ms apart on a daemon
    // thread, independent of tick health.
    private volatile boolean burstRunning = false;

    /** Build 82: start a burst of N screenshots on a background thread. */
    private void startBurst(int n, String reason) {
        if (burstRunning) return; // don't stack bursts
        burstRunning = true;
        diag("Build 82: burst recording started (" + n + " shots): " + reason);
        Thread t = new Thread(() -> {
            try {
                for (int i = n; i > 0; i--) {
                    saveScreenshot("burst-" + reason + "-" + i);
                    try { Thread.sleep(600); } catch (InterruptedException ie) { break; }
                }
                diag("Build 82: burst recording finished: " + reason);
            } finally {
                burstRunning = false;
            }
        });
        t.setDaemon(true);
        t.setName("tutorial-burst");
        t.start();
    }

    private void resetBankFlags() {
        bankWentUp = false;
        bankOpened = false;
        bankClosed = false;
        bankPollBoothDone = false;
        pollRetryTicks = 0;
        pollBurstFired = false;
        pollClickedOnce = false;
        pollDialogSeen = false;
        bankUpStep = 0;
        bankClimbFrom = null;
        bankUpTicks = 0;
        bankExitTicks = 0;
        bankOpenStability = 0;
        // Build 108: reset the per-attempt Account Guide state, but NOT
        // accountGuideDone — that is cross-stage knowledge (the tutorial only
        // needs him once per account).
        accountGuidePending = false;
        accountGuidePhase = 0;
        accountGuideTalkInitiated = false;
        accountGuideDialogSeen = false;
        accountGuideTicks = 0;
        gateUnclearRepeats = 0;
    }

    // Build 108: tutorial door-gate detection. The game gates tutorial doors
    // on missing prerequisites ("You need to talk to the X before you are
    // allowed to proceed through this door."). Returns:
    //   null — no dialog open;
    //   ""   — dialog open but not a readable gate (blank text/other dialog);
    //   otherwise the lowercased prerequisite ("account guide", ...).
    private String gateDialogPrerequisite() {
        if (!safeIsInDialogue()) return null;
        String title = "", body = "";
        try { title = safeGetQuestion(); } catch (Exception ignored) {}
        try { body = safeGetDialogueText(); } catch (Exception ignored) {}
        if (title == null) title = "";
        if (body == null) body = "";
        body = getDialogBodyCached(title, body);
        String text = (title + " " + body).toLowerCase();
        if (!text.contains("before you are allowed to proceed through")) return "";
        int i = text.indexOf("you need to talk to the ");
        if (i >= 0) {
            int j = text.indexOf(" before you are allowed", i);
            if (j > i) {
                return text.substring(i + "you need to talk to the ".length(), j).trim();
            }
        }
        return "";
    }

    /** Build 108: is the player inside/around the bank building? */
    private boolean playerNearBank() {
        try {
            WorldPoint p = Rs2Player.getWorldLocation();
            return p != null && p.getX() >= 3115 && p.getX() <= 3135
                    && p.getY() >= 3118 && p.getY() <= 3132;
        } catch (Exception e) {
            return false;
        }
    }

    // Build 108: the missing tutorial step — talk to the Account Guide in the
    // bank building (official order: Account Guide talk -> open the Account
    // Management tab -> talk again -> bank booth -> poll booth -> bank exit).
    // Build 110: runs FIRST in doBank — the booth is game-gated on his talk.
    // Called from doBank and from the prayer endgame's gate recovery. Owns
    // its dialogs — callers must call it BEFORE any generic dialog guard
    // (same reason as Build 100's poll tracking).
    private void doAccountGuideStep() {
        Microbot.status = "Tutorial Island: Account Guide";
        if (accountGuideDone) return;
        if (!accountGuideTalkInitiated && safeIsInDialogue()) {
            // Stale dialog (e.g. the door gate) before we've started talking —
            // clear it before seeking him.
            dialogueTick();
            return;
        }
        if (accountGuidePhase == 1) {
            // Open the Account Management tab — the flashing prompt requires
            // a PHYSICAL click. The instruction box is handled via
            // dialogueTick's Build 108 mapping when it's up.
            if (safeIsInDialogue()) {
                dialogueTick();
                return;
            }
            boolean tabOpen = false;
            try { tabOpen = clickTabIcon(InterfaceTab.ACC_MAN, true); }
            catch (Exception e) { diag("Build 108: account tab click failed: " + e); }
            if (tabOpen) {
                diag("Build 108: account tab open — talking to Account Guide again");
                accountGuidePhase = 2;
                accountGuideTalkInitiated = false;
                accountGuideDialogSeen = false;
                accountGuideTicks = 0;
            } else {
                if (accountGuideTicks++ % 20 == 0) {
                    diag("Build 108: opening account management tab (tick " + accountGuideTicks + ")");
                }
                if (accountGuideTicks > 150) {
                    // Fail-safe: the tab click may not be strictly required.
                    diag("Build 108: account tab not opening after 150 ticks — proceeding to second talk");
                    accountGuidePhase = 2;
                    accountGuideTalkInitiated = false;
                    accountGuideDialogSeen = false;
                    accountGuideTicks = 0;
                }
            }
            return;
        }
        // Phases 0 and 2: talk, then wait for the dialog to open and close.
        // (chooseDialogueOption already answers "hear about X again?" with
        // "No thanks", so a re-talk can't loop.)
        if (accountGuideTalkInitiated) {
            if (safeIsInDialogue()) {
                String gp = gateDialogPrerequisite();
                if (gp != null && !gp.isEmpty()) {
                    // A door-gate dialog, not his talk — dismiss, don't count
                    // it toward completion (Build 106 misattribution lesson).
                    diag("Build 108: gate dialog ('" + gp + "') while seeking Account Guide — dismissing");
                    dialogueTick();
                    return;
                }
                accountGuideDialogSeen = true;
                dialogueTick();
                return;
            }
            if (accountGuideDialogSeen) {
                accountGuideTalkInitiated = false;
                accountGuideDialogSeen = false;
                accountGuideTicks = 0;
                if (accountGuidePhase == 0) {
                    accountGuidePhase = 1;
                    diag("Build 108: first Account Guide talk done — opening account tab");
                } else {
                    accountGuideDone = true;
                    accountGuidePending = false;
                    accountGuidePhase = 0;
                    diag("Build 108: Account Guide done (both talks + account tab)");
                }
                return;
            }
            // Initiated but no dialog yet — the talk click may still be
            // walking into range; fall through and retry the talk.
        }
        if (!npcReachable("Account Guide", 25)) {
            WorldPoint p = null;
            try { p = Rs2Player.getWorldLocation(); } catch (Exception ignored) {}
            if (p != null) {
                try {
                    Rs2Walker.walkTo(new WorldPoint(3122, 3126, p.getPlane()));
                } catch (Exception e) {
                    diag("Build 108: walk into bank failed: " + e);
                }
            }
            if (accountGuideTicks++ % 10 == 0) {
                diag("Build 108: Account Guide not in range, walking into bank (tick " + accountGuideTicks + ")");
            }
            if (accountGuideTicks > 150) {
                // Fail-safe: never hard-stall the tutorial on one NPC.
                // Build 124 (Alex): NEVER mark timeout as completion. Check the
                // game's varp: if >=533 the Account Guide step is truly done,
                // otherwise this is a real failure needing recovery, not a skip.
                Integer v = readVarp281();
                if (v != null && v >= 533) {
                    diag("Build 124: Account Guide not reached after 150 ticks, but varp=" + v + " (>=533) confirms step done in game -- marking done");
                    accountGuideDone = true;
                    accountGuidePending = false;
                    accountGuidePhase = 0;
                } else {
                    diag("Build 124: Account Guide UNREACHABLE after 150 ticks (varp=" + v + ") -- NOT marking done, trying door recovery");
                    accountGuideTicks = 0; // reset counter, try door recovery below
                    // Fall through to door recovery: try opening nearest door
                }
            }
            return;
        }
        accountGuideTicks = 0;
        if (!accountGuideTalkInitiated) {
            diag("Build 108: talking to the Account Guide (round " + (accountGuidePhase + 1) + "/2)");
        }
        accountGuideTalkInitiated = true;
        talkToOnce("Account Guide");
    }

    // Build 108: door-gate recovery for stage endgames. Returns true when a
    // gate situation was handled — the caller MUST return early and NEVER
    // re-click the door on a gate tick. A readable gate naming the Account
    // Guide arms the pending step; anything else is dismissed and held.
    private boolean handleDoorGate() {
        String gp = gateDialogPrerequisite();
        if (gp == null) {
            gateUnclearRepeats = 0;
            return false; // no dialog — door click may proceed
        }
        if (gp.isEmpty()) {
            // Dialog open but not a readable gate (blank text or other
            // dialog). Dismiss; if it keeps reappearing at the bank, assume
            // the Account Guide gate with unreadable text.
            dialogueTick();
            if (++gateUnclearRepeats >= 4) {
                gateUnclearRepeats = 0;
                if (playerNearBank() && !accountGuideDone) {
                    diag("Build 108: unreadable door dialog x4 near bank — assuming Account Guide gate");
                    accountGuidePending = true;
                } else {
                    diag("Build 108: unreadable door dialog x4 — holding");
                }
            }
            return true;
        }
        // Readable gate — dismiss it, never hammer the door.
        dialogueTick();
        gateUnclearRepeats = 0;
        if (gp.contains("account guide") && !accountGuideDone) {
            diag("Build 108: door gated on Account Guide — servicing missing step");
            accountGuidePending = true;
        } else {
            diag("Build 108: door gated on '" + gp + "' — holding, not retrying door");
        }
        return true;
    }

    /** Build 82: keep the screenshots folder clean — delete PNGs older than
     *  90 minutes after each new save. Julien asked for automatic cleanup. */
    private void cleanupOldScreenshots(File shotsDir) {
        try {
            long cutoff = System.currentTimeMillis() - 90L * 60L * 1000L;
            File[] files = shotsDir.listFiles((d, name) -> name.endsWith(".png"));
            if (files == null) return;
            int deleted = 0;
            for (File f : files) {
                if (f.lastModified() < cutoff && f.delete()) deleted++;
            }
            if (deleted > 0) diag("Build 82: cleaned up " + deleted + " old screenshots");
        } catch (Exception e) {
            // cleanup is best-effort; never break the screenshot flow
        }
    }

    private void doBank() {
        Microbot.status = "Tutorial Island: Bank";
        // Build 123: VARP-AWARE BANK. Live 2026-09-27 19:50 (Build 122):
        // varp=540 (bank "exit" step) but bot redid Account Guide from scratch,
        // getting door-blocked clicking him (5s timeouts). If the game's varp
        // says the bank is done (>=540), don't redo it -- mark done and let
        // PRAYER's walk handle the exit door. Julien: "door never been fixed"
        // -- the door isn't the problem, redoing completed steps is.
        // Build 128: CORRECTED THRESHOLD (Alex's wiki table).
        // 540=Exit Account Guide's room (a STEP TO DO, not skip!);
        // 550=Talk to Brother Brace (PRAYER starts). Old >=540 was wrong.
        Integer bv = readVarp281();
        if (bv != null && bv >= 550) {
            diag("Build 128: varp 281 = " + bv + " (>=550, Brother Brace step) -- bank truly complete, skipping to PRAYER");
            bankDone = true;
            // Build 126: RESET PRAYER FLAGS. Live 2026-09-27 20:03 (Build 123/124):
            // prayerTalked1=true persisted from the 19:28 run, so doPrayer()
            // skipped the "walk south to church" logic and went straight for
            // the prayer tab -- while the character was still outdoors.
            // Julien: "you have to go through 2 doors in the bank where you
            // did one of them" -- the bot must WALK (with door handling), not
            // tab-click, until it reaches Brother Brace.
            resetPrayerFlags();
            return;
        }
        // Build 131: EXPLICIT 540 SUBSTATE. Alex 2026-09-27 20:20: varp=540 is
        // EXIT_ACCOUNT_GUIDE_ROOM -- a distinct step, not "bank generic".
        // Live: "Click here to continue" dialogue blocks, doors are OPEN
        // (not closed-path failure). The bot must: (1) dismiss the dialogue
        // FIRST (log widget text/bounds), (2) then cross the door, (3) verify
        // varp 540->550. Do NOT attempt door while dialogue is up.
        if (bv != null && bv == 540) {
            diag("Build 133 SUBSTATE: VARP 540 = EXIT_ACCOUNT_GUIDE_ROOM. Varp proves Account Guide (530/531/532), bank booth (510), and POLL BOOTH (520) are DONE -- skipping all redo. Going straight to exit.");
            // Alex 2026-09-27 20:27: Build 132 set accountGuideDone/bankOpened/
            // bankClosed but MISSED bankPollBoothDone -- the poll-booth block
            // (guarded by if (!bankPollBoothDone)) still ran at 20:27:05.
            // Varp 540 means 520 (poll booth) is complete. Set ALL done flags.
            accountGuideDone = true;
            bankOpened = true;
            bankClosed = true;
            bankPollBoothDone = true;
            // Fall through to the exit logic below. The Account Guide block
            // (if (!accountGuideDone)), booth block, and poll-booth block
            // (if (!bankPollBoothDone)) are now all skipped.
        }
        // Build 83: REMOVED the Brother Brace proximity shortcut that marked
        // the bank done without ever opening it. Per Julien's principle, the
        // bot must OBSERVE the bank open+close (bankOpened/bankClosed flags),
        // not guess from a nearby NPC. The stage detector now prioritizes
        // BANK over PRAYER, so this shortcut is unnecessary and harmful.
        diag("BANK TICK: up=" + bankWentUp + " opened=" + bankOpened
                + " closed=" + bankClosed + " upStep=" + bankUpStep);
        // Build 100: STATE-BASED poll-step completion (Julien's principle:
        // re-derive from observed state, never guess from text).
        // pollBoothStillWanted() can only verify via the readable dialog title
        // ("Moving on"), but tutorial dialog text is often EMPTY, so it
        // returns null forever and the bot re-clicks the booth every 6 ticks
        // while dialogueTick opens/closes the same dialog (seen live
        // 2026-09-27: retry ticks 4->10->16->22 with the "Moving on" dialog
        // cycling). Instead: once the booth was clicked AND a dialog was
        // observed open afterwards AND that dialog is now closed (dialogueTick
        // dismissed it), the click registered with the game -- the step is
        // done. Fail closed: never completes without having SEEN the dialog
        // (a click that did nothing keeps retrying, as before). This MUST run
        // before the dialog guard below, which short-circuits doBank while a
        // dialog is open -- otherwise the "seen" half could never be recorded.
        if (pollClickedOnce && !bankPollBoothDone) {
            if (safeIsInDialogue()) {
                pollDialogSeen = true;
            } else if (pollDialogSeen) {
                bankPollBoothDone = true;
                try { Rs2Keyboard.keyPress(KeyEvent.VK_ESCAPE); } catch (Exception ignored) {}
                diag("Build 100: poll booth step VERIFIED complete (dialog opened then dismissed after click; title unreadable so used dialog transition, not text)");
                return;
            }
        }
        // Build 110: ACCOUNT GUIDE STEP — FIRST, before any booth click
        // (same dialog-ownership reason as Build 100: the step tracks its own
        // dialogs; the guard would eat the "seen" half). Build 108 placed
        // this step after the poll booth ("poll booth -> Account Guide ->
        // bank exit"), but the live game proves the Account Guide comes
        // FIRST: every booth click just re-pops his "Account (Management)"
        // instruction dialog ("The guide here will tell you all about your
        // account. Just click on him to hear what he's got to say.") while
        // the bank never opens (opened=false for 15+ min, seen live
        // 2026-09-27 17:49->18:08 on Builds 107/109). Official order:
        // Account Guide -> bank booth -> poll booth -> bank exit.
        if (!accountGuideDone) {
            doAccountGuideStep();
            return;
        }
        // Build 109: "I can't reach that!" recovery — MUST run before the
        // dialog guard (same reason as Build 100). The physical booth click
        // fires from wherever the player stands; if the game answers "I
        // can't reach that!", the guard would just dismiss it and the click
        // would loop forever with the bank never opening (seen live
        // 2026-09-27 17:59: click -> "I can't reach that!" -> continue,
        // opened=false for minutes). Instead: dismiss, walk adjacent to the
        // booth, retry the click next tick.
        if (!bankOpened && cantReachDialogOpen()) {
            diag("Build 109: 'I can't reach that!' at bank booth — walking adjacent before retrying");
            dialogueTick();
            walkAdjacentToBooth();
            return;
        }
        // Build 72: dismiss blocking dialogs (e.g. the client "worlds" error
        // popup, tutorial instruction boxes) before touching the bank.
        if (safeIsInDialogue()) {
            dialogueTick();
            return;
        }
        if (!bankWentUp) {
            // Build 80: verify "upstairs" by COORDINATE, not by movement +
            // banker proximity. The combat cave is at Y~9526, the bank at
            // Y~3126 (observed live: ladder 9727 at (3111,9526), ladder 9728
            // at (3111,3126)). The old check allowed a double-climb: after a
            // successful Climb-up, the next tick clicked "Climb-up" AGAIN on
            // the bank-side ladder, sending the player straight back down to
            // the cave — while bankWentUp=true locked in. The bot then spent
            // 16 min trying to open a booth that wasn't there (it was in the
            // cave, not the bank). Now: if we're not in the underground
            // region (Y < 9000) we're upstairs — never touch the ladder.
            // Only click Climb-up while actually in the cave (Y > 9000).
            WorldPoint now = Rs2Player.getWorldLocation();
            if (now != null && now.getY() < 9000) {
                bankWentUp = true;
                bankUpTicks = 0;
                bankClimbFrom = null;
                diag("Build 80: upstairs by coordinate (y=" + now.getY()
                        + ") — not touching the ladder");
                return;
            }
            bankUpTicks++;
            boolean clicked = clickDoorDirect("Climb-up", 4);
            WorldPoint after = Rs2Player.getWorldLocation();
            if (after != null && after.getY() < 9000) {
                bankWentUp = true;
                bankUpTicks = 0;
                bankClimbFrom = null;
                diag("Build 80: climbed up (y=" + after.getY() + ")");
                startBurst(10, "climbed-up-ladder");
            } else if (bankUpTicks % 30 == 1) {
                diag("Build 80: climbing up... tick=" + bankUpTicks
                        + " clicked=" + clicked);
            }
            return;
        }
        if (!bankOpened) {
            // Build 90: must be INSIDE the bank to click the booth. Live
            // 2026-09-27: the bot climbed the ladder but was OUTSIDE the
            // bank (south, y<=3121) trying to click the booth at (3121,3124)
            // through the wall -- clicks landed at the wrong spot forever.
            // If outside, open the south door and walk north inside first.
            WorldPoint bop = Rs2Player.getWorldLocation();
            if (bop != null && bop.getY() <= 3121) {
                if (clickDoorDirect("Open", 4)) {
                    diag("Build 94: outside bank, opened door to enter");
                }
                Rs2Walker.walkTo(new WorldPoint(3122, 3126, bop.getPlane()));
                diag("Build 94: walking inside bank (at " + bop + ")");
                return;
            }
            // Build 80: require the bank to be STABLY open (3 consecutive
            // ticks) before marking it opened. A single isOpen()=true can
            // flicker, causing "up then straight back down".
            if (Rs2Bank.isOpen()) {
                bankOpenStability++;
                if (bankOpenStability >= 3) {
                    bankOpened = true;
                    bankOpenStability = 0;
                    diag("Bank is open (stable 3 ticks)");
                    startBurst(8, "bank-opened");
                } else {
                    diag("Bank open stability: " + bankOpenStability + "/3");
                }
                return;
            }
            bankOpenStability = 0;
            // One open attempt per tick; next tick verifies isOpen().
            // Build 74: the Tutorial Island booth uses "Use", not "Bank", so
            // the generic Rs2Bank.openBank() never finds it — fall back to
            // clicking the booth directly with "Use".
            boolean opened = false;
            try {
                opened = Rs2Bank.openBank();
            } catch (Exception e) {
                diag("Rs2Bank.openBank threw: " + e);
            }
            if (!opened) {
                clickBoothDirect("Use");
            }
            return;
        }
        if (!bankClosed) {
            try {
                Rs2Bank.closeBank();
            } catch (Exception ignored) {}
            if (!Rs2Bank.isOpen()) {
                bankClosed = true;
                diag("Bank closed");
            }
            return;
        }
        // Build 87/89: POLL BOOTH step, VERIFIED by the game's own instruction
        // dialog. The tutorial says "click on the indicated poll booth to
        // continue" AFTER the bank is closed. This step is done ONLY when the
        // game's instruction no longer asks for the poll booth -- NEVER on
        // click()'s return value. (Live 2026-09-27: Rs2TileObjectModel.click
        // returns true unconditionally; Build 85's "clicked" poll booth left
        // the right-click menu open on "Use Poll booth" and the poll
        // instruction was still up 62s later -- the "Use" never fired.)
        // Build 89: the check matches "poll booth" (the object), NOT "poll" --
        // the post-click 'Moving on' instruction says 'Polls are run
        // periodically...', so matching "poll" could never complete
        // (seen 15:29:50: retry ticks 4->10 with the 'Polls are run
        // periodically' box still up).
        // While the game still wants the poll booth: close any polls
        // interface that opened (Escape is harmless when nothing is open),
        // then re-click the booth. Fail closed: blank/unreadable instruction
        // text keeps retrying rather than guessing completion.
        if (!bankPollBoothDone) {
            pollRetryTicks++;
            // Build 93: SPEED. pollBoothStillWanted() does a full widget-tree
            // scan (~24s/tick observed live 2026-09-27: 95s for 4 ticks).
            // Only scan on verification ticks, not every tick. The dialog
            // only changes AFTER we click, so scanning before the first
            // click is pure waste.
            Boolean wanted = null;
            if (pollRetryTicks % 6 == 1 || pollClickedOnce) {
                wanted = pollBoothStillWanted();
            }
            if (wanted != null && !wanted) {
                bankPollBoothDone = true;
                try { Rs2Keyboard.keyPress(KeyEvent.VK_ESCAPE); } catch (Exception ignored) {}
                diag("Build 89: poll booth step VERIFIED complete (instruction no longer mentions the poll booth)");
                return;
            }
            if (pollRetryTicks % 6 == 1) {
                try { Rs2Keyboard.keyPress(KeyEvent.VK_ESCAPE); } catch (Exception ignored) {}
            } else if (pollRetryTicks % 6 == 4) {
                if (clickPollBoothDirect()) {
                    pollClickedOnce = true; // Build 93: start verifying after first click
                    diag("Build 87: poll booth click attempt (retry tick " + pollRetryTicks + ")");
                    if (!pollBurstFired) {
                        pollBurstFired = true;
                        startBurst(8, "poll-booth-clicked");
                    }
                }
            }
            if (pollRetryTicks % 30 == 0) {
                diag("Build 87: still waiting on poll booth step (tick " + pollRetryTicks + ")");
            }
            return;
        }
        // Build 86: EXIT VERIFICATION. The bank stage must not complete until
        // the player is OBSERVED outside the bank (Julien's principle:
        // coordinate-verified, never guessed from NPC proximity). Live
        // 2026-09-27: Build 84's `npcReachable("Brother Brace", 40)` fired
        // while the player was still INSIDE the bank (the church at Y~3106 is
        // well within 40 tiles of the bank at Y~3126), so the stage jumped to
        // PRAYER and stranded the bot looping "Brother Brace not nearby".
        // The bank's south door is at y~3125; outside (south) = y <= 3121.
        // Re-derived from observed position every tick: if inside, keep the
        // door open and step south through it; only complete once outside.
        // Build 134 (Alex 2026-09-27): EXPLICIT DOOR-1 / DOOR-2 SUBSTATES.
        // The 540 exit requires TWO independent door crossings:
        //   Door-1: Exit the Account Guide's room (the small room upstairs)
        //   Door-2: Exit the bank building (south door at y~3125)
        // Each is a verified transition: observe tile/side before, identify the
        // specific door (name/id/action/tile), check reachability, issue ONE
        // action, then WAIT for fresh tile/door/dialogue observation before
        // advancing. A click return or walk call is NOT a crossing.
        WorldPoint bpp = Rs2Player.getWorldLocation();
        boolean outsideBank = bpp != null && bpp.getY() <= 3121;
        if (!outsideBank) {
            bankExitTicks++;
            bankUpStep = 1;

            // No-progress watchdog: (varp, tile, dialogue, target/action).
            // If unchanged for 5 ticks, stop retrying and log a snapshot.
            Integer bvNow = getVarp281();
            String dlgNow = getDialogueTextSafe();
            String targetNow = bankDoorTargetDesc != null ? bankDoorTargetDesc : "none";
            boolean unchanged = (bvNow != null && bvNow == bankDoorLastVarp)
                    && tilesEqual(bpp, bankDoorLastTile)
                    && strEqual(dlgNow, bankDoorLastDialogue)
                    && strEqual(targetNow, bankDoorLastTarget);
            if (unchanged) {
                bankDoorStuckTicks++;
            } else {
                bankDoorStuckTicks = 0;
                bankDoorLastVarp = bvNow != null ? bvNow : -1;
                bankDoorLastTile = bpp;
                bankDoorLastDialogue = dlgNow;
                bankDoorLastTarget = targetNow;
            }
            if (bankDoorStuckTicks >= 5) {
                // Stop retrying. Log compact scene/object/widget snapshot.
                diag("Build 134 DOOR STUCK: (varp=" + bvNow + ",tile=" + bpp
                        + ",dialogue=" + truncate(dlgNow, 60) + ",target=" + targetNow
                        + ") unchanged for 5 ticks. Door=" + bankExitDoor
                        + ". Replan failed: no alternative door found in scene scan.");
                logCompactSceneSnapshot();
                bankDoorStuckTicks = 0; // Reset to avoid log spam, but do NOT retry the same action
                return;
            }

            // Determine which door we're working on.
            // Door-1: player is in the Account Guide's room (north part, y > 3127 approx)
            // Door-2: player is in the main bank area (y 3122-3127), heading to south door
            if (bankExitDoor == 0) {
                // Initialize: determine starting door from Y position
                if (bpp != null && bpp.getY() > 3127) {
                    bankExitDoor = 1;
                    bankDoorTileBefore = bpp;
                    diag("Build 134 DOOR-1 START: player at " + bpp + " (in Account Guide room). Finding door-1 target.");
                } else {
                    bankExitDoor = 2;
                    bankDoorTileBefore = bpp;
                    diag("Build 134 DOOR-2 START: player at " + bpp + " (in bank main area). Finding door-2 target.");
                }
            }

            // Find the specific door for the current substate.
            // Door-1: the door exiting the Account Guide's room
            // Door-2: the bank's south door (y~3125)
            Rs2TileObjectModel doorObj = findExitDoorForSubstate(bankExitDoor, bpp);
            if (doorObj == null) {
                diag("Build 134 DOOR-" + bankExitDoor + ": no door object found in scene. Tile=" + bpp);
                return;
            }

            String doorName = getObjectNameSafe(doorObj);
            int doorId = getObjectIdSafe(doorObj);
            WorldPoint doorTile = getObjectTileSafe(doorObj);
            String doorAction = "Open"; // Tutorial doors use "Open"
            bankDoorTargetDesc = doorName + "/" + doorId + "/" + doorAction + "@" + doorTile;
            boolean reachable = isDoorReachable(doorObj, bpp);

            diag("Build 134 DOOR-" + bankExitDoor + ": target=" + bankDoorTargetDesc
                    + ", playerBefore=" + bankDoorTileBefore
                    + ", playerNow=" + bpp
                    + ", reachable=" + reachable);

            if (!reachable) {
                diag("Build 134 DOOR-" + bankExitDoor + ": door not reachable. Cannot issue action.");
                return;
            }

            // Issue ONE action, then wait for fresh observation next tick.
            // Do NOT mark as done here. Verification happens on the next tick
            // by comparing the new tile against bankDoorTileBefore.
            boolean clicked = clickDoorDirect(doorAction, 4);
            if (clicked) {
                diag("Build 134 DOOR-" + bankExitDoor + ": issued '" + doorAction
                        + "' on " + bankDoorTargetDesc
                        + ". Waiting for crossing verification (tile change).");
                // Do NOT advance bankExitDoor here. The next tick will check
                // if the player tile changed (crossing verified) or if we're
                // stuck (watchdog above).
            }

            // Also step toward the door's far side to encourage pathing through.
            // This is a single walk action, not a crossing claim.
            if (bpp != null && doorTile != null) {
                // Walk to a tile just beyond the door (south for door-2, appropriate for door-1)
                WorldPoint beyond = new WorldPoint(doorTile.getX(), doorTile.getY() - 2, doorTile.getPlane());
                Rs2Walker.walkTo(beyond);
            }

            // Check for crossing: if player Y decreased significantly from bankDoorTileBefore,
            // or if we've moved to the next area, advance the door substate.
            if (bpp != null && bankDoorTileBefore != null) {
                int yBefore = bankDoorTileBefore.getY();
                int yNow = bpp.getY();
                // Door-1 crossing: moved south out of the Account Guide room (y dropped below 3128)
                // Door-2 crossing: moved south through the bank door (y <= 3121)
                if (bankExitDoor == 1 && yNow <= 3127 && yBefore > 3127) {
                    diag("Build 134 DOOR-1 CROSSED: " + bankDoorTileBefore + " -> " + bpp
                            + ". Advancing to DOOR-2.");
                    bankExitDoor = 2;
                    bankDoorTileBefore = bpp;
                    bankDoorStuckTicks = 0;
                } else if (bankExitDoor == 2 && yNow <= 3121 && yBefore > 3121) {
                    diag("Build 134 DOOR-2 CROSSED: " + bankDoorTileBefore + " -> " + bpp
                            + ". Exit complete. Waiting for varp 540->550.");
                    bankExitDoor = 0; // Reset for next time
                    bankDoorTileBefore = null;
                    bankDoorStuckTicks = 0;
                }
            }

            if (bankExitTicks % 10 == 0) {
                diag("Build 134: exiting bank... at " + bpp
                        + " (door=" + bankExitDoor + ", need y<=3121), tick " + bankExitTicks);
            }
            return;
        }
        // Reset exit tracking once outside.
        lastBankExitY = -1;
        bankExitStuckTicks = 0;
        // Build 134 (Alex 2026-09-27): BANK→PRAYER requires varp 281 >= 550.
        // REMOVED: `bankOpened && bankClosed && npcReachable("Brother Brace", 40)`
        // set bankDone=true without checking varp. This was the Build 83 bug:
        // Brace at Y~3106 is within 40 tiles of the bank at Y~3126, so the
        // stage jumped to PRAYER while the player was still inside. Proximity
        // is NOT completion. Only varp 281 >= 550 completes the bank stage.
        Integer bvExit = getVarp281();
        if (bvExit != null && bvExit >= 550) {
            if (!bankDone) diag("Build 134: Bank complete: varp 281 = " + bvExit + " (>=550). Proximity to Brother Brace is not completion.");
            bankDone = true;
            resetBankFlags();
            return;
        }
        // Outside but varp < 550: keep heading south to the church.
        // Do NOT mark bankDone. Varp is the completion gate.
        // Outside but Brace not yet in range: keep heading south to the church.
        WorldPoint p = Rs2Player.getWorldLocation();
        if (p != null) {
            Rs2Walker.walkTo(new WorldPoint(p.getX(), p.getY() - 6, p.getPlane()));
        }
    }

    // Tick-based flags for the prayer stage (Build 63).
    // Build 172 (Alex): varp-change tracking for cheap verification.
    private int lastPrayerVarpLogged = -1;
    private int lastMagicVarpLogged = -1;
    private boolean prayerTalked1 = false;
    private boolean prayerTabClicked = false;
    private boolean prayerTalked2 = false;
    // Build 158 (Alex): missing steps -- Friends tab (varp 580) and third
    // Brace talk (varp 600).
    private boolean prayerFriendsClicked = false;
    private boolean prayerTalked3 = false;
    private boolean prayerDialogSeen3 = false;
    private int prayerStallTicks = 0; // Build 87: ticks spent walking to the church
    private WorldPoint prayerLastPos = null; // Build 105: stall detection for bank door
    private int prayerNoMoveTicks = 0;
    private int prayerTalkAttempts = 0; // Build 119: talk attempts without dialog (door-blocked detection)
    private String lastLoggedTabStripDiag = ""; // Build 124: dedupe for the throttled tab-strip tree diagnostic
    // Build 106: dialog-transition completion flags (same proven pattern as
    // Build 100's poll-booth fix). See doPrayer comment for why.
    private boolean prayerDialogSeen1 = false;
    private boolean prayerDialogSeen2 = false;

    private void resetPrayerFlags() {
        prayerTalked1 = false;
        prayerTabClicked = false;
        prayerTalked2 = false;
        prayerFriendsClicked = false;
        prayerTalked3 = false;
        prayerStallTicks = 0;
        prayerLastPos = null;
        prayerNoMoveTicks = 0;
        prayerTalkAttempts = 0;
        prayerDialogSeen1 = false;
        prayerDialogSeen2 = false;
        prayerDialogSeen3 = false;
    }

    private void doPrayer() {
        Microbot.status = "Tutorial Island: Brother Brace";
        // Build 159 (Alex): VARP-BASED completion, not NPC proximity.
        // CRITICAL: varp281 = NEXT REQUIRED action, not completed one.
        // varp=560 means DO the Prayer tab now, not that it's done.
        // So: step done when varp has moved PAST it.
        // 550=Brace1, 560=Prayer tab, 570=Brace2, 580=Friends, 600=Brace3,
        // 610=exit chapel (PRAYER done), 620+=MAGIC.
        Integer pv = getVarp281();
        if (pv != null && pv >= 620) {
            if (!prayerDone) diag("Build 159: PRAYER complete (varp=" + pv + " >= 620)");
            prayerDone = true;
            resetPrayerFlags();
            return;
        }
        // Mark steps done only when varp has advanced PAST them.
        if (pv != null) {
            if (pv >= 610 && !prayerTalked3) {
                prayerTalked3 = true;
                diag("Build 159: varp=" + pv + " >= 610, Brace talk3 done");
            }
            if (pv >= 600 && !prayerFriendsClicked) {
                prayerFriendsClicked = true;
                diag("Build 159: varp=" + pv + " >= 600, Friends tab done");
            }
            if (pv >= 580 && !prayerTalked2) {
                prayerTalked2 = true;
                diag("Build 159: varp=" + pv + " >= 580, Brace talk2 done");
            }
            if (pv >= 570 && !prayerTabClicked) {
                prayerTabClicked = true;
                diag("Build 159: varp=" + pv + " >= 570, Prayer tab done");
            }
            if (pv >= 560 && !prayerTalked1) {
                prayerTalked1 = true;
                diag("Build 159: varp=" + pv + " >= 560, Brace talk1 done");
            }
            // Build 172 (Alex): varp281 is AUTHORITATIVE every tick. The
            // dialogue-transition pattern (dialog-seen-then-closed => true)
            // fired on talk1's lingering dialogue close at 23:34:03, setting
            // prayerTalked2=true WITHOUT a fresh Talk-to while the game
            // still showed "Talk with Brother Brace". Local flags that outrun
            // game state are RESET here -- not only set true above. Dialogue
            // closing or click dispatch can NEVER complete a step without
            // its next varp. This prevents the same premature-flag mistake
            // at each later conversation.
            if (pv < 560 && prayerTalked1) {
                prayerTalked1 = false; prayerDialogSeen1 = false;
                diag("Build 172: varp=" + pv + " <560, RESETTING premature prayerTalked1");
            }
            if (pv < 570 && prayerTabClicked) {
                prayerTabClicked = false;
                diag("Build 172: varp=" + pv + " <570, RESETTING premature prayerTabClicked");
            }
            if (pv < 580 && prayerTalked2) {
                prayerTalked2 = false; prayerDialogSeen2 = false;
                diag("Build 172: varp=" + pv + " <580, RESETTING premature prayerTalked2");
            }
            if (pv < 600 && prayerFriendsClicked) {
                prayerFriendsClicked = false;
                diag("Build 172: varp=" + pv + " <600, RESETTING premature prayerFriendsClicked");
            }
            if (pv < 610 && prayerTalked3) {
                prayerTalked3 = false; prayerDialogSeen3 = false;
                diag("Build 172: varp=" + pv + " <610, RESETTING premature prayerTalked3");
            }
            // Build 172: log varp changes for cheap verification.
            if (pv != lastPrayerVarpLogged) {
                diag("Build 172: varp281 PRAYER " + lastPrayerVarpLogged + " -> " + pv);
                lastPrayerVarpLogged = pv;
                // Build 172 (Alex): clear stale dialogueSeen latches on varp
                // transition so lingering "dialog seen" can't re-trigger the
                // (now-disabled) completion branches.
                prayerDialogSeen1 = false; prayerDialogSeen2 = false; prayerDialogSeen3 = false;
            }
        }
        // Build 87: POSITION GUARD. Only talk to Brother Brace when actually
        // near the church. Live 2026-09-27: the bot looped "Talking to
        // 'Brother Brace'" for 60+s with zero progress while physically
        // INSIDE the bank -- the NPC cache holds Brace ~20 tiles away, so
        // findNpcTimeout succeeds but the clicks hit an off-screen NPC.
        // Build 167 (Alex): BRACE GOAL DRIVES NAVIGATION. No Y heuristics.
        // The stable observed goal drives navigation; doors are handled ONLY
        // when blocking that goal's planned route edge -- never any nearby
        // door. Goal resolution: fresh Brace snapshot first; landmark
        // fallback (3126,3106) when Brace is out of cache range (166 logged
        // "blind-south (no brace snapshot)" -- Brace ~17 tiles away).
        // Historical reference (NOT proof): bank->prayer via 3133,3123 then
        // 3134,3117 to 3130,3108; chapel entrance 3129,3107. Corroborates
        // EAST around the fence before south. Switch to fresh Brace snapshot
        // once seen.
        if (!prayerTalked1) {
            try {
                // Build 166: use WorldModel snapshot (non-blocking), not
                // Rs2Player.getWorldLocation() (ClientThread.invoke stall).
                WorldPoint pp = worldModel.playerPos;
                if (pp == null) {
                    if (prayerStallTicks++ % 20 == 0) {
                        diag("Build 167: waiting for player snapshot");
                    }
                    return;
                }
                // Resolve goal: Brace snapshot, else landmark fallback.
                WorldModel.NpcSnapshot braceGoal = findNpcSnapshot("Brother Brace");
                WorldPoint goalTile;
                String goalWhy;
                if (braceGoal != null && braceGoal.tile != null) {
                    goalTile = braceGoal.tile;
                    goalWhy = "brace-snapshot@" + goalTile;
                } else {
                    goalTile = new WorldPoint(3126, 3106, pp.getPlane());
                    goalWhy = "landmark-fallback@" + goalTile + " (no brace snapshot)";
                }
                int distToGoal = Math.abs(pp.getX() - goalTile.getX())
                               + Math.abs(pp.getY() - goalTile.getY());
                if (distToGoal <= 2) {
                    // At goal -- fall through to talk logic below.
                } else {
                    // Build 168 (Alex): OWNERSHIP. If a door is pending
                    // (pendingDoorId != -1), the door handler owns movement
                    // this tick -- run it and return WITHOUT touching the
                    // main-goal walkStep. walkStep returns MOVING immediately
                    // on target change, so calling walkStep(goalTile) then
                    // walkStep(doorAdj) in the same tick (or alternating
                    // ticks) rebuilds the route forever without stepping.
                    // Never switch main goal and door subgoal in one tick.
                    if (pendingDoorId != -1) {
                        if (prayerStallTicks++ % 10 == 0) {
                            diag("Build 168: door pending (id=" + pendingDoorId
                                + "), door handler owns movement -- main goal held");
                        }
                        handleDoorRouteTick(pp, "PRAYER_TRAVEL", goalTile);
                        return;
                    }
                    // No door pending: establish/observe the stable goal
                    // route. Ensure the walker is routing toward our goal
                    // (sets the active route that findDoorOnPathTo inspects
                    // for blocked edges).
                    try {
                        WalkerState pws = Rs2Walker.walkStep(goalTile, 0);
                        if (prayerStallTicks % 20 == 0) {
                            diag("Build 168: prayer travel walkStep -> " + pws
                                + " goal=" + goalWhy + " (dist=" + distToGoal + ")");
                        }
                    } catch (Exception e) {
                        diag("Build 168: prayer travel walkStep failed: " + e.getClass().getSimpleName());
                    }
                    // Select the blocker ONLY from the active route's forward
                    // edges. Returns false when no door blocks -- route
                    // proceeds unimpeded. After verified crossing/abort the
                    // pending state clears and we resume the main goal here.
                    if (handleDoorRouteTick(pp, "PRAYER_TRAVEL", goalTile)) {
                        return; // Door handling consumed the tick
                    }
                    if (prayerStallTicks++ % 10 == 0) {
                        diag("Build 168: en route, goal=" + goalWhy
                            + " (dist=" + distToGoal + ")");
                    }
                    return;
                }
            } catch (Exception e) {
                diag("Build 167: prayer travel failed: " + e);
            }
        }
        diag("PRAYER TICK: talked1=" + prayerTalked1 + " tab=" + prayerTabClicked
                + " talked2=" + prayerTalked2);
        // Build 106: DIALOG-TRANSITION completion (same proven pattern as Build
        // 100's poll-booth fix). The old code did `if (dialogueTick())
        // prayerTalked1 = true`, but dialogueTick() only returns true when NO
        // dialogue is open at the end of the call (final `return
        // !safeIsInDialogue()`; every click branch returns false immediately
        // after clicking) -- and it is only ever called while a dialogue IS
        // open. So the completion flag could NEVER set. Live 2026-09-27
        // 17:23-17:33: the bot talked to Brother Brace and clicked through his
        // dialogue for 10+ minutes while talked1 stayed false (infinite
        // Build 172 (Alex): VARP-AUTHORITATIVE. The Build 106 dialogue-
        // transition (dialog-seen-then-closed => talked1=true) is DISABLED
        // when varp is valid. It fired on stale dialogue closes, setting
        // flags without game proof. Now: if dialogue open, drain it;
        // otherwise dispatch TalkBrace directly. ONLY varp >= 560 proves
        // talk1. Clicks/dialogue-close record attempts, never completion.
        if (!prayerTalked1) {
            if (safeIsInDialogue()) {
                dialogueTick();
                return;
            }
            // Build 119: CHAPEL DOOR FIX. Live 2026-09-27 19:28-19:32: bot
            // reached the church (y<=3115) but Brother Brace is behind the
            // chapel door -- talkToOnce's click hung the tick for 4min and
            // Julien saw it "stuck at the door repeating actions". If 3+
            // talk attempts produced no dialog, assume a closed door is
            // blocking and click it open before retrying the talk.
            if (prayerTalkAttempts >= 3) {
                diag("Build 119: " + prayerTalkAttempts + " talk attempts, no dialog -- opening nearby door");
                if (clickDoorDirect("Open")) {
                    prayerTalkAttempts = 0;
                }
                return;
            }
            talkToOnce("Brother Brace");
            prayerTalkAttempts++;
            return;
        }
        // Open the prayer tab as instructed — PHYSICAL CLICK, not hotkey.
        // (Tick-based: click once per tick, verified by flag.)
        // Build 170 (Alex): varp 560 can set prayerTalked1=true while a
        // dialogue continue is still pending (varp arrives before the NPC
        // dialogue UI closes). The Prayer tab widget (548:69) reports
        // hidden=true while dialogue is open, causing NO VERIFIED TARGET
        // loops. Drain any pending dialogue BEFORE attempting the tab.
        // Do NOT guess new tab IDs -- the widget exists but is hidden.
        if (!prayerTabClicked) {
            if (safeIsInDialogue()) {
                if (prayerStallTicks++ % 10 == 0) {
                    diag("Build 170: dialogue still open after varp=560, draining continue before Prayer tab");
                }
                dialogueTick();
                return;
            }
            if (clickTabIcon(InterfaceTab.PRAYER, true)) prayerTabClicked = true;
            return;
        }
        // Build 172 (Alex): VARP-AUTHORITATIVE. Build 106 dialogue-transition
        // DISABLED when varp valid -- it set prayerTalked2=true on talk1's
        // lingering close (23:34:03) without a fresh Talk-to. Drain dialogue
        // if open; else dispatch TalkBrace directly for varp 570. ONLY
        // varp >= 580 proves talk2.
        if (!prayerTalked2) {
            if (safeIsInDialogue()) {
                dialogueTick();
                return;
            }
            talkToOnce("Brother Brace");
            return;
        }
        // Build 158 (Alex): varp 580 = Friends tab (was skipped entirely).
        // Build 170 (Alex): same pending-dialogue priority as Prayer tab.
        // varp 580 can set prayerTalked2 while a dialogue continue is still
        // pending; tab widgets are hidden while dialogue is open.
        if (!prayerFriendsClicked) {
            if (safeIsInDialogue()) {
                dialogueTick();
                return;
            }
            if (clickTabIcon(InterfaceTab.FRIENDS, true)) prayerFriendsClicked = true;
            return;
        }
        // Build 158 (Alex): varp 600 = third Brace conversation (was skipped).
        // Build 172 (Alex): VARP-AUTHORITATIVE. Dialogue-transition DISABLED.
        // Drain if open; else dispatch TalkBrace directly. ONLY varp >= 610
        // proves talk3.
        if (!prayerTalked3) {
            if (safeIsInDialogue()) {
                dialogueTick();
                return;
            }
            talkToOnce("Brother Brace");
            return;
        }
        // varp >= 610 handled at top-of-tick; if we're here with all flags
        // set, exit the chapel toward the Magic Instructor.
        // Build 173 (Alex): EXIT WITHOUT NPC DEPENDENCY. 172 RUNNING 23:38:53,
        // varp 570->610 at 23:39:21 (church lesson complete). Blocker: code
        // waited for Magic Instructor snapshot that may not load until AFTER
        // chapel exit. Fix: prefer live NPC snapshot if available; else use
        // stable landmark (3141,3088) from historical chapel-to-mage route
        // (3122,3102)->(3124,3100)->(3141,3088), plane 0. Route validates
        // against loaded doors/collision; pending-door ownership retained.
        // Do NOT wait indefinitely for an NPC that may not spawn until exit.
        if (prayerTalked3 && pv != null && pv >= 610 && pv < 620) {
            try {
                WorldPoint pp = worldModel.playerPos;
                WorldPoint goalTile = null;
                String goalDesc = null;
                WorldModel.NpcSnapshot magicGoal = findNpcSnapshot("Magic Instructor");
                if (magicGoal != null && magicGoal.tile != null) {
                    goalTile = magicGoal.tile;
                    goalDesc = "Magic Instructor@" + goalTile;
                } else {
                    // Build 173: stable landmark, no NPC wait.
                    goalTile = new WorldPoint(3141, 3088, 0);
                    goalDesc = "magic-landmark@" + goalTile;
                    if (prayerStallTicks % 20 == 0) {
                        diag("Build 173: no Instructor snapshot, exiting toward stable landmark " + goalTile);
                    }
                }
                if (pp == null || goalTile == null) {
                    return;
                }
                // Door-owned path with GOAL: handles chapel doors on the path.
                if (handleDoorRouteTick(pp, "PRAYER_EXIT", goalTile)) {
                    return; // Door handling consumed the tick
                }
                // No door blocking the path: walk direct to goal.
                WalkerState cws = Rs2Walker.walkStep(goalTile, 0);
                if (prayerStallTicks % 20 == 0) {
                    diag("Build 173: chapel exit walkStep -> " + cws
                        + " dest=" + goalDesc + " (varp=" + pv + ")");
                }
                prayerStallTicks++;
                return;
            } catch (Exception e) {
                diag("Build 173: chapel exit failed: " + e.getClass().getSimpleName());
            }
        }
        // To the magic instructor — one door click per tick; the top-of-tick
        // varp >= 610 check completes the stage.
        // Build 108: GATE RECOVERY. The bank stage skipped the Account Guide,
        // so the bank exit is game-gated on his talk — blindly clicking "Open"
        // looped the gate dialog forever (seen live 2026-09-27 17:44). The
        // game's gate dialog is ground truth: service a pending prerequisite
        // instead of the door, and never re-click a gated door.
        if (!accountGuideDone && accountGuidePending) {
            doAccountGuideStep(); // owns its dialogs
            return;
        }
        if (handleDoorGate()) return;
        clickDoorDirect("Open");
    }

    // Tick-based flags for the magic stage (Build 63).
    private boolean magicTalked1 = false;
    private boolean magicTabOpened = false;
    private boolean magicTalked2 = false; // Build 158: now BEFORE cast (varp 640)
    private boolean magicCastIssued = false;
    private int magicCastWait = 0;
    private boolean magicCastDone = false;
    private boolean magicTalked3 = false; // Build 158: teleport dialogue (varp 670)
    private int magicStallTicks = 0; // Build 173: diag throttle for landmark navigation
    // Build 106: dialog-transition completion flags (same latent bug as
    // prayer: dialogueTick() can never return true when called from inside a
    // safeIsInDialogue() guard).
    private boolean magicDialogSeen1 = false;
    private boolean magicDialogSeen2 = false;
    private boolean magicDialogSeen3 = false;

    private void resetMagicFlags() {
        magicTalked1 = false;
        magicTabOpened = false;
        magicTalked2 = false;
        magicCastIssued = false;
        magicCastWait = 0;
        magicCastDone = false;
        magicTalked3 = false;
        magicDialogSeen1 = false;
        magicDialogSeen2 = false;
        magicDialogSeen3 = false;
    }

    private void doMagic() {
        Microbot.status = "Tutorial Island: Magic Instructor";
        if (Rs2Player.hasCompletedTutorialIsland()) {
            if (!magicDone) diag("Magic complete: tutorial island finished");
            magicDone = true;
            resetMagicFlags();
            return;
        }
        // Build 159 (Alex): VARP-BASED progression per wiki varp 281.
        // varp = NEXT REQUIRED action. Step done when varp moves PAST it:
        // 620=Talk1, 630=Spellbook, 640=Talk2, 650=Wind Strike cast,
        // 670=Teleport dialogue, 1000=done.
        Integer mv = getVarp281();
        if (mv != null) {
            if (mv >= 1000 && !magicTalked3) {
                magicTalked3 = true;
                diag("Build 159: varp=" + mv + " >= 1000, teleport dialogue done");
            }
            if (mv >= 670 && !magicCastDone) {
                magicCastDone = true;
                diag("Build 159: varp=" + mv + " >= 670, Wind Strike done");
            }
            if (mv >= 650 && !magicTalked2) {
                magicTalked2 = true;
                diag("Build 159: varp=" + mv + " >= 650, Instructor talk2 done");
            }
            if (mv >= 640 && !magicTabOpened) {
                magicTabOpened = true;
                diag("Build 159: varp=" + mv + " >= 640, spellbook tab done");
            }
            if (mv >= 630 && !magicTalked1) {
                magicTalked1 = true;
                diag("Build 159: varp=" + mv + " >= 630, Instructor talk1 done");
            }
            // Build 172 (Alex): varp AUTHORITATIVE for Magic too. Reset
            // premature flags; clear dialogueSeen latches on varp transition.
            // Clicks/dialogue-close = attempts only; varp = completion.
            if (mv < 630 && magicTalked1) {
                magicTalked1 = false;
                diag("Build 172: varp=" + mv + " <630, RESETTING premature magicTalked1");
            }
            if (mv < 640 && magicTabOpened) {
                magicTabOpened = false;
                diag("Build 172: varp=" + mv + " <640, RESETTING premature magicTabOpened");
            }
            if (mv < 650 && magicTalked2) {
                magicTalked2 = false;
                diag("Build 172: varp=" + mv + " <650, RESETTING premature magicTalked2");
            }
            if (mv < 670 && magicCastDone) {
                magicCastDone = false; magicCastIssued = false;
                diag("Build 172: varp=" + mv + " <670, RESETTING premature magicCastDone");
            }
            if (mv < 1000 && magicTalked3) {
                magicTalked3 = false;
                diag("Build 172: varp=" + mv + " <1000, RESETTING premature magicTalked3");
            }
            if (mv != lastMagicVarpLogged) {
                diag("Build 172: varp281 MAGIC " + lastMagicVarpLogged + " -> " + mv);
                lastMagicVarpLogged = mv;
                // Clear stale dialogueSeen latches on varp transition.
                magicDialogSeen1 = false; magicDialogSeen2 = false; magicDialogSeen3 = false;
            }
        }
        diag("MAGIC TICK: talked1=" + magicTalked1 + " tab=" + magicTabOpened
                + " talked2=" + magicTalked2 + " cast=" + magicCastDone + " talked3=" + magicTalked3);
        // Build 172 (Alex): VARP-AUTHORITATIVE. Dialogue-transition DISABLED.
        // Drain if open; else dispatch directly. ONLY varp >= 630 proves talk1.
        // Build 173 (Alex): NAVIGATE TO LANDMARK until NPC loads. After chapel
        // exit the Instructor may not be in the NPC snapshot yet. Walk toward
        // stable landmark (3141,3088) until snapshot appears; do NOT wait
        // indefinitely for an NPC that loads on approach.
        if (!magicTalked1) {
            if (safeIsInDialogue()) {
                dialogueTick();
                return;
            }
            WorldModel.NpcSnapshot instructorSnap = findNpcSnapshot("Magic Instructor");
            if (instructorSnap == null || instructorSnap.tile == null) {
                // NPC not loaded: navigate toward landmark.
                WorldPoint mpp = worldModel.playerPos;
                WorldPoint magicLandmark = new WorldPoint(3141, 3088, 0);
                if (mpp != null) {
                    if (handleDoorRouteTick(mpp, "MAGIC_APPROACH", magicLandmark)) {
                        return;
                    }
                    WalkerState mws = Rs2Walker.walkStep(magicLandmark, 0);
                    if (magicStallTicks++ % 20 == 0) {
                        diag("Build 173: Instructor not in snapshot, walking to landmark "
                            + magicLandmark + " -> " + mws + " (varp=" + mv + ")");
                    }
                }
                return;
            }
            talkToOnce("Magic Instructor");
            return;
        }
        // Open the magic tab — PHYSICAL CLICK, not hotkey.
        // Build 170 (Alex): same pending-dialogue priority. varp 630 can
        // arrive while a dialogue continue is still pending.
        if (!magicTabOpened) {
            if (safeIsInDialogue()) {
                dialogueTick();
                return;
            }
            if (clickTabIcon(InterfaceTab.MAGIC, true)) magicTabOpened = true;
            return;
        }
        // Build 158 (Alex): talk2 (varp 640) comes BEFORE the cast.
        // The Instructor must be spoken to again after opening the
        // spellbook; old code cast first which the game rejects.
        // Build 172 (Alex): VARP-AUTHORITATIVE. Dialogue-transition DISABLED.
        // Drain if open; else dispatch directly. ONLY varp >= 650 proves talk2.
        if (!magicTalked2) {
            if (safeIsInDialogue()) {
                dialogueTick();
                return;
            }
            talkToOnce("Magic Instructor");
            return;
        }
        if (!magicCastDone) {
            // Build 174 (Alex): DRAIN DIALOGUE BEFORE CAST. 173 blocked
            // 23:45:16+: "Terrova gives you some air runes and mind runes" +
            // "Click here to continue" visible, but cast branch went straight
            // to castWindStrikeOnce() without draining. Runes must be
            // accepted first. Reuse 171's Continue-first dialogueTick().
            // Tutorial hint text alone is not blocking; actual dialogue is.
            if (safeIsInDialogue()) {
                dialogueTick();
                return;
            }
            // Build 159 (Alex): verify varp 650->670 (cast registered),
            // don't just wait for animation. Retry bounded while varp=650.
            Integer cv = getVarp281();
            if (cv != null && cv >= 670) {
                magicCastDone = true;
                diag("Build 159: varp=" + cv + " >= 670, Wind Strike verified");
                return;
            }
            if (!magicCastIssued) {
                // One cast attempt per tick; next ticks verify the cast landed.
                if (castWindStrikeOnce()) {
                    magicCastIssued = true;
                    magicCastWait = 0;
                    diag("Wind strike cast issued (varp=" + cv + ")");
                }
                return;
            }
            magicCastWait++;
            // Build 160 (Alex): varp is the ONLY truth for cast completion.
            // Removed the unreadable-varp animation fallback -- it marked
            // cast done from idle, which is wrong. If varp is unreadable,
            // keep retrying; don't assume success.
            if (magicCastWait > 25) {
                // ~15s with no varp progress -- retry the cast (bounded).
                // varp stuck at 650 means cast didn't register.
                diag("Build 159: cast wait timed out at varp=" + cv + ", retrying (bounded)");
                magicCastIssued = false;
                magicCastWait = 0;
            }
            return;
        }
        // Build 158 (Alex): talk3 (varp 670) = teleport dialogue.
        // Build 160 (Alex): at varp 670, PERFORM the departure dialogue.
        // Don't pre-complete on dialogue close -- keep retrying while 670
        // persists. Only varp >= 1000 confirms departure.
        if (!magicTalked3) {
            Integer dv = getVarp281();
            // If varp already >= 1000, we're done (handled at top).
            // If varp is 670+, we need to DO the dialogue.
            if (safeIsInDialogue()) {
                magicDialogSeen3 = true;
                dialogueTick();
                return;
            }
            if (magicDialogSeen3) {
                // Dialogue closed -- but did varp advance to 1000?
                // If still 670, the teleport didn't happen; retry.
                if (dv != null && dv >= 1000) {
                    magicTalked3 = true;
                    magicDialogSeen3 = false;
                    diag("Build 160: departure confirmed (varp=" + dv + " >= 1000)");
                    return;
                } else {
                    // Dialogue closed but varp still 670 -- retry the conversation.
                    magicDialogSeen3 = false;
                    diag("Build 160: dialogue closed but varp=" + dv + " (still 670), retrying departure talk");
                    // Fall through to talkToOnce below
                }
            }
            talkToOnce("Magic Instructor");
            return;
        }
        // He teleports us to Lumbridge: the top-of-tick
        // hasCompletedTutorialIsland() check completes the stage.
        diag("Waiting for teleport to Lumbridge...");
    }

    /** ONE wind-strike cast attempt: find a chicken, cast. No waiting.
     *  Returns true if the cast action was issued. */
    private boolean castWindStrikeOnce() {
        // REBUILD: was blocking invoke() NPC iteration. Now uses the
        // event-driven Rs2NpcCache (non-blocking); getNpc() gives the raw Actor.
        Actor chicken = null;
        try {
            net.runelite.client.plugins.microbot.api.npc.models.Rs2NpcModel model =
                Microbot.getRs2NpcCache().query()
                    .within(20)
                    .withName("Chicken")
                    .nearest();
            if (model != null) {
                chicken = model.getNpc();
            }
        } catch (Exception e) {
            // fall through to null
        }
        if (chicken == null) {
            // Maybe we're not near the pen yet: open the gate (one click;
            // the next tick retries finding a chicken).
            diag("No chicken nearby, opening gate");
            clickDoorDirect("Open");
            return false;
        }
        try {
            // Build 158 (Alex): Rs2Magic.castOn only accepts the legacy
            // util.npc.Rs2NpcModel wrapper or Player -- raw Actor from
            // model.getNpc() returns false silently. Wrap it.
            // (Cast Actor to NPC for the Rs2NpcModel constructor.)
            net.runelite.client.plugins.microbot.util.npc.Rs2NpcModel wrapped =
                new net.runelite.client.plugins.microbot.util.npc.Rs2NpcModel((NPC) chicken);
            return Rs2Magic.castOn(MagicAction.WIND_STRIKE, wrapped);
        } catch (Exception e) {
            diag("castWindStrikeOnce failed: " + e);
            return false;
        }
    }
}
