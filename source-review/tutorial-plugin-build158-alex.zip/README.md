# Build 158 — VARP PRAYER/MAGIC — For Alex
## 2026-09-27 22:50 EDT

### Status: SHIPPED (not yet loaded)
Patch: patches/patch-158.zip
SHA-256: 3dbee4a54641035e960b98c0794d9cd4da693f9bc1540cf906217437598d7e0d
version.txt = 158
Marker: "Build 158 - VARP PRAYER/MAGIC" (verified via strings)

### Fixes (Alex's completion blockers)

1. **doPrayer varp-driven**: Removed the Magic Instructor proximity
   (40 tiles) completion check that skipped Friends tab and third Brace
   talk. Now: 550=Brace1, 560=Prayer tab, 570=Brace2, 580=Friends tab
   (NEW), 600=Brace3 (NEW), 610=done. Varp auto-marks completed steps.

2. **doMagic reordered**: 620=Talk1, 630=Spellbook, 640=Talk2 BEFORE cast
   (was casting before talk2 -- game rejects), 650=Wind Strike, 670=Talk3
   teleport dialogue (NEW). Varp auto-marks completed steps.

3. **dialogueTick scoped**: Quest Guide option-2 override now requires
   inQuestGuide only (questTabClicked persists and corrupted later
   choices).

4. **castOn wrapper**: Rs2Magic.castOn gets legacy Rs2NpcModel wrapper
   (new Rs2NpcModel((NPC) chicken)) -- raw Actor returns false silently
   per Alex's javap.

Keeps Build 157 - EXACT WALK DISTANCE (walkTo(x,0)).

### Status
Loaded: Build 157 (door 9722 retry). Available: 158.
Awaiting 158 banner. PRAYER/MAGIC fixes activate once past the door.
