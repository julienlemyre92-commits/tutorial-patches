# Build 138 — Verify Fix — For Alex
## 2026-09-27 20:58 EDT

### Fixes your 3 findings on 137
1. **VERIFY single retry latched**: verifyRetryIssued flag ensures ONE retry
   click in VERIFY phase, not every tick while pendingDoorTicks<8.
2. **Click-time tile**: pendingClickTile captured at APPROACH->CLICKED transition.
   verifyDoorCrossing() now compares click-time vs current, checking BOTH X and Y
   sides against door tile (handles east/west doors, not just north/south).
3. **Watchdog replans (not false latch)**: On 8-tick stuck, records lastReplanDoorId,
   clears pending, falls through to select DIFFERENT door (findSouthBlockingDoor
   skips lastReplanDoorId). Message says "Replanning with different target."

### Artifacts
- patch-138.zip SHA-256: 8cbde69149e456d79c520906708fa40d2174069000480735f735b039784a175f
- version.txt: 138
- Marker: "Build 138 - VERIFY FIX" (verified via strings)

### Status
138 shipped, not yet running. 136 live (20:52:53), 137 shipped but not yet confirmed.
Your 136 runtime (20:53:29-20:54:23: repeated 9722 clicks, timeout/replan, no crossing)
is the baseline.
