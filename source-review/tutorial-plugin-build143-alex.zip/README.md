# Build 143 — Far-Side Verify — For Alex
## 2026-09-27 21:19 EDT

### Status
Patch uploaded: patches/patch-143.zip
SHA-256: 32ef22bc8a9311909c6933f15fa679e6f3e393e00a1b5c2b0739b11caae058bd
version.txt = 143
Marker: "Build 143 - FAR-SIDE VERIFY" (verified via strings)
Classes: net.runelite.client.plugins.microbot.tutorialisland.{TutorialIslandScript,TutorialIslandPlugin,TutorialIslandConfig,WorldModel}
Compiled: JDK 17, clean, agent excluded

### Change vs 142
WALKTHROUGH now uses verifyWalkthroughFarSide() instead of verifyDoorCrossing().

### Deterministic simulation (Python, exact Java logic)

#### OLD verifyDoorCrossing (strict sign flips) — 4 cases:
```
1. LEGIT (3133,3124)->(3130,3122) door (3130,3124) = False  <<< BUG
   beforeY=0 (at door level), afterY=-1. Strict flip needs nonzero before.
2. OSCILLATION (3129,3124)->(3130,3124) = False (correct)
3. OSCILLATION REV (3130,3124)->(3129,3124) = False (correct)
4. TRUE N->S (3130,3126)->(3130,3122) = True (correct)
```
The legit 5-tile walkthrough route was rejected because the player approaches
at the door's Y level (beforeY=0), and strict crossedY requires beforeY>0.

#### NEW verifyWalkthroughFarSide — 7 cases, ALL PASS:
```
PASS: LEGIT (3133,3124)->(3130,3122) = True
PASS: OSCILLATION fwd (no Y change) = False
PASS: OSCILLATION rev (no Y change) = False
PASS: TRUE N->S (3130,3126)->(3130,3122) = True
PASS: WALK AROUND east (x far from door) = False
PASS: NORTH shuffle (never went south) = False
PASS: STARTED south (wrong side) = False
```

Logic:
- Must start at/north of door Y (tileBefore.getY() >= dy)
- Must end south of door Y (tileAfter.getY() < dy)
- X must hug door (|tileAfter.getX() - dx| <= 2)
- Must have moved south (tileAfter.getY() < tileBefore.getY())

### Notes
- Strict verifyDoorCrossing() retained for small click-verifications (1-4 tiles).
- Route progress still requires separate south checkpoint y<=3115.
- Keeps 142: no-adjacent real rejection, FAILED logging, traversable gate.
